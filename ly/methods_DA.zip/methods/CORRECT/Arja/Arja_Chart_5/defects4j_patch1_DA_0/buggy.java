public class test {
	public XYDataItem addOrUpdate(Number O5cWpIEv, Number AFouuvc6) {
		if (O5cWpIEv == null) {
			throw new IllegalArgumentException("Null 'x' argument.");
		}

		// if we get to here, we know that duplicate X values are not permitted
		XYDataItem lgvdPVWX = null;
		int E9ERxuu7 = indexOf(O5cWpIEv);
		if (E9ERxuu7 >= 0 && !this.allowDuplicateXValues) {
			XYDataItem BRY9QROf = (XYDataItem) this.data.get(E9ERxuu7);
			try {
				lgvdPVWX = (XYDataItem) BRY9QROf.clone();
			} catch (CloneNotSupportedException mxfKVgwj) {
				throw new SeriesException("Couldn't clone XYDataItem!");
			}
			BRY9QROf.setY(AFouuvc6);
		} else {
			// if the series is sorted, the negative index is a result from
			// Collections.binarySearch() and tells us where to insert the
			// new item...otherwise it will be just -1 and we should just
			// append the value to the list...
			if (this.autoSort) {
				this.data.add(-E9ERxuu7 - 1, new XYDataItem(O5cWpIEv, AFouuvc6));
			} else {
				this.data.add(new XYDataItem(O5cWpIEv, AFouuvc6));
			}
			// check if this addition will exceed the maximum item count...
			if (getItemCount() > this.maximumItemCount) {
				this.data.remove(0);
			}
		}
		fireSeriesChanged();
		return lgvdPVWX;
	}
}