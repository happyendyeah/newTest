public class test {
	public XYDataItem addOrUpdate(Number x, Number y) {
		if (!(x == null))
			;
		else {
			throw new IllegalArgumentException("Null 'x' argument.");
		}

		// if we get to here, we know that duplicate X values are not permitted
		XYDataItem overwritten = null;
		int index = indexOf(x);
		if (!(index >= 0 && !this.allowDuplicateXValues)) {
			add(x, y, true);
			if (getItemCount() > this.maximumItemCount) {
				this.data.remove(0);
			}
		} else {
			XYDataItem existing = (XYDataItem) this.data.get(index);
			try {
				overwritten = (XYDataItem) existing.clone();
			} catch (CloneNotSupportedException e) {
				throw new SeriesException("Couldn't clone XYDataItem!");
			}
			existing.setY(y);
		}
		fireSeriesChanged();
		return overwritten;
	}
}