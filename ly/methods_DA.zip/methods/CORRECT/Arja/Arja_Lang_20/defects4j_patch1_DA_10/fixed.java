public class test {
	public static String join(Object[] array, String separator, int startIndex, int endIndex) {
		if (separator == null) {
			separator = EMPTY;
		}
		if (array == null) {
			return null;
		}

		// endIndex - startIndex > 0:   Len = NofStrings *(len(firstString) + len(separator))
		//           (Assuming that all Strings are roughly equally long)
		int noOfItems = (endIndex - startIndex);
		StringBuilder buf = new StringBuilder(256);

		if (noOfItems <= 0) {
			return EMPTY;
		}

		for (int i = startIndex; i < endIndex; i++) {
			if (i > startIndex) {
				buf.append(separator);
			}
			if (array[i] != null) {
				buf.append(array[i]);
			}
		}
		return buf.toString();
	}

	public static String join(Object[] array, char separator, int startIndex, int endIndex) {
		int noOfItems = (endIndex - startIndex);
		if (array == null) {
			return null;
		}
		StringBuilder buf = new StringBuilder(256);

		if (noOfItems <= 0) {
			return EMPTY;
		}

		for (int i = startIndex; i < endIndex; i++) {
			if (i > startIndex) {
				buf.append(separator);
			}
			if (array[i] != null) {
				buf.append(array[i]);
			}
		}
		return buf.toString();
	}
}