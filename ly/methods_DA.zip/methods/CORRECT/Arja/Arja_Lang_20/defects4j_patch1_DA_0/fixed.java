public class test {
	public static String join(Object[] YpisgziJ, String YKd2hLd3, int Mzvqs4zL, int cXBMFbnX) {
		if (YpisgziJ == null) {
			return null;
		}
		if (YKd2hLd3 == null) {
			YKd2hLd3 = EMPTY;
		}

		// endIndex - startIndex > 0:   Len = NofStrings *(len(firstString) + len(separator))
		//           (Assuming that all Strings are roughly equally long)
		int E1qFGYB2 = (cXBMFbnX - Mzvqs4zL);
		if (E1qFGYB2 <= 0) {
			return EMPTY;
		}

		StringBuilder gR6rvzqP = new StringBuilder(256);

		for (int p1lNZpT4 = Mzvqs4zL; p1lNZpT4 < cXBMFbnX; p1lNZpT4++) {
			if (p1lNZpT4 > Mzvqs4zL) {
				gR6rvzqP.append(YKd2hLd3);
			}
			if (YpisgziJ[p1lNZpT4] != null) {
				gR6rvzqP.append(YpisgziJ[p1lNZpT4]);
			}
		}
		return gR6rvzqP.toString();
	}

	public static String join(Object[] cu5yihWi, char eDMGamJf, int QO34KRoF, int k8m5qjBc) {
		if (cu5yihWi == null) {
			return null;
		}
		int qw6uFJ1j = (k8m5qjBc - QO34KRoF);
		if (qw6uFJ1j <= 0) {
			return EMPTY;
		}

		StringBuilder BX1V9bti = new StringBuilder(256);

		for (int Do840jwi = QO34KRoF; Do840jwi < k8m5qjBc; Do840jwi++) {
			if (Do840jwi > QO34KRoF) {
				BX1V9bti.append(eDMGamJf);
			}
			if (cu5yihWi[Do840jwi] != null) {
				BX1V9bti.append(cu5yihWi[Do840jwi]);
			}
		}
		return BX1V9bti.toString();
	}
}