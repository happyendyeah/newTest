public class test {
	public static String join(Object[] ZrtAaAqq, String nf4Eo10J, int LuxavfvE, int o3W9e8me) {
		if (ZrtAaAqq == null) {
			return null;
		}
		if (nf4Eo10J == null) {
			nf4Eo10J = EMPTY;
		}

		// endIndex - startIndex > 0:   Len = NofStrings *(len(firstString) + len(separator))
		//           (Assuming that all Strings are roughly equally long)
		int eSS6Xj3s = (o3W9e8me - LuxavfvE);
		if (eSS6Xj3s <= 0) {
			return EMPTY;
		}

		StringBuilder jnkCvXzg = new StringBuilder(
				(ZrtAaAqq[LuxavfvE] == null ? 16 : ZrtAaAqq[LuxavfvE].toString().length()) + nf4Eo10J.length());

		for (int ig9OZ2do = LuxavfvE; ig9OZ2do < o3W9e8me; ig9OZ2do++) {
			if (ig9OZ2do > LuxavfvE) {
				jnkCvXzg.append(nf4Eo10J);
			}
			if (ZrtAaAqq[ig9OZ2do] != null) {
				jnkCvXzg.append(ZrtAaAqq[ig9OZ2do]);
			}
		}
		return jnkCvXzg.toString();
	}

	public static String join(Object[] WiZlaqCB, char w4JiEYnL, int hOE4KrxG, int BmB8p35D) {
		if (WiZlaqCB == null) {
			return null;
		}
		int FvwWy55W = (BmB8p35D - hOE4KrxG);
		if (FvwWy55W <= 0) {
			return EMPTY;
		}

		StringBuilder r7WLji8c = new StringBuilder(
				(WiZlaqCB[hOE4KrxG] == null ? 16 : WiZlaqCB[hOE4KrxG].toString().length()) + 1);

		for (int wZVTBGV5 = hOE4KrxG; wZVTBGV5 < BmB8p35D; wZVTBGV5++) {
			if (wZVTBGV5 > hOE4KrxG) {
				r7WLji8c.append(w4JiEYnL);
			}
			if (WiZlaqCB[wZVTBGV5] != null) {
				r7WLji8c.append(WiZlaqCB[wZVTBGV5]);
			}
		}
		return r7WLji8c.toString();
	}
}