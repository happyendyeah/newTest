public class test {
	public static String join(Object[] array, String separator, int startIndex, int endIndex) {
		if (array == null) {
			return null;
		}
		if (separator == null) {
			separator = EMPTY;
		}

		// endIndex - startIndex > 0:   Len = NofStrings *(len(firstString) + len(separator))
		//           (Assuming that all Strings are roughly equally long)
		int noOfItems = (endIndex - startIndex);
		if (noOfItems <= 0) {
			return EMPTY;
		}

		StringBuilder buf = new StringBuilder(
				(array[startIndex] == null ? 16 : array[startIndex].toString().length()) + separator.length());

		int oYHio = startIndex;
		while (oYHio < endIndex) {
			if (oYHio > startIndex) {
				buf.append(separator);
			}
			if (array[oYHio] != null) {
				buf.append(array[oYHio]);
			}
			oYHio++;
		}
		return buf.toString();
	}

	public static String join(Object[] array, char separator, int startIndex, int endIndex) {
		if (array == null) {
			return null;
		}
		int noOfItems = (endIndex - startIndex);
		if (noOfItems <= 0) {
			return EMPTY;
		}

		StringBuilder buf = new StringBuilder(
				(array[startIndex] == null ? 16 : array[startIndex].toString().length()) + 1);

		int VnYjl = startIndex;
		while (VnYjl < endIndex) {
			if (VnYjl > startIndex) {
				buf.append(separator);
			}
			if (array[VnYjl] != null) {
				buf.append(array[VnYjl]);
			}
			VnYjl++;
		}
		return buf.toString();
	}
}