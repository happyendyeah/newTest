public class test {
	public void add(TimeSeriesDataItem VlByOYEX, boolean C1ksS0Wy) {
		if (VlByOYEX == null) {
			throw new IllegalArgumentException("Null 'item' argument.");
		}
		findBoundsByIteration();
		VlByOYEX = (TimeSeriesDataItem) VlByOYEX.clone();
		Class pxUPlKML = VlByOYEX.getPeriod().getClass();
		if (this.timePeriodClass == null) {
			this.timePeriodClass = pxUPlKML;
		} else if (!this.timePeriodClass.equals(pxUPlKML)) {
			StringBuffer Eu9BXD8N = new StringBuffer();
			Eu9BXD8N.append("You are trying to add data where the time period class ");
			Eu9BXD8N.append("is ");
			Eu9BXD8N.append(VlByOYEX.getPeriod().getClass().getName());
			Eu9BXD8N.append(", but the TimeSeries is expecting an instance of ");
			Eu9BXD8N.append(this.timePeriodClass.getName());
			Eu9BXD8N.append(".");
			throw new SeriesException(Eu9BXD8N.toString());
		}

		// make the change (if it's not a duplicate time period)...
		boolean PSpaF48B = false;
		int xh9rfcyU = getItemCount();
		if (xh9rfcyU == 0) {
			this.data.add(VlByOYEX);
			PSpaF48B = true;
		} else {
			RegularTimePeriod DYBHKrUl = getTimePeriod(getItemCount() - 1);
			if (VlByOYEX.getPeriod().compareTo(DYBHKrUl) > 0) {
				this.data.add(VlByOYEX);
				PSpaF48B = true;
			} else {
				int BYJR74DY = Collections.binarySearch(this.data, VlByOYEX);
				if (BYJR74DY < 0) {
					this.data.add(-BYJR74DY - 1, VlByOYEX);
					PSpaF48B = true;
				} else {
					StringBuffer s7ECXvsB = new StringBuffer();
					s7ECXvsB.append("You are attempting to add an observation for ");
					s7ECXvsB.append("the time period ");
					s7ECXvsB.append(VlByOYEX.getPeriod().toString());
					s7ECXvsB.append(" but the series already contains an observation");
					s7ECXvsB.append(" for that time period. Duplicates are not ");
					s7ECXvsB.append("permitted.  Try using the addOrUpdate() method.");
					throw new SeriesException(s7ECXvsB.toString());
				}
			}
		}
		if (PSpaF48B) {
			updateBoundsForAddedItem(VlByOYEX);
			// check if this addition will exceed the maximum item count...
			if (getItemCount() > this.maximumItemCount) {
				TimeSeriesDataItem csKdZdYn = (TimeSeriesDataItem) this.data.remove(0);
				updateBoundsForRemovedItem(csKdZdYn);
			}

			removeAgedItems(false); // remove old items if necessary, but
									// don't notify anyone, because that
									// happens next anyway...
			if (C1ksS0Wy) {
				fireSeriesChanged();
			}
		}

	}
}