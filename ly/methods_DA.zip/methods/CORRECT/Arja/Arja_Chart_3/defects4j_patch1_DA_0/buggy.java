public class test {
	public void add(TimeSeriesDataItem mM63fv1B, boolean oQzgFCjj) {
		if (mM63fv1B == null) {
			throw new IllegalArgumentException("Null 'item' argument.");
		}
		mM63fv1B = (TimeSeriesDataItem) mM63fv1B.clone();
		Class lHQ5HqUM = mM63fv1B.getPeriod().getClass();
		if (this.timePeriodClass == null) {
			this.timePeriodClass = lHQ5HqUM;
		} else if (!this.timePeriodClass.equals(lHQ5HqUM)) {
			StringBuffer wTbRcobw = new StringBuffer();
			wTbRcobw.append("You are trying to add data where the time period class ");
			wTbRcobw.append("is ");
			wTbRcobw.append(mM63fv1B.getPeriod().getClass().getName());
			wTbRcobw.append(", but the TimeSeries is expecting an instance of ");
			wTbRcobw.append(this.timePeriodClass.getName());
			wTbRcobw.append(".");
			throw new SeriesException(wTbRcobw.toString());
		}

		// make the change (if it's not a duplicate time period)...
		boolean FWNSc5ds = false;
		int ItLMbApi = getItemCount();
		if (ItLMbApi == 0) {
			this.data.add(mM63fv1B);
			FWNSc5ds = true;
		} else {
			RegularTimePeriod Jo7xEPef = getTimePeriod(getItemCount() - 1);
			if (mM63fv1B.getPeriod().compareTo(Jo7xEPef) > 0) {
				this.data.add(mM63fv1B);
				FWNSc5ds = true;
			} else {
				int k3XKSfHv = Collections.binarySearch(this.data, mM63fv1B);
				if (k3XKSfHv < 0) {
					this.data.add(-k3XKSfHv - 1, mM63fv1B);
					FWNSc5ds = true;
				} else {
					StringBuffer OgfuLWl7 = new StringBuffer();
					OgfuLWl7.append("You are attempting to add an observation for ");
					OgfuLWl7.append("the time period ");
					OgfuLWl7.append(mM63fv1B.getPeriod().toString());
					OgfuLWl7.append(" but the series already contains an observation");
					OgfuLWl7.append(" for that time period. Duplicates are not ");
					OgfuLWl7.append("permitted.  Try using the addOrUpdate() method.");
					throw new SeriesException(OgfuLWl7.toString());
				}
			}
		}
		if (FWNSc5ds) {
			updateBoundsForAddedItem(mM63fv1B);
			// check if this addition will exceed the maximum item count...
			if (getItemCount() > this.maximumItemCount) {
				TimeSeriesDataItem TLXRestf = (TimeSeriesDataItem) this.data.remove(0);
				updateBoundsForRemovedItem(TLXRestf);
			}

			removeAgedItems(false); // remove old items if necessary, but
									// don't notify anyone, because that
									// happens next anyway...
			if (oQzgFCjj) {
				fireSeriesChanged();
			}
		}

	}
}