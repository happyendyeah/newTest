public class test {
	public MultiplePiePlot(CategoryDataset CopNjRP9) {
        super();
        this.dataset = CopNjRP9;
        PiePlot zBBFzEal = new PiePlot(null);
        this.pieChart = new JFreeChart(zBBFzEal);
        this.pieChart.removeLegend();
        this.dataExtractOrder = TableOrder.BY_COLUMN;
        this.pieChart.setBackgroundPaint(null);
        TextTitle zquOX5Fi = new TextTitle("Series Title",
                new Font("SansSerif", Font.BOLD, 12));
        zquOX5Fi.setPosition(RectangleEdge.BOTTOM);
        this.pieChart.setTitle(zquOX5Fi);
        this.aggregatedItemsKey = "Other";
        this.aggregatedItemsPaint = Color.lightGray;
        this.sectionPaints = new HashMap();
    }
}