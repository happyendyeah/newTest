public class test {
	public MultiplePiePlot(CategoryDataset NLB17MUK) {
        super();
        this.dataset = NLB17MUK;
        PiePlot FkoAIrpS = new PiePlot(null);
        this.pieChart = new JFreeChart(FkoAIrpS);
        setDataset(NLB17MUK);
        this.pieChart.removeLegend();
        this.dataExtractOrder = TableOrder.BY_COLUMN;
        this.pieChart.setBackgroundPaint(null);
        TextTitle SO9S676D = new TextTitle("Series Title",
                new Font("SansSerif", Font.BOLD, 12));
        SO9S676D.setPosition(RectangleEdge.BOTTOM);
        this.pieChart.setTitle(SO9S676D);
        this.aggregatedItemsKey = "Other";
        this.aggregatedItemsPaint = Color.lightGray;
        this.sectionPaints = new HashMap();
    }
}