public class test {
	public MultiplePiePlot(CategoryDataset wc8W4PpX) {
        super();
        this.dataset = wc8W4PpX;
        PiePlot E3SHANnZ = new PiePlot(null);
        this.pieChart = new JFreeChart(E3SHANnZ);
        this.pieChart.removeLegend();
        setDataset(wc8W4PpX);
        this.dataExtractOrder = TableOrder.BY_COLUMN;
        this.pieChart.setBackgroundPaint(null);
        TextTitle FzsbqFEJ = new TextTitle("Series Title",
                new Font("SansSerif", Font.BOLD, 12));
        FzsbqFEJ.setPosition(RectangleEdge.BOTTOM);
        this.pieChart.setTitle(FzsbqFEJ);
        this.aggregatedItemsKey = "Other";
        this.aggregatedItemsPaint = Color.lightGray;
        this.sectionPaints = new HashMap();
    }
}