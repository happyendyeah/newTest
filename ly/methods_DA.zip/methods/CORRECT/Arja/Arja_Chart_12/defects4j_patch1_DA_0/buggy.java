public class test {
	public MultiplePiePlot(CategoryDataset qBWIgvot) {
        super();
        this.dataset = qBWIgvot;
        PiePlot OwFeBjUR = new PiePlot(null);
        this.pieChart = new JFreeChart(OwFeBjUR);
        this.pieChart.removeLegend();
        this.dataExtractOrder = TableOrder.BY_COLUMN;
        this.pieChart.setBackgroundPaint(null);
        TextTitle Wp1GQt1q = new TextTitle("Series Title",
                new Font("SansSerif", Font.BOLD, 12));
        Wp1GQt1q.setPosition(RectangleEdge.BOTTOM);
        this.pieChart.setTitle(Wp1GQt1q);
        this.aggregatedItemsKey = "Other";
        this.aggregatedItemsPaint = Color.lightGray;
        this.sectionPaints = new HashMap();
    }
}