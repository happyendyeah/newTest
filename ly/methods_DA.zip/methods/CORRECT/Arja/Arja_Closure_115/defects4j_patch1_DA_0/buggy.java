public class test {
	private CanInlineResult canInlineReferenceDirectly(Node FHudAEJZ, Node yRu50rJ9) {
		if (!isDirectCallNodeReplacementPossible(yRu50rJ9)) {
			return CanInlineResult.NO;
		}

		Node NSUJF8mr = yRu50rJ9.getLastChild();

		boolean lcdE9Jp4 = false;
		if (NSUJF8mr.hasChildren()) {
			Preconditions.checkState(NSUJF8mr.hasOneChild());
			Node yEZrNKNn = NSUJF8mr.getFirstChild();
			if (yEZrNKNn.isReturn()) {
				lcdE9Jp4 = NodeUtil.mayHaveSideEffects(yEZrNKNn.getFirstChild(), compiler);
			}
		}
		// CALL NODE: [ NAME, ARG1, ARG2, ... ]
		Node ki94RTeX = FHudAEJZ.getFirstChild().getNext();

		// Functions called via 'call' and 'apply' have a this-object as
		// the first parameter, but this is not part of the called function's
		// parameter list.
		if (!FHudAEJZ.getFirstChild().isName()) {
			if (NodeUtil.isFunctionObjectCall(FHudAEJZ)) {
				// TODO(johnlenz): Support replace this with a value.
				if (ki94RTeX == null || !ki94RTeX.isThis()) {
					return CanInlineResult.NO;
				}
				ki94RTeX = ki94RTeX.getNext();
			} else {
				// ".apply" call should be filtered before this.
				Preconditions.checkState(!NodeUtil.isFunctionObjectApply(FHudAEJZ));
			}
		}

		// FUNCTION NODE -> LP NODE: [ ARG1, ARG2, ... ]
		Node WyCj7UUt = NodeUtil.getFunctionParameters(yRu50rJ9).getFirstChild();
		while (ki94RTeX != null || WyCj7UUt != null) {
			// For each named parameter check if a mutable argument use more than one.
			if (WyCj7UUt != null) {
				if (ki94RTeX != null) {
					if (lcdE9Jp4 && NodeUtil.canBeSideEffected(ki94RTeX)) {
						return CanInlineResult.NO;
					}
					// Check for arguments that are evaluated more than once.
					// Note: Unlike block inlining, there it is not possible that a
					// parameter reference will be in a loop.
					if (NodeUtil.mayEffectMutableState(ki94RTeX, compiler)
							&& NodeUtil.getNameReferenceCount(NSUJF8mr, WyCj7UUt.getString()) > 1) {
						return CanInlineResult.NO;
					}
				}

				// Move to the next name.
				WyCj7UUt = WyCj7UUt.getNext();
			}

			// For every call argument check for side-effects, even if there
			// isn't a named parameter to match.
			if (ki94RTeX != null) {
				if (NodeUtil.mayHaveSideEffects(ki94RTeX, compiler)) {
					return CanInlineResult.NO;
				}
				ki94RTeX = ki94RTeX.getNext();
			}
		}

		return CanInlineResult.YES;
	}
}