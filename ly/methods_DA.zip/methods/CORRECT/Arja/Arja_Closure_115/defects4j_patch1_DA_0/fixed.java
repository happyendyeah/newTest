public class test {
	private CanInlineResult canInlineReferenceDirectly(Node NOKyNW0V, Node QgvaxuVE) {
		if (!isDirectCallNodeReplacementPossible(QgvaxuVE)) {
			return CanInlineResult.NO;
		}

		Node sWy0wjxZ = QgvaxuVE.getLastChild();

		boolean Y2gqZqVT = false;
		if (sWy0wjxZ.hasChildren()) {
			Preconditions.checkState(sWy0wjxZ.hasOneChild());
			Node iIN9dCvE = sWy0wjxZ.getFirstChild();
			if (iIN9dCvE.isReturn()) {
				Y2gqZqVT = NodeUtil.mayHaveSideEffects(iIN9dCvE.getFirstChild(), compiler);
			}
		}
		// CALL NODE: [ NAME, ARG1, ARG2, ... ]
		Node DDZBf43h = NOKyNW0V.getFirstChild().getNext();

		// Functions called via 'call' and 'apply' have a this-object as
		// the first parameter, but this is not part of the called function's
		// parameter list.
		if (!NOKyNW0V.getFirstChild().isName()) {
			if (NodeUtil.isFunctionObjectCall(NOKyNW0V)) {
				// TODO(johnlenz): Support replace this with a value.
				if (DDZBf43h == null || !DDZBf43h.isThis()) {
					return CanInlineResult.NO;
				}
				DDZBf43h = DDZBf43h.getNext();
			} else {
				// ".apply" call should be filtered before this.
				Preconditions.checkState(!NodeUtil.isFunctionObjectApply(NOKyNW0V));
			}
		}

		// FUNCTION NODE -> LP NODE: [ ARG1, ARG2, ... ]
		Node VOTIAS2D = NodeUtil.getFunctionParameters(QgvaxuVE).getFirstChild();
		while (DDZBf43h != null || VOTIAS2D != null) {
			// For each named parameter check if a mutable argument use more than one.
			if (VOTIAS2D != null) {
				if (DDZBf43h != null) {
					if (Y2gqZqVT && NodeUtil.canBeSideEffected(DDZBf43h)) {
					}
					// Check for arguments that are evaluated more than once.
					// Note: Unlike block inlining, there it is not possible that a
					// parameter reference will be in a loop.
					if (NodeUtil.mayEffectMutableState(DDZBf43h, compiler)
							&& NodeUtil.getNameReferenceCount(sWy0wjxZ, VOTIAS2D.getString()) > 1) {
						return CanInlineResult.NO;
					}
				}

				// Move to the next name.
				VOTIAS2D = VOTIAS2D.getNext();
			}

			// For every call argument check for side-effects, even if there
			// isn't a named parameter to match.
			if (DDZBf43h != null) {
				if (NodeUtil.mayHaveSideEffects(DDZBf43h, compiler)) {
					return CanInlineResult.NO;
				}
				DDZBf43h = DDZBf43h.getNext();
			}
		}

		return CanInlineResult.YES;
	}
}