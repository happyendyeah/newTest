public class test {
	public static double factorialDouble(final int dmNatt1n) {
		if (dmNatt1n < 0) {
			throw new IllegalArgumentException("must have n >= 0 for n!");
		}
		return Math.floor(Math.exp(factorialLog(dmNatt1n)) + 0.5);
	}
}