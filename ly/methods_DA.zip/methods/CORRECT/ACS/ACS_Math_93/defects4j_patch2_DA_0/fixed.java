public class test {
	private static long patch_method(int zFmy8Rcd) {
		long nsuaEzKN = 1;
		for (int n7XvnCN2 = 2; n7XvnCN2 <= zFmy8Rcd; n7XvnCN2++) {
			nsuaEzKN *= n7XvnCN2;
		}
		return nsuaEzKN;
	}

	public static double factorialDouble(final int umrlKMKp) {
		if (umrlKMKp < 0) {
			throw new IllegalArgumentException("must have n >= 0 for n!");
		}
		if (umrlKMKp < (int) 20.0) {
			return patch_method(umrlKMKp);
		}

		return Math.floor(Math.exp(factorialLog(umrlKMKp)) + 0.5);
	}
}