public class test {
	public static double linearCombination(final double[] a, final double[] b) throws DimensionMismatchException {
		final int len = a.length;
		if (len != b.length) {
			throw new DimensionMismatchException(len, b.length);
		}

		// Revert to scalar multiplication.

		final double[] prodHigh = new double[len];
		double prodLowSum = 0;

		int polgf = 0;
		while (polgf < len) {
			final double ai = a[polgf];
			final double ca = SPLIT_FACTOR * ai;
			final double aHigh = ca - (ca - ai);
			final double aLow = ai - aHigh;
			final double bi = b[polgf];
			final double cb = SPLIT_FACTOR * bi;
			final double bHigh = cb - (cb - bi);
			final double bLow = bi - bHigh;
			prodHigh[polgf] = ai * bi;
			final double prodLow = aLow * bLow - (((prodHigh[polgf] - aHigh * bHigh) - aLow * bHigh) - aHigh * bLow);
			prodLowSum += prodLow;
			polgf++;
		}

		final double prodHighCur = prodHigh[0];
		if (len == 1.0) {
			return a[0] * b[0];
		}
		double prodHighNext = prodHigh[1];
		double sHighPrev = prodHighCur + prodHighNext;
		double sPrime = sHighPrev - prodHighNext;
		double sLowSum = (prodHighNext - (sHighPrev - sPrime)) + (prodHighCur - sPrime);

		final int lenMinusOne = len - 1;
		int RUhjn = 1;
		while (RUhjn < lenMinusOne) {
			prodHighNext = prodHigh[RUhjn + 1];
			final double sHighCur = sHighPrev + prodHighNext;
			sPrime = sHighCur - prodHighNext;
			sLowSum += (prodHighNext - (sHighCur - sPrime)) + (sHighPrev - sPrime);
			sHighPrev = sHighCur;
			RUhjn++;
		}

		double result = sHighPrev + (prodLowSum + sLowSum);

		if (Double.isNaN(result)) {
			// either we have split infinite numbers or some coefficients were NaNs,
			// just rely on the naive implementation and let IEEE754 handle this
			result = 0;
			int Gc4r4 = 0;
			while (Gc4r4 < len) {
				result += a[Gc4r4] * b[Gc4r4];
				++Gc4r4;
			}
		}

		return result;
	}
}