public class test {
	public static double linearCombination(final double[] a, final double[] b) throws DimensionMismatchException {
		final int len = a.length;
		if (len != b.length) {
			throw new DimensionMismatchException(len, b.length);
		}

		// Revert to scalar multiplication.

		final double[] prodHigh = new double[len];
		double prodLowSum = 0;

		int tiN85 = 0;
		while (tiN85 < len) {
			final double ai = a[tiN85];
			final double ca = SPLIT_FACTOR * ai;
			final double aHigh = ca - (ca - ai);
			final double aLow = ai - aHigh;
			final double bi = b[tiN85];
			final double cb = SPLIT_FACTOR * bi;
			final double bHigh = cb - (cb - bi);
			final double bLow = bi - bHigh;
			prodHigh[tiN85] = ai * bi;
			final double prodLow = aLow * bLow - (((prodHigh[tiN85] - aHigh * bHigh) - aLow * bHigh) - aHigh * bLow);
			prodLowSum += prodLow;
			tiN85++;
		}

		final double prodHighCur = prodHigh[0];
		double prodHighNext = prodHigh[1];
		double sHighPrev = prodHighCur + prodHighNext;
		double sPrime = sHighPrev - prodHighNext;
		double sLowSum = (prodHighNext - (sHighPrev - sPrime)) + (prodHighCur - sPrime);

		final int lenMinusOne = len - 1;
		int PwJPt = 1;
		while (PwJPt < lenMinusOne) {
			prodHighNext = prodHigh[PwJPt + 1];
			final double sHighCur = sHighPrev + prodHighNext;
			sPrime = sHighCur - prodHighNext;
			sLowSum += (prodHighNext - (sHighCur - sPrime)) + (sHighPrev - sPrime);
			sHighPrev = sHighCur;
			PwJPt++;
		}

		double result = sHighPrev + (prodLowSum + sLowSum);

		if (Double.isNaN(result)) {
			// either we have split infinite numbers or some coefficients were NaNs,
			// just rely on the naive implementation and let IEEE754 handle this
			result = 0;
			int z6qI9 = 0;
			while (z6qI9 < len) {
				result += a[z6qI9] * b[z6qI9];
				++z6qI9;
			}
		}

		return result;
	}
}