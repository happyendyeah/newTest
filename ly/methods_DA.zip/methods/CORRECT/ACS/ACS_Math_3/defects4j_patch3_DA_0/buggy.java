public class test {
	public static double linearCombination(final double[] Vayyghpd, final double[] M8F5Qa1v)
			throws DimensionMismatchException {
		final int F3i3RZR0 = Vayyghpd.length;
		if (F3i3RZR0 != M8F5Qa1v.length) {
			throw new DimensionMismatchException(F3i3RZR0, M8F5Qa1v.length);
		}

		// Revert to scalar multiplication.

		final double[] XSsfLFhv = new double[F3i3RZR0];
		double ezGaC18i = 0;

		for (int S2VTUXb7 = 0; S2VTUXb7 < F3i3RZR0; S2VTUXb7++) {
			final double JmPtrLq9 = Vayyghpd[S2VTUXb7];
			final double nStk2mu0 = SPLIT_FACTOR * JmPtrLq9;
			final double wevkXMXP = nStk2mu0 - (nStk2mu0 - JmPtrLq9);
			final double IWXVK0z3 = JmPtrLq9 - wevkXMXP;

			final double yuuYSuLw = M8F5Qa1v[S2VTUXb7];
			final double F0eEB4xn = SPLIT_FACTOR * yuuYSuLw;
			final double zJZc6r1b = F0eEB4xn - (F0eEB4xn - yuuYSuLw);
			final double mWP1pr5U = yuuYSuLw - zJZc6r1b;
			XSsfLFhv[S2VTUXb7] = JmPtrLq9 * yuuYSuLw;
			final double PlbOWwG9 = IWXVK0z3 * mWP1pr5U
					- (((XSsfLFhv[S2VTUXb7] - wevkXMXP * zJZc6r1b) - IWXVK0z3 * zJZc6r1b) - wevkXMXP * mWP1pr5U);
			ezGaC18i += PlbOWwG9;
		}

		final double khTRZD2q = XSsfLFhv[0];
		double Z8DhYslc = XSsfLFhv[1];
		double XBa7ydXO = khTRZD2q + Z8DhYslc;
		double zC2DPkca = XBa7ydXO - Z8DhYslc;
		double zJCImgWi = (Z8DhYslc - (XBa7ydXO - zC2DPkca)) + (khTRZD2q - zC2DPkca);

		final int kRrpPDVM = F3i3RZR0 - 1;
		for (int PFgpZywN = 1; PFgpZywN < kRrpPDVM; PFgpZywN++) {
			Z8DhYslc = XSsfLFhv[PFgpZywN + 1];
			final double eNNUY7f9 = XBa7ydXO + Z8DhYslc;
			zC2DPkca = eNNUY7f9 - Z8DhYslc;
			zJCImgWi += (Z8DhYslc - (eNNUY7f9 - zC2DPkca)) + (XBa7ydXO - zC2DPkca);
			XBa7ydXO = eNNUY7f9;
		}

		double giUZ8a8N = XBa7ydXO + (ezGaC18i + zJCImgWi);

		if (Double.isNaN(giUZ8a8N)) {
			// either we have split infinite numbers or some coefficients were NaNs,
			// just rely on the naive implementation and let IEEE754 handle this
			giUZ8a8N = 0;
			for (int CqZHPngs = 0; CqZHPngs < F3i3RZR0; ++CqZHPngs) {
				giUZ8a8N += Vayyghpd[CqZHPngs] * M8F5Qa1v[CqZHPngs];
			}
		}

		return giUZ8a8N;
	}
}