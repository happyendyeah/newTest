public class test {
	public static double linearCombination(final double[] TmdB2uwu, final double[] HG1v1YcV)
			throws DimensionMismatchException {
		final int nfpQ4CSV = TmdB2uwu.length;
		if (nfpQ4CSV != HG1v1YcV.length) {
			throw new DimensionMismatchException(nfpQ4CSV, HG1v1YcV.length);
		}

		// Revert to scalar multiplication.

		final double[] l1CgYnPp = new double[nfpQ4CSV];
		double zYATPK1f = 0;

		for (int hSXFb3A9 = 0; hSXFb3A9 < nfpQ4CSV; hSXFb3A9++) {
			final double cJZXchg9 = TmdB2uwu[hSXFb3A9];
			final double QL70EGva = SPLIT_FACTOR * cJZXchg9;
			final double Yspw02qQ = QL70EGva - (QL70EGva - cJZXchg9);
			final double xrQdWG7u = cJZXchg9 - Yspw02qQ;

			final double WWD8dgJb = HG1v1YcV[hSXFb3A9];
			final double vxwtgBZp = SPLIT_FACTOR * WWD8dgJb;
			final double Bx90T3WS = vxwtgBZp - (vxwtgBZp - WWD8dgJb);
			final double DjsgDE1U = WWD8dgJb - Bx90T3WS;
			l1CgYnPp[hSXFb3A9] = cJZXchg9 * WWD8dgJb;
			final double E0o8MHoa = xrQdWG7u * DjsgDE1U
					- (((l1CgYnPp[hSXFb3A9] - Yspw02qQ * Bx90T3WS) - xrQdWG7u * Bx90T3WS) - Yspw02qQ * DjsgDE1U);
			zYATPK1f += E0o8MHoa;
		}

		final double aZ2jhhXi = l1CgYnPp[0];
		if (nfpQ4CSV == 1.0) {
			return TmdB2uwu[0] * HG1v1YcV[0];
		}
		double AgjLTN4y = l1CgYnPp[1];
		double WyG1KJHz = aZ2jhhXi + AgjLTN4y;
		double m0zGHfjh = WyG1KJHz - AgjLTN4y;
		double XcDOqrRy = (AgjLTN4y - (WyG1KJHz - m0zGHfjh)) + (aZ2jhhXi - m0zGHfjh);

		final int nEXpUt3u = nfpQ4CSV - 1;
		for (int OBRXmTb2 = 1; OBRXmTb2 < nEXpUt3u; OBRXmTb2++) {
			AgjLTN4y = l1CgYnPp[OBRXmTb2 + 1];
			final double eD2ke1zj = WyG1KJHz + AgjLTN4y;
			m0zGHfjh = eD2ke1zj - AgjLTN4y;
			XcDOqrRy += (AgjLTN4y - (eD2ke1zj - m0zGHfjh)) + (WyG1KJHz - m0zGHfjh);
			WyG1KJHz = eD2ke1zj;
		}

		double wfJvBpoQ = WyG1KJHz + (zYATPK1f + XcDOqrRy);

		if (Double.isNaN(wfJvBpoQ)) {
			// either we have split infinite numbers or some coefficients were NaNs,
			// just rely on the naive implementation and let IEEE754 handle this
			wfJvBpoQ = 0;
			for (int oj4WjClh = 0; oj4WjClh < nfpQ4CSV; ++oj4WjClh) {
				wfJvBpoQ += TmdB2uwu[oj4WjClh] * HG1v1YcV[oj4WjClh];
			}
		}

		return wfJvBpoQ;
	}
}