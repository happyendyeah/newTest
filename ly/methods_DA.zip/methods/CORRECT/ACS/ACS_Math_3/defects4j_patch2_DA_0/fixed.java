public class test {
	public static double linearCombination(final double[] c2eHhFpw, final double[] BpfTkyfn)
			throws DimensionMismatchException {
		final int tf8qsW7c = c2eHhFpw.length;
		if (tf8qsW7c != BpfTkyfn.length) {
			throw new DimensionMismatchException(tf8qsW7c, BpfTkyfn.length);
		}

		// Revert to scalar multiplication.

		final double[] GJ0hTc3C = new double[tf8qsW7c];
		double Hq4Nupz2 = 0;

		for (int HBTFkrgr = 0; HBTFkrgr < tf8qsW7c; HBTFkrgr++) {
			final double MHw2Fz3v = c2eHhFpw[HBTFkrgr];
			final double rLLDApds = SPLIT_FACTOR * MHw2Fz3v;
			final double rTSxKpqO = rLLDApds - (rLLDApds - MHw2Fz3v);
			final double LCrS7eF7 = MHw2Fz3v - rTSxKpqO;

			final double Z1MbOoAL = BpfTkyfn[HBTFkrgr];
			final double TCnr4JEE = SPLIT_FACTOR * Z1MbOoAL;
			final double sLJNc5ug = TCnr4JEE - (TCnr4JEE - Z1MbOoAL);
			final double W0pNZzoV = Z1MbOoAL - sLJNc5ug;
			GJ0hTc3C[HBTFkrgr] = MHw2Fz3v * Z1MbOoAL;
			final double SkyyxVxJ = LCrS7eF7 * W0pNZzoV
					- (((GJ0hTc3C[HBTFkrgr] - rTSxKpqO * sLJNc5ug) - LCrS7eF7 * sLJNc5ug) - rTSxKpqO * W0pNZzoV);
			Hq4Nupz2 += SkyyxVxJ;
		}

		final double TXTPYYCV = GJ0hTc3C[0];
		if (tf8qsW7c == 1.0) {
			return c2eHhFpw[0] * BpfTkyfn[0];
		}
		double IoSlhNh1 = GJ0hTc3C[1];
		double ddT3PXkI = TXTPYYCV + IoSlhNh1;
		double ayL2KxfV = ddT3PXkI - IoSlhNh1;
		double yHQLEh2H = (IoSlhNh1 - (ddT3PXkI - ayL2KxfV)) + (TXTPYYCV - ayL2KxfV);

		final int T1fX2Agr = tf8qsW7c - 1;
		for (int NYtUYiWq = 1; NYtUYiWq < T1fX2Agr; NYtUYiWq++) {
			IoSlhNh1 = GJ0hTc3C[NYtUYiWq + 1];
			final double BUaF1bBu = ddT3PXkI + IoSlhNh1;
			ayL2KxfV = BUaF1bBu - IoSlhNh1;
			yHQLEh2H += (IoSlhNh1 - (BUaF1bBu - ayL2KxfV)) + (ddT3PXkI - ayL2KxfV);
			ddT3PXkI = BUaF1bBu;
		}

		double PvpK1opA = ddT3PXkI + (Hq4Nupz2 + yHQLEh2H);

		if (Double.isNaN(PvpK1opA)) {
			// either we have split infinite numbers or some coefficients were NaNs,
			// just rely on the naive implementation and let IEEE754 handle this
			PvpK1opA = 0;
			for (int jlOlEOeu = 0; jlOlEOeu < tf8qsW7c; ++jlOlEOeu) {
				PvpK1opA += c2eHhFpw[jlOlEOeu] * BpfTkyfn[jlOlEOeu];
			}
		}

		return PvpK1opA;
	}
}