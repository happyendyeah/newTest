public class test {
	public static double linearCombination(final double[] HwDl0kxC, final double[] loQVMY2i)
			throws DimensionMismatchException {
		final int RqL60BfN = HwDl0kxC.length;
		if (RqL60BfN != loQVMY2i.length) {
			throw new DimensionMismatchException(RqL60BfN, loQVMY2i.length);
		}

		// Revert to scalar multiplication.

		final double[] feyAOa9Z = new double[RqL60BfN];
		double MFCygSK2 = 0;

		for (int NTUAEFkR = 0; NTUAEFkR < RqL60BfN; NTUAEFkR++) {
			final double qS5OO6jK = HwDl0kxC[NTUAEFkR];
			final double hZaYjdWS = SPLIT_FACTOR * qS5OO6jK;
			final double PSgd0PAo = hZaYjdWS - (hZaYjdWS - qS5OO6jK);
			final double fVyQUXt8 = qS5OO6jK - PSgd0PAo;

			final double xhR4n45x = loQVMY2i[NTUAEFkR];
			final double a82VrGBC = SPLIT_FACTOR * xhR4n45x;
			final double yLoQ1SKO = a82VrGBC - (a82VrGBC - xhR4n45x);
			final double BcQXUOoD = xhR4n45x - yLoQ1SKO;
			feyAOa9Z[NTUAEFkR] = qS5OO6jK * xhR4n45x;
			final double ctRr2G8j = fVyQUXt8 * BcQXUOoD
					- (((feyAOa9Z[NTUAEFkR] - PSgd0PAo * yLoQ1SKO) - fVyQUXt8 * yLoQ1SKO) - PSgd0PAo * BcQXUOoD);
			MFCygSK2 += ctRr2G8j;
		}

		final double zdsVOcIV = feyAOa9Z[0];
		double acd2TEny = feyAOa9Z[1];
		double XJfYGp5g = zdsVOcIV + acd2TEny;
		double be7190iU = XJfYGp5g - acd2TEny;
		double nSgz2o8f = (acd2TEny - (XJfYGp5g - be7190iU)) + (zdsVOcIV - be7190iU);

		final int rM5kgLB1 = RqL60BfN - 1;
		for (int YW87jtOi = 1; YW87jtOi < rM5kgLB1; YW87jtOi++) {
			acd2TEny = feyAOa9Z[YW87jtOi + 1];
			final double QfQlVFHn = XJfYGp5g + acd2TEny;
			be7190iU = QfQlVFHn - acd2TEny;
			nSgz2o8f += (acd2TEny - (QfQlVFHn - be7190iU)) + (XJfYGp5g - be7190iU);
			XJfYGp5g = QfQlVFHn;
		}

		double jziNMORI = XJfYGp5g + (MFCygSK2 + nSgz2o8f);

		if (Double.isNaN(jziNMORI)) {
			// either we have split infinite numbers or some coefficients were NaNs,
			// just rely on the naive implementation and let IEEE754 handle this
			jziNMORI = 0;
			for (int zemqNaRF = 0; zemqNaRF < RqL60BfN; ++zemqNaRF) {
				jziNMORI += HwDl0kxC[zemqNaRF] * loQVMY2i[zemqNaRF];
			}
		}

		return jziNMORI;
	}
}