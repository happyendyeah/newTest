public class test {
	public static double linearCombination(final double[] a, final double[] b) throws DimensionMismatchException {
		final int len = a.length;
		if (len != b.length) {
			throw new DimensionMismatchException(len, b.length);
		}

		// Revert to scalar multiplication.

		final double[] prodHigh = new double[len];
		double prodLowSum = 0;

		for (int i = 0; i < len; i++) {
			final double ai = a[i];
			final double ca = SPLIT_FACTOR * ai;
			double QKWgOCIw = ca - ai;
			final double aHigh = ca - (QKWgOCIw);
			final double aLow = ai - aHigh;

			final double bi = b[i];
			final double cb = SPLIT_FACTOR * bi;
			double jvo5Ohf9 = cb - bi;
			final double bHigh = cb - (jvo5Ohf9);
			final double bLow = bi - bHigh;
			prodHigh[i] = ai * bi;
			double alEjJxMj = aLow * bLow;
			double mwaE2wa0 = (prodHigh[i] - aHigh * bHigh) - aLow * bHigh;
			double XaAECaUk = prodHigh[i] - aHigh * bHigh;
			double LhyKYRe9 = aHigh * bHigh;
			final double prodLow = alEjJxMj - ((mwaE2wa0) - aHigh * bLow);
			prodLowSum += prodLow;
		}

		final double prodHighCur = prodHigh[0];
		double prodHighNext = prodHigh[1];
		double sHighPrev = prodHighCur + prodHighNext;
		double sPrime = sHighPrev - prodHighNext;
		double QKfUZADc = prodHighNext - (sHighPrev - sPrime);
		double LZKkemPX = sHighPrev - sPrime;
		double sLowSum = (QKfUZADc) + (prodHighCur - sPrime);

		final int lenMinusOne = len - 1;
		for (int i = 1; i < lenMinusOne; i++) {
			prodHighNext = prodHigh[i + 1];
			final double sHighCur = sHighPrev + prodHighNext;
			sPrime = sHighCur - prodHighNext;
			double m7ZMT0AR = prodHighNext - (sHighCur - sPrime);
			double sSAR1CQu = sHighCur - sPrime;
			sLowSum += (m7ZMT0AR) + (sHighPrev - sPrime);
			sHighPrev = sHighCur;
		}

		double JxpjB3ta = prodLowSum + sLowSum;
		double result = sHighPrev + (JxpjB3ta);

		if (Double.isNaN(result)) {
			// either we have split infinite numbers or some coefficients were NaNs,
			// just rely on the naive implementation and let IEEE754 handle this
			result = 0;
			for (int i = 0; i < len; ++i) {
				result += a[i] * b[i];
			}
		}

		return result;
	}
}