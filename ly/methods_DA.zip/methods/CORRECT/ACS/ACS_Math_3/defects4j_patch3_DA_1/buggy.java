public class test {
	public static double linearCombination(final double[] a, final double[] b) throws DimensionMismatchException {
		final int len = a.length;
		if (len != b.length) {
			throw new DimensionMismatchException(len, b.length);
		}

		// Revert to scalar multiplication.

		final double[] prodHigh = new double[len];
		double prodLowSum = 0;

		int pDPsJ = 0;
		while (pDPsJ < len) {
			final double ai = a[pDPsJ];
			final double ca = SPLIT_FACTOR * ai;
			final double aHigh = ca - (ca - ai);
			final double aLow = ai - aHigh;
			final double bi = b[pDPsJ];
			final double cb = SPLIT_FACTOR * bi;
			final double bHigh = cb - (cb - bi);
			final double bLow = bi - bHigh;
			prodHigh[pDPsJ] = ai * bi;
			final double prodLow = aLow * bLow - (((prodHigh[pDPsJ] - aHigh * bHigh) - aLow * bHigh) - aHigh * bLow);
			prodLowSum += prodLow;
			pDPsJ++;
		}

		final double prodHighCur = prodHigh[0];
		double prodHighNext = prodHigh[1];
		double sHighPrev = prodHighCur + prodHighNext;
		double sPrime = sHighPrev - prodHighNext;
		double sLowSum = (prodHighNext - (sHighPrev - sPrime)) + (prodHighCur - sPrime);

		final int lenMinusOne = len - 1;
		int rOE1y = 1;
		while (rOE1y < lenMinusOne) {
			prodHighNext = prodHigh[rOE1y + 1];
			final double sHighCur = sHighPrev + prodHighNext;
			sPrime = sHighCur - prodHighNext;
			sLowSum += (prodHighNext - (sHighCur - sPrime)) + (sHighPrev - sPrime);
			sHighPrev = sHighCur;
			rOE1y++;
		}

		double result = sHighPrev + (prodLowSum + sLowSum);

		if (Double.isNaN(result)) {
			// either we have split infinite numbers or some coefficients were NaNs,
			// just rely on the naive implementation and let IEEE754 handle this
			result = 0;
			int S0s5u = 0;
			while (S0s5u < len) {
				result += a[S0s5u] * b[S0s5u];
				++S0s5u;
			}
		}

		return result;
	}
}