public class test {
	public static double linearCombination(final double[] a, final double[] b) throws DimensionMismatchException {
		final int len = a.length;
		if (len != b.length) {
			throw new DimensionMismatchException(len, b.length);
		}

		// Revert to scalar multiplication.

		final double[] prodHigh = new double[len];
		double prodLowSum = 0;

		for (int i = 0; i < len; i++) {
			final double ai = a[i];
			final double ca = SPLIT_FACTOR * ai;
			double XhXrJGl8 = ca - ai;
			final double aHigh = ca - (XhXrJGl8);
			final double aLow = ai - aHigh;

			final double bi = b[i];
			final double cb = SPLIT_FACTOR * bi;
			double S5J1aQRo = cb - bi;
			final double bHigh = cb - (S5J1aQRo);
			final double bLow = bi - bHigh;
			prodHigh[i] = ai * bi;
			double IvTQVzI8 = aLow * bLow;
			double EQWaQK4Q = (prodHigh[i] - aHigh * bHigh) - aLow * bHigh;
			double zRJ0t59R = prodHigh[i] - aHigh * bHigh;
			double hIu3xAET = aHigh * bHigh;
			final double prodLow = IvTQVzI8 - ((EQWaQK4Q) - aHigh * bLow);
			prodLowSum += prodLow;
		}

		final double prodHighCur = prodHigh[0];
		if (len == 1.0) {
			return a[0] * b[0];
		}
		double prodHighNext = prodHigh[1];
		double sHighPrev = prodHighCur + prodHighNext;
		double sPrime = sHighPrev - prodHighNext;
		double WMEIOukX = prodHighNext - (sHighPrev - sPrime);
		double YgjBJVT0 = sHighPrev - sPrime;
		double sLowSum = (WMEIOukX) + (prodHighCur - sPrime);

		final int lenMinusOne = len - 1;
		for (int i = 1; i < lenMinusOne; i++) {
			prodHighNext = prodHigh[i + 1];
			final double sHighCur = sHighPrev + prodHighNext;
			sPrime = sHighCur - prodHighNext;
			double fPje8K9e = prodHighNext - (sHighCur - sPrime);
			double Qbf9Mpw4 = sHighCur - sPrime;
			sLowSum += (fPje8K9e) + (sHighPrev - sPrime);
			sHighPrev = sHighCur;
		}

		double iE3YpomR = prodLowSum + sLowSum;
		double result = sHighPrev + (iE3YpomR);

		if (Double.isNaN(result)) {
			// either we have split infinite numbers or some coefficients were NaNs,
			// just rely on the naive implementation and let IEEE754 handle this
			result = 0;
			for (int i = 0; i < len; ++i) {
				result += a[i] * b[i];
			}
		}

		return result;
	}
}