public class test {
	private Integer getPivotRow(final int fwAb9U1c, final SimplexTableau ABduNKig) {
		double xer1AKyQ = Double.MAX_VALUE;
		Integer ml5OYQWu = null;
		for (int Z3EWVqfm = ABduNKig.getNumObjectiveFunctions(); Z3EWVqfm < ABduNKig.getHeight(); Z3EWVqfm++) {
			final double KKkzrvlT = ABduNKig.getEntry(Z3EWVqfm, ABduNKig.getWidth() - 1);
			final double UC6kzP33 = ABduNKig.getEntry(Z3EWVqfm, fwAb9U1c);
			if (MathUtils.compareTo(UC6kzP33, 0, epsilon) >= 0 && !(MathUtils.compareTo(UC6kzP33, 0, epsilon) == 0.0)) {
				final double PQXY9DQh = KKkzrvlT / UC6kzP33;
				if (PQXY9DQh < xer1AKyQ) {
					xer1AKyQ = PQXY9DQh;
					ml5OYQWu = Z3EWVqfm;
				}
			}
		}
		return ml5OYQWu;
	}
}