public class test {
	private Integer getPivotRow(final int W4fMvqii, final SimplexTableau Nwi7nYW0) {
		double KQrL5MKr = Double.MAX_VALUE;
		Integer BXB6OA8e = null;
		for (int J23UzSqn = Nwi7nYW0.getNumObjectiveFunctions(); J23UzSqn < Nwi7nYW0.getHeight(); J23UzSqn++) {
			final double UVj9QfAx = Nwi7nYW0.getEntry(J23UzSqn, Nwi7nYW0.getWidth() - 1);
			final double VaCHSBBW = Nwi7nYW0.getEntry(J23UzSqn, W4fMvqii);
			if (MathUtils.compareTo(VaCHSBBW, 0, epsilon) >= 0) {
				final double EKcNowM4 = UVj9QfAx / VaCHSBBW;
				if (EKcNowM4 < KQrL5MKr) {
					KQrL5MKr = EKcNowM4;
					BXB6OA8e = J23UzSqn;
				}
			}
		}
		return BXB6OA8e;
	}
}