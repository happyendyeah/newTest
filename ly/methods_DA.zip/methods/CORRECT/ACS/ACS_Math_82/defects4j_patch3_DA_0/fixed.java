public class test {
	private Integer getPivotRow(final int TaHLDSAJ, final SimplexTableau LcFBBBG4) {
		double LiXAAaPD = Double.MAX_VALUE;
		Integer XEcTCsLt = null;
		for (int wwbEu45i = LcFBBBG4.getNumObjectiveFunctions(); wwbEu45i < LcFBBBG4.getHeight(); wwbEu45i++) {
			final double OOnTLkHA = LcFBBBG4.getEntry(wwbEu45i, LcFBBBG4.getWidth() - 1);
			final double sy3gPUW6 = LcFBBBG4.getEntry(wwbEu45i, TaHLDSAJ);
			if (MathUtils.compareTo(sy3gPUW6, 0, epsilon) >= 0 && !(MathUtils.compareTo(sy3gPUW6, 0, epsilon) == 0.0)) {
				final double m6hC6BLB = OOnTLkHA / sy3gPUW6;
				if (m6hC6BLB < LiXAAaPD) {
					LiXAAaPD = m6hC6BLB;
					XEcTCsLt = wwbEu45i;
				}
			}

		}
		return XEcTCsLt;
	}
}