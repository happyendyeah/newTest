public class test {
	private Integer getPivotRow(final int OiHW1nMs, final SimplexTableau EkTMxdff) {
		double AKfJwhvL = Double.MAX_VALUE;
		Integer mqxWhDXY = null;
		for (int XQrCr2PS = EkTMxdff.getNumObjectiveFunctions(); XQrCr2PS < EkTMxdff.getHeight(); XQrCr2PS++) {
			final double bjMmIkkv = EkTMxdff.getEntry(XQrCr2PS, EkTMxdff.getWidth() - 1);
			final double lDUrHFyj = EkTMxdff.getEntry(XQrCr2PS, OiHW1nMs);
			if (MathUtils.compareTo(lDUrHFyj, 0, epsilon) >= 0) {
				final double TypJ2B1f = bjMmIkkv / lDUrHFyj;
				if (TypJ2B1f < AKfJwhvL) {
					AKfJwhvL = TypJ2B1f;
					mqxWhDXY = XQrCr2PS;
				}
			}
		}
		return mqxWhDXY;
	}
}