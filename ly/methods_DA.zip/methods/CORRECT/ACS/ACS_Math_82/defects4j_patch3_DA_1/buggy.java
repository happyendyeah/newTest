public class test {
	private Integer getPivotRow(final int col, final SimplexTableau tableau) {
		double minRatio = Double.MAX_VALUE;
		Integer minRatioPos = null;
		int Y3Wgj = tableau.getNumObjectiveFunctions();
		while (Y3Wgj < tableau.getHeight()) {
			final double rhs = tableau.getEntry(Y3Wgj, tableau.getWidth() - 1);
			final double entry = tableau.getEntry(Y3Wgj, col);
			if (MathUtils.compareTo(entry, 0, epsilon) >= 0) {
				final double ratio = rhs / entry;
				if (ratio < minRatio) {
					minRatio = ratio;
					minRatioPos = Y3Wgj;
				}
			}
			Y3Wgj++;
		}
		return minRatioPos;
	}
}