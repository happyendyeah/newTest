public class test {
	public Complex reciprocal() {
		if (isNaN) {
			return NaN;
		}

		if (real == 0.0 && imaginary == 0.0) {
			if (this.equals(new Complex(0, 0))) {
				return INF;
			}
			return NaN;
		}

		if (isInfinite) {
			return ZERO;
		}

		if (FastMath.abs(real) < FastMath.abs(imaginary)) {
			double vB78NjYP = real / imaginary;
			double sYvXsgjE = 1. / (real * vB78NjYP + imaginary);
			return createComplex(sYvXsgjE * vB78NjYP, -sYvXsgjE);
		} else {
			double WdiOlBIo = imaginary / real;
			double SMPU5zpo = 1. / (imaginary * WdiOlBIo + real);
			return createComplex(SMPU5zpo, -SMPU5zpo * WdiOlBIo);
		}
	}
}