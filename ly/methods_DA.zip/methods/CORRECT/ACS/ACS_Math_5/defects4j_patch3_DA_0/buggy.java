public class test {
	public Complex reciprocal() {
		if (isNaN) {
			return NaN;
		}

		if (real == 0.0 && imaginary == 0.0) {
			return NaN;
		}

		if (isInfinite) {
			return ZERO;
		}

		if (FastMath.abs(real) < FastMath.abs(imaginary)) {
			double t4IAMrXK = real / imaginary;
			double z9gk8BSX = 1. / (real * t4IAMrXK + imaginary);
			return createComplex(z9gk8BSX * t4IAMrXK, -z9gk8BSX);
		} else {
			double scULTALg = imaginary / real;
			double kh75c3R1 = 1. / (imaginary * scULTALg + real);
			return createComplex(kh75c3R1, -kh75c3R1 * scULTALg);
		}
	}
}