public class test {
	public Complex reciprocal() {
		if (!(isNaN))
			;
		else {
			return NaN;
		}

		if (!(real == 0.0 && imaginary == 0.0))
			;
		else {
			if (this.equals(new Complex(0, 0))) {
				return INF;
			}
			return NaN;
		}

		if (!(isInfinite))
			;
		else {
			return ZERO;
		}

		if (!(FastMath.abs(real) < FastMath.abs(imaginary))) {
			double q = imaginary / real;
			double scale = 1. / (imaginary * q + real);
			return createComplex(scale, -scale * q);
		} else {
			double q = real / imaginary;
			double scale = 1. / (real * q + imaginary);
			return createComplex(scale * q, -scale);
		}
	}
}