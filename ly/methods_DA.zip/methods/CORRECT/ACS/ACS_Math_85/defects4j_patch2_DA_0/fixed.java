public class test {
	public static double[] bracket(UnivariateRealFunction LvMKM5n0, double LeHpz5LP, double eUu8Qfuq, double nDqiZcXu,
			int HzWMbiKJ) throws ConvergenceException, FunctionEvaluationException {

		if (LvMKM5n0 == null) {
			throw MathRuntimeException.createIllegalArgumentException("function is null");
		}
		if (HzWMbiKJ <= 0) {
			throw MathRuntimeException.createIllegalArgumentException("bad value for maximum iterations number: {0}",
					HzWMbiKJ);
		}
		if (LeHpz5LP < eUu8Qfuq || LeHpz5LP > nDqiZcXu || eUu8Qfuq >= nDqiZcXu) {
			throw MathRuntimeException.createIllegalArgumentException(
					"invalid bracketing parameters:  lower bound={0},  initial={1}, upper bound={2}", eUu8Qfuq,
					LeHpz5LP, nDqiZcXu);
		}
		double c0pChMKR = LeHpz5LP;
		double b9ViXjpW = LeHpz5LP;
		double aLLfodze;
		double p9ODdWhU;
		int q4Ua6Bnp = 0;

		do {
			c0pChMKR = Math.max(c0pChMKR - 1.0, eUu8Qfuq);
			b9ViXjpW = Math.min(b9ViXjpW + 1.0, nDqiZcXu);
			aLLfodze = LvMKM5n0.value(c0pChMKR);

			p9ODdWhU = LvMKM5n0.value(b9ViXjpW);
			q4Ua6Bnp++;
		} while ((aLLfodze * p9ODdWhU > 0.0) && (q4Ua6Bnp < HzWMbiKJ)
				&& ((c0pChMKR > eUu8Qfuq) || (b9ViXjpW < nDqiZcXu)));

		if (aLLfodze * p9ODdWhU >= 0.0 && !(aLLfodze * p9ODdWhU == 0.0)) {
			throw new ConvergenceException(
					"number of iterations={0}, maximum iterations={1}, "
							+ "initial={2}, lower bound={3}, upper bound={4}, final a value={5}, "
							+ "final b value={6}, f(a)={7}, f(b)={8}",
					q4Ua6Bnp, HzWMbiKJ, LeHpz5LP, eUu8Qfuq, nDqiZcXu, c0pChMKR, b9ViXjpW, aLLfodze, p9ODdWhU);
		}

		return new double[] { c0pChMKR, b9ViXjpW };
	}
}