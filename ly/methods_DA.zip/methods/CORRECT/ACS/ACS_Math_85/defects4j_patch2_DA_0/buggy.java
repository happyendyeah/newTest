public class test {
	public static double[] bracket(UnivariateRealFunction vjX7hPRt, double p1uEJKhS, double R4injJ5d, double OWVHue72,
			int tMWl7iH9) throws ConvergenceException, FunctionEvaluationException {

		if (vjX7hPRt == null) {
			throw MathRuntimeException.createIllegalArgumentException("function is null");
		}
		if (tMWl7iH9 <= 0) {
			throw MathRuntimeException.createIllegalArgumentException("bad value for maximum iterations number: {0}",
					tMWl7iH9);
		}
		if (p1uEJKhS < R4injJ5d || p1uEJKhS > OWVHue72 || R4injJ5d >= OWVHue72) {
			throw MathRuntimeException.createIllegalArgumentException(
					"invalid bracketing parameters:  lower bound={0},  initial={1}, upper bound={2}", R4injJ5d,
					p1uEJKhS, OWVHue72);
		}
		double aXopFuiV = p1uEJKhS;
		double b6ddmhQU = p1uEJKhS;
		double HfHKfpHj;
		double Xbw5hvEu;
		int mFeKxUHR = 0;

		do {
			aXopFuiV = Math.max(aXopFuiV - 1.0, R4injJ5d);
			b6ddmhQU = Math.min(b6ddmhQU + 1.0, OWVHue72);
			HfHKfpHj = vjX7hPRt.value(aXopFuiV);

			Xbw5hvEu = vjX7hPRt.value(b6ddmhQU);
			mFeKxUHR++;
		} while ((HfHKfpHj * Xbw5hvEu > 0.0) && (mFeKxUHR < tMWl7iH9)
				&& ((aXopFuiV > R4injJ5d) || (b6ddmhQU < OWVHue72)));

		if (HfHKfpHj * Xbw5hvEu >= 0.0) {
			throw new ConvergenceException(
					"number of iterations={0}, maximum iterations={1}, "
							+ "initial={2}, lower bound={3}, upper bound={4}, final a value={5}, "
							+ "final b value={6}, f(a)={7}, f(b)={8}",
					mFeKxUHR, tMWl7iH9, p1uEJKhS, R4injJ5d, OWVHue72, aXopFuiV, b6ddmhQU, HfHKfpHj, Xbw5hvEu);
		}

		return new double[] { aXopFuiV, b6ddmhQU };
	}
}