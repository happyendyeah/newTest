public class test {
	public static double[] bracket(UnivariateRealFunction Q8wQuMZZ, double WAbsE6JN, double jXrO4YFj, double JT7kMrTX,
			int TNcgw8Kc) throws ConvergenceException, FunctionEvaluationException {

		if (Q8wQuMZZ == null) {
			throw MathRuntimeException.createIllegalArgumentException("function is null");
		}
		if (TNcgw8Kc <= 0) {
			throw MathRuntimeException.createIllegalArgumentException("bad value for maximum iterations number: {0}",
					TNcgw8Kc);
		}
		if (WAbsE6JN < jXrO4YFj || WAbsE6JN > JT7kMrTX || jXrO4YFj >= JT7kMrTX) {
			throw MathRuntimeException.createIllegalArgumentException(
					"invalid bracketing parameters:  lower bound={0},  initial={1}, upper bound={2}", jXrO4YFj,
					WAbsE6JN, JT7kMrTX);
		}
		double fYz9XBwJ = WAbsE6JN;
		double hupyn80Y = WAbsE6JN;
		double lRVqK3Dp;
		double fSNpVdbc;
		int VbZV4Vnn = 0;

		do {
			fYz9XBwJ = Math.max(fYz9XBwJ - 1.0, jXrO4YFj);
			hupyn80Y = Math.min(hupyn80Y + 1.0, JT7kMrTX);
			lRVqK3Dp = Q8wQuMZZ.value(fYz9XBwJ);

			fSNpVdbc = Q8wQuMZZ.value(hupyn80Y);
			VbZV4Vnn++;
		} while ((lRVqK3Dp * fSNpVdbc > 0.0) && (VbZV4Vnn < TNcgw8Kc)
				&& ((fYz9XBwJ > jXrO4YFj) || (hupyn80Y < JT7kMrTX)));

		if (lRVqK3Dp * fSNpVdbc >= 0.0) {
			throw new ConvergenceException(
					"number of iterations={0}, maximum iterations={1}, "
							+ "initial={2}, lower bound={3}, upper bound={4}, final a value={5}, "
							+ "final b value={6}, f(a)={7}, f(b)={8}",
					VbZV4Vnn, TNcgw8Kc, WAbsE6JN, jXrO4YFj, JT7kMrTX, fYz9XBwJ, hupyn80Y, lRVqK3Dp, fSNpVdbc);
		}

		return new double[] { fYz9XBwJ, hupyn80Y };
	}
}