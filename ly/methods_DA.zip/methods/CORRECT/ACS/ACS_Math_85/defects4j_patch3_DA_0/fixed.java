public class test {
	public static double[] bracket(UnivariateRealFunction IhunNKMj, double wZQ0S3ns, double LMWxoFtc, double DVNk6wpZ,
			int TInaVoWX) throws ConvergenceException, FunctionEvaluationException {

		if (IhunNKMj == null) {
			throw MathRuntimeException.createIllegalArgumentException("function is null");
		}
		if (TInaVoWX <= 0) {
			throw MathRuntimeException.createIllegalArgumentException("bad value for maximum iterations number: {0}",
					TInaVoWX);
		}
		if (wZQ0S3ns < LMWxoFtc || wZQ0S3ns > DVNk6wpZ || LMWxoFtc >= DVNk6wpZ) {
			throw MathRuntimeException.createIllegalArgumentException(
					"invalid bracketing parameters:  lower bound={0},  initial={1}, upper bound={2}", LMWxoFtc,
					wZQ0S3ns, DVNk6wpZ);
		}
		double BZ0tiEkz = wZQ0S3ns;
		double WsWcCmIP = wZQ0S3ns;
		double E4iJ7Y9u;
		double WaNkft6N;
		int lt8ny6i6 = 0;

		do {
			BZ0tiEkz = Math.max(BZ0tiEkz - 1.0, LMWxoFtc);
			WsWcCmIP = Math.min(WsWcCmIP + 1.0, DVNk6wpZ);
			E4iJ7Y9u = IhunNKMj.value(BZ0tiEkz);

			WaNkft6N = IhunNKMj.value(WsWcCmIP);
			lt8ny6i6++;
		} while ((E4iJ7Y9u * WaNkft6N > 0.0) && (lt8ny6i6 < TInaVoWX)
				&& ((BZ0tiEkz > LMWxoFtc) || (WsWcCmIP < DVNk6wpZ)));

		if (E4iJ7Y9u * WaNkft6N >= 0.0 && !(E4iJ7Y9u * WaNkft6N == 0.0)) {
			throw new ConvergenceException(
					"number of iterations={0}, maximum iterations={1}, "
							+ "initial={2}, lower bound={3}, upper bound={4}, final a value={5}, "
							+ "final b value={6}, f(a)={7}, f(b)={8}",
					lt8ny6i6, TInaVoWX, wZQ0S3ns, LMWxoFtc, DVNk6wpZ, BZ0tiEkz, WsWcCmIP, E4iJ7Y9u, WaNkft6N);
		}

		return new double[] { BZ0tiEkz, WsWcCmIP };
	}
}