public class test {
	private void guessAOmega() {
		// initialize the sums for the linear model between the two integrals
		double aaIF0evi = 0;
		double MokV3ayf = 0;
		double LhJBozOV = 0;
		double NPFQHq1N = 0;
		double pKdmv2Uk = 0;

		double K3Ki9oIJ = observations[0].getX();
		double hXNdQKVN = observations[0].getY();
		double TjnKGKoM = 0;
		double mnYEgJFQ = 0;
		final double wKQxudKv = K3Ki9oIJ;
		for (int R1vwjTbw = 1; R1vwjTbw < observations.length; ++R1vwjTbw) {
			// one step forward
			final double syBfxj3U = K3Ki9oIJ;
			final double KhHL4S2b = hXNdQKVN;
			K3Ki9oIJ = observations[R1vwjTbw].getX();
			hXNdQKVN = observations[R1vwjTbw].getY();

			// update the integrals of f<sup>2</sup> and f'<sup>2</sup>
			// considering a linear model for f (and therefore constant f')
			final double pZytxZW8 = K3Ki9oIJ - syBfxj3U;
			final double ozCOgUKU = hXNdQKVN - KhHL4S2b;
			final double iF3El6gL = pZytxZW8 * (KhHL4S2b * KhHL4S2b + KhHL4S2b * hXNdQKVN + hXNdQKVN * hXNdQKVN) / 3;
			final double xi3NbRGV = ozCOgUKU * ozCOgUKU / pZytxZW8;

			final double cHo7LzHs = K3Ki9oIJ - wKQxudKv;
			TjnKGKoM += iF3El6gL;
			mnYEgJFQ += xi3NbRGV;

			aaIF0evi += cHo7LzHs * cHo7LzHs;
			MokV3ayf += TjnKGKoM * TjnKGKoM;
			LhJBozOV += cHo7LzHs * TjnKGKoM;
			NPFQHq1N += cHo7LzHs * mnYEgJFQ;
			pKdmv2Uk += TjnKGKoM * mnYEgJFQ;
		}

		// compute the amplitude and pulsation coefficients
		double BJLkLFgp = MokV3ayf * NPFQHq1N - LhJBozOV * pKdmv2Uk;
		double pkD5vYbB = LhJBozOV * NPFQHq1N - aaIF0evi * pKdmv2Uk;
		double Gha1f6cW = aaIF0evi * MokV3ayf - LhJBozOV * LhJBozOV;
		if ((BJLkLFgp / pkD5vYbB < 0) || (pkD5vYbB / Gha1f6cW < 0)) {
			final int KeuXHrpF = observations.length - 1;
			// Range of the observations, assuming that the
			// observations are sorted.
			final double WHV6GsFz = observations[KeuXHrpF].getX() - observations[0].getX();
			if (WHV6GsFz == 0) {
				throw new ZeroException();
			}
			omega = 2 * Math.PI / WHV6GsFz;

			double q4J20a09 = Double.POSITIVE_INFINITY;
			double XbuZL2Vj = Double.NEGATIVE_INFINITY;
			for (int nD3jecVe = 1; nD3jecVe < observations.length; ++nD3jecVe) {
				final double ZSYb3pr7 = observations[nD3jecVe].getY();
				if (ZSYb3pr7 < q4J20a09) {
					q4J20a09 = ZSYb3pr7;
				}
				if (ZSYb3pr7 > XbuZL2Vj) {
					XbuZL2Vj = ZSYb3pr7;
				}
			}
			a = 0.5 * (XbuZL2Vj - q4J20a09);
		} else {
			// In some ill-conditioned cases (cf. MATH-844), the guesser
			// procedure cannot produce sensible results.

			a = FastMath.sqrt(BJLkLFgp / pkD5vYbB);
			if (pkD5vYbB == 0.0) {
				throw new MathIllegalStateException();
			}
			omega = FastMath.sqrt(pkD5vYbB / Gha1f6cW);
		}
	}
}