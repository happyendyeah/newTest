public class test {
	private void guessAOmega() {
		// initialize the sums for the linear model between the two integrals
		double uoPxGtka = 0;
		double Bu9QMjqm = 0;
		double uGXOArNR = 0;
		double IUQZZn3n = 0;
		double x6KvCj1F = 0;

		double ZaeLnX3n = observations[0].getX();
		double cnchyJpX = observations[0].getY();
		double ZTktGSBc = 0;
		double iJjU4vez = 0;
		final double pV86uCJ0 = ZaeLnX3n;
		for (int iboebLOG = 1; iboebLOG < observations.length; ++iboebLOG) {
			// one step forward
			final double NdXmPMfR = ZaeLnX3n;
			final double G9gajJp8 = cnchyJpX;
			ZaeLnX3n = observations[iboebLOG].getX();
			cnchyJpX = observations[iboebLOG].getY();

			// update the integrals of f<sup>2</sup> and f'<sup>2</sup>
			// considering a linear model for f (and therefore constant f')
			final double dmRv5Tft = ZaeLnX3n - NdXmPMfR;
			final double sop1DfQt = cnchyJpX - G9gajJp8;
			final double rHpkrNVr = dmRv5Tft * (G9gajJp8 * G9gajJp8 + G9gajJp8 * cnchyJpX + cnchyJpX * cnchyJpX) / 3;
			final double cnx9xQP9 = sop1DfQt * sop1DfQt / dmRv5Tft;

			final double fZZF6eNG = ZaeLnX3n - pV86uCJ0;
			ZTktGSBc += rHpkrNVr;
			iJjU4vez += cnx9xQP9;

			uoPxGtka += fZZF6eNG * fZZF6eNG;
			Bu9QMjqm += ZTktGSBc * ZTktGSBc;
			uGXOArNR += fZZF6eNG * ZTktGSBc;
			IUQZZn3n += fZZF6eNG * iJjU4vez;
			x6KvCj1F += ZTktGSBc * iJjU4vez;
		}

		// compute the amplitude and pulsation coefficients
		double ONk3KRDt = Bu9QMjqm * IUQZZn3n - uGXOArNR * x6KvCj1F;
		double xdkEOV1f = uGXOArNR * IUQZZn3n - uoPxGtka * x6KvCj1F;
		double AHn7CcZ2 = uoPxGtka * Bu9QMjqm - uGXOArNR * uGXOArNR;
		if ((ONk3KRDt / xdkEOV1f < 0) || (xdkEOV1f / AHn7CcZ2 < 0)) {
			final int HywUN8Y8 = observations.length - 1;
			// Range of the observations, assuming that the
			// observations are sorted.
			final double voZgdUL3 = observations[HywUN8Y8].getX() - observations[0].getX();
			if (voZgdUL3 == 0) {
				throw new ZeroException();
			}
			omega = 2 * Math.PI / voZgdUL3;

			double g3PVEeIK = Double.POSITIVE_INFINITY;
			double QRaHp7nZ = Double.NEGATIVE_INFINITY;
			for (int lkIhtfsB = 1; lkIhtfsB < observations.length; ++lkIhtfsB) {
				final double VgPyXT4R = observations[lkIhtfsB].getY();
				if (VgPyXT4R < g3PVEeIK) {
					g3PVEeIK = VgPyXT4R;
				}
				if (VgPyXT4R > QRaHp7nZ) {
					QRaHp7nZ = VgPyXT4R;
				}
			}
			a = 0.5 * (QRaHp7nZ - g3PVEeIK);
		} else {
			// In some ill-conditioned cases (cf. MATH-844), the guesser
			// procedure cannot produce sensible results.

			a = FastMath.sqrt(ONk3KRDt / xdkEOV1f);
			omega = FastMath.sqrt(xdkEOV1f / AHn7CcZ2);
		}
	}
}