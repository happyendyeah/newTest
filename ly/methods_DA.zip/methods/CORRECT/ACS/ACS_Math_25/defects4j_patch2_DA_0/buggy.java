public class test {
	private void guessAOmega() {
		// initialize the sums for the linear model between the two integrals
		double YVhH1BDC = 0;
		double QZv4sgIg = 0;
		double WXQ0M9ku = 0;
		double MXOQGAk5 = 0;
		double kvI3RpUN = 0;

		double UMcuItGu = observations[0].getX();
		double yVNnrfyF = observations[0].getY();
		double q2LI36ok = 0;
		double qqHalPaj = 0;
		final double KQeYBI1C = UMcuItGu;
		for (int vX43anMR = 1; vX43anMR < observations.length; ++vX43anMR) {
			// one step forward
			final double a3AAnMv4 = UMcuItGu;
			final double lDpkusAr = yVNnrfyF;
			UMcuItGu = observations[vX43anMR].getX();
			yVNnrfyF = observations[vX43anMR].getY();

			// update the integrals of f<sup>2</sup> and f'<sup>2</sup>
			// considering a linear model for f (and therefore constant f')
			final double nS6Ap5od = UMcuItGu - a3AAnMv4;
			final double qp80cGKk = yVNnrfyF - lDpkusAr;
			final double WA5qkgmZ = nS6Ap5od * (lDpkusAr * lDpkusAr + lDpkusAr * yVNnrfyF + yVNnrfyF * yVNnrfyF) / 3;
			final double HPw9YshI = qp80cGKk * qp80cGKk / nS6Ap5od;

			final double XSlLUF5V = UMcuItGu - KQeYBI1C;
			q2LI36ok += WA5qkgmZ;
			qqHalPaj += HPw9YshI;

			YVhH1BDC += XSlLUF5V * XSlLUF5V;
			QZv4sgIg += q2LI36ok * q2LI36ok;
			WXQ0M9ku += XSlLUF5V * q2LI36ok;
			MXOQGAk5 += XSlLUF5V * qqHalPaj;
			kvI3RpUN += q2LI36ok * qqHalPaj;
		}

		// compute the amplitude and pulsation coefficients
		double otYLpJoR = QZv4sgIg * MXOQGAk5 - WXQ0M9ku * kvI3RpUN;
		double OmEYZ1ut = WXQ0M9ku * MXOQGAk5 - YVhH1BDC * kvI3RpUN;
		double pefTJAQD = YVhH1BDC * QZv4sgIg - WXQ0M9ku * WXQ0M9ku;
		if ((otYLpJoR / OmEYZ1ut < 0) || (OmEYZ1ut / pefTJAQD < 0)) {
			final int ordGXHZC = observations.length - 1;
			// Range of the observations, assuming that the
			// observations are sorted.
			final double pwWaquvv = observations[ordGXHZC].getX() - observations[0].getX();
			if (pwWaquvv == 0) {
				throw new ZeroException();
			}
			omega = 2 * Math.PI / pwWaquvv;

			double suUEdTc9 = Double.POSITIVE_INFINITY;
			double LZluW10Z = Double.NEGATIVE_INFINITY;
			for (int aknGkAi7 = 1; aknGkAi7 < observations.length; ++aknGkAi7) {
				final double pN36IkPS = observations[aknGkAi7].getY();
				if (pN36IkPS < suUEdTc9) {
					suUEdTc9 = pN36IkPS;
				}
				if (pN36IkPS > LZluW10Z) {
					LZluW10Z = pN36IkPS;
				}
			}
			a = 0.5 * (LZluW10Z - suUEdTc9);
		} else {
			// In some ill-conditioned cases (cf. MATH-844), the guesser
			// procedure cannot produce sensible results.

			a = FastMath.sqrt(otYLpJoR / OmEYZ1ut);
			omega = FastMath.sqrt(OmEYZ1ut / pefTJAQD);
		}
	}
}