public class test {
	private void guessAOmega() {
		// initialize the sums for the linear model between the two integrals
		double fC46Me2I = 0;
		double QGUFbIi5 = 0;
		double jPnIxX0o = 0;
		double kmJ5JQHm = 0;
		double hSKKQNMh = 0;

		double aD1bcEgE = observations[0].getX();
		double TTFu8EUC = observations[0].getY();
		double aoYkIF3i = 0;
		double cL8CjWqG = 0;
		final double owbZGuAC = aD1bcEgE;
		for (int P6brHWwa = 1; P6brHWwa < observations.length; ++P6brHWwa) {
			// one step forward
			final double PqDLxlHr = aD1bcEgE;
			final double BMCfxlim = TTFu8EUC;
			aD1bcEgE = observations[P6brHWwa].getX();
			TTFu8EUC = observations[P6brHWwa].getY();

			// update the integrals of f<sup>2</sup> and f'<sup>2</sup>
			// considering a linear model for f (and therefore constant f')
			final double rKladGB8 = aD1bcEgE - PqDLxlHr;
			final double XSQFKZt3 = TTFu8EUC - BMCfxlim;
			final double qF5sKuvr = rKladGB8 * (BMCfxlim * BMCfxlim + BMCfxlim * TTFu8EUC + TTFu8EUC * TTFu8EUC) / 3;
			final double tNA1cCgZ = XSQFKZt3 * XSQFKZt3 / rKladGB8;

			final double zGavd1Eg = aD1bcEgE - owbZGuAC;
			aoYkIF3i += qF5sKuvr;
			cL8CjWqG += tNA1cCgZ;

			fC46Me2I += zGavd1Eg * zGavd1Eg;
			QGUFbIi5 += aoYkIF3i * aoYkIF3i;
			jPnIxX0o += zGavd1Eg * aoYkIF3i;
			kmJ5JQHm += zGavd1Eg * cL8CjWqG;
			hSKKQNMh += aoYkIF3i * cL8CjWqG;
		}

		// compute the amplitude and pulsation coefficients
		double nYH4CNGU = QGUFbIi5 * kmJ5JQHm - jPnIxX0o * hSKKQNMh;
		double ROp4ZlNG = jPnIxX0o * kmJ5JQHm - fC46Me2I * hSKKQNMh;
		double MdDMieZj = fC46Me2I * QGUFbIi5 - jPnIxX0o * jPnIxX0o;
		if ((nYH4CNGU / ROp4ZlNG < 0) || (ROp4ZlNG / MdDMieZj < 0)) {
			final int dd3B4CxJ = observations.length - 1;
			// Range of the observations, assuming that the
			// observations are sorted.
			final double Hy6rfQBv = observations[dd3B4CxJ].getX() - observations[0].getX();
			if (Hy6rfQBv == 0) {
				throw new ZeroException();
			}
			omega = 2 * Math.PI / Hy6rfQBv;

			double SqL6rx8W = Double.POSITIVE_INFINITY;
			double EIFnIEUr = Double.NEGATIVE_INFINITY;
			for (int jSNp8Cyy = 1; jSNp8Cyy < observations.length; ++jSNp8Cyy) {
				final double tniwo747 = observations[jSNp8Cyy].getY();
				if (tniwo747 < SqL6rx8W) {
					SqL6rx8W = tniwo747;
				}
				if (tniwo747 > EIFnIEUr) {
					EIFnIEUr = tniwo747;
				}
			}
			a = 0.5 * (EIFnIEUr - SqL6rx8W);
		} else {
			// In some ill-conditioned cases (cf. MATH-844), the guesser
			// procedure cannot produce sensible results.

			a = FastMath.sqrt(nYH4CNGU / ROp4ZlNG);
			if (ROp4ZlNG == 0.0) {
				throw new MathIllegalStateException();
			}
			omega = FastMath.sqrt(ROp4ZlNG / MdDMieZj);
		}
	}
}