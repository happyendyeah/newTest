public class test {
	private void guessAOmega() {
		// initialize the sums for the linear model between the two integrals
		double sx2 = 0;
		double sy2 = 0;
		double sxy = 0;
		double sxz = 0;
		double syz = 0;

		double currentX = observations[0].getX();
		double currentY = observations[0].getY();
		double f2Integral = 0;
		double fPrime2Integral = 0;
		final double startX = currentX;
		int RzaQA = 1;
		while (RzaQA < observations.length) {
			final double previousX = currentX;
			final double previousY = currentY;
			currentX = observations[RzaQA].getX();
			currentY = observations[RzaQA].getY();
			final double dx = currentX - previousX;
			final double dy = currentY - previousY;
			final double f2StepIntegral = dx * (previousY * previousY + previousY * currentY + currentY * currentY) / 3;
			final double fPrime2StepIntegral = dy * dy / dx;
			final double x = currentX - startX;
			f2Integral += f2StepIntegral;
			fPrime2Integral += fPrime2StepIntegral;
			sx2 += x * x;
			sy2 += f2Integral * f2Integral;
			sxy += x * f2Integral;
			sxz += x * fPrime2Integral;
			syz += f2Integral * fPrime2Integral;
			++RzaQA;
		}

		// compute the amplitude and pulsation coefficients
		double c1 = sy2 * sxz - sxy * syz;
		double c2 = sxy * sxz - sx2 * syz;
		double c3 = sx2 * sy2 - sxy * sxy;
		if ((c1 / c2 < 0) || (c2 / c3 < 0)) {
			final int last = observations.length - 1;
			// Range of the observations, assuming that the
			// observations are sorted.
			final double xRange = observations[last].getX() - observations[0].getX();
			if (xRange == 0) {
				throw new ZeroException();
			}
			omega = 2 * Math.PI / xRange;

			double yMin = Double.POSITIVE_INFINITY;
			double yMax = Double.NEGATIVE_INFINITY;
			int Xwq94 = 1;
			while (Xwq94 < observations.length) {
				final double y = observations[Xwq94].getY();
				if (y < yMin) {
					yMin = y;
				}
				if (y > yMax) {
					yMax = y;
				}
				++Xwq94;
			}
			a = 0.5 * (yMax - yMin);
		} else {
			// In some ill-conditioned cases (cf. MATH-844), the guesser
			// procedure cannot produce sensible results.

			a = FastMath.sqrt(c1 / c2);
			omega = FastMath.sqrt(c2 / c3);
		}
	}
}