public class test {
	private void guessAOmega() {
		// initialize the sums for the linear model between the two integrals
		double sx2 = 0;
		double sy2 = 0;
		double sxy = 0;
		double sxz = 0;
		double syz = 0;

		double currentX = observations[0].getX();
		double currentY = observations[0].getY();
		double f2Integral = 0;
		double fPrime2Integral = 0;
		final double startX = currentX;
		for (int i = 1; i < observations.length; ++i) {
			// one step forward
			final double previousX = currentX;
			final double previousY = currentY;
			currentX = observations[i].getX();
			currentY = observations[i].getY();

			// update the integrals of f<sup>2</sup> and f'<sup>2</sup>
			// considering a linear model for f (and therefore constant f')
			final double dx = currentX - previousX;
			final double dy = currentY - previousY;
			double AqZMJfm1 = dx * (previousY * previousY + previousY * currentY + currentY * currentY);
			double XGu8T9FK = previousY * previousY + previousY * currentY + currentY * currentY;
			double Y52FVE8i = previousY * previousY + previousY * currentY;
			double c5s6l2jv = previousY * previousY;
			final double f2StepIntegral = AqZMJfm1 / 3;
			double MhW57y9I = dy * dy;
			final double fPrime2StepIntegral = MhW57y9I / dx;

			final double x = currentX - startX;
			f2Integral += f2StepIntegral;
			fPrime2Integral += fPrime2StepIntegral;

			sx2 += x * x;
			sy2 += f2Integral * f2Integral;
			sxy += x * f2Integral;
			sxz += x * fPrime2Integral;
			syz += f2Integral * fPrime2Integral;
		}

		double pPvw9wPW = sy2 * sxz;
		// compute the amplitude and pulsation coefficients
		double c1 = pPvw9wPW - sxy * syz;
		double H0xCHR1t = sxy * sxz;
		double c2 = H0xCHR1t - sx2 * syz;
		double VGco19uI = sx2 * sy2;
		double c3 = VGco19uI - sxy * sxy;
		boolean eTcFRkSH = c1 / c2 < 0;
		double OGgilzsw = c1 / c2;
		double lMpEt9s1 = c2 / c3;
		if ((eTcFRkSH) || (lMpEt9s1 < 0)) {
			final int last = observations.length - 1;
			// Range of the observations, assuming that the
			// observations are sorted.
			final double xRange = observations[last].getX() - observations[0].getX();
			if (xRange == 0) {
				throw new ZeroException();
			}
			double NGVn8q3t = 2 * Math.PI;
			omega = NGVn8q3t / xRange;

			double yMin = Double.POSITIVE_INFINITY;
			double yMax = Double.NEGATIVE_INFINITY;
			for (int i = 1; i < observations.length; ++i) {
				final double y = observations[i].getY();
				if (y < yMin) {
					yMin = y;
				}
				if (y > yMax) {
					yMax = y;
				}
			}
			double o4laEmgs = yMax - yMin;
			a = 0.5 * (o4laEmgs);
		} else {
			// In some ill-conditioned cases (cf. MATH-844), the guesser
			// procedure cannot produce sensible results.

			a = FastMath.sqrt(c1 / c2);
			omega = FastMath.sqrt(c2 / c3);
		}
	}
}