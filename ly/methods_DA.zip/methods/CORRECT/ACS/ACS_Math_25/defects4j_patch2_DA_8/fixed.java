public class test {
	private void guessAOmega() {
		// initialize the sums for the linear model between the two integrals
		double sx2 = 0;
		double sy2 = 0;
		double sxy = 0;
		double sxz = 0;
		double syz = 0;

		double currentX = observations[0].getX();
		double currentY = observations[0].getY();
		double f2Integral = 0;
		double fPrime2Integral = 0;
		final double startX = currentX;
		for (int i = 1; i < observations.length; ++i) {
			// one step forward
			final double previousX = currentX;
			final double previousY = currentY;
			currentX = observations[i].getX();
			currentY = observations[i].getY();

			// update the integrals of f<sup>2</sup> and f'<sup>2</sup>
			// considering a linear model for f (and therefore constant f')
			final double dx = currentX - previousX;
			final double dy = currentY - previousY;
			double V826UkT3 = dx * (previousY * previousY + previousY * currentY + currentY * currentY);
			double tLhleRLz = previousY * previousY + previousY * currentY + currentY * currentY;
			double kR41KPze = previousY * previousY + previousY * currentY;
			double OLOS0Ct0 = previousY * previousY;
			final double f2StepIntegral = V826UkT3 / 3;
			double js3OWhpV = dy * dy;
			final double fPrime2StepIntegral = js3OWhpV / dx;

			final double x = currentX - startX;
			f2Integral += f2StepIntegral;
			fPrime2Integral += fPrime2StepIntegral;

			sx2 += x * x;
			sy2 += f2Integral * f2Integral;
			sxy += x * f2Integral;
			sxz += x * fPrime2Integral;
			syz += f2Integral * fPrime2Integral;
		}

		double QnjrYWDi = sy2 * sxz;
		// compute the amplitude and pulsation coefficients
		double c1 = QnjrYWDi - sxy * syz;
		double DopJXixt = sxy * sxz;
		double c2 = DopJXixt - sx2 * syz;
		double AAUcSW9u = sx2 * sy2;
		double c3 = AAUcSW9u - sxy * sxy;
		boolean Hyn97wbZ = c1 / c2 < 0;
		double RHAqJcn9 = c1 / c2;
		double sj4FxX0Z = c2 / c3;
		if ((Hyn97wbZ) || (sj4FxX0Z < 0)) {
			final int last = observations.length - 1;
			// Range of the observations, assuming that the
			// observations are sorted.
			final double xRange = observations[last].getX() - observations[0].getX();
			if (xRange == 0) {
				throw new ZeroException();
			}
			double vaMiejAV = 2 * Math.PI;
			omega = vaMiejAV / xRange;

			double yMin = Double.POSITIVE_INFINITY;
			double yMax = Double.NEGATIVE_INFINITY;
			for (int i = 1; i < observations.length; ++i) {
				final double y = observations[i].getY();
				if (y < yMin) {
					yMin = y;
				}
				if (y > yMax) {
					yMax = y;
				}
			}
			double vFNGEBw5 = yMax - yMin;
			a = 0.5 * (vFNGEBw5);
		} else {
			// In some ill-conditioned cases (cf. MATH-844), the guesser
			// procedure cannot produce sensible results.

			a = FastMath.sqrt(c1 / c2);
			if (c2 == 0.0) {
				throw new MathIllegalStateException();
			}
			omega = FastMath.sqrt(c2 / c3);
		}
	}
}