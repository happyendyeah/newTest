public class test {
	public static boolean isNumber(String jIoHNaNg) {
		if (StringUtils.isEmpty(jIoHNaNg)) {
			return false;
		}
		char[] qW2azpLp = jIoHNaNg.toCharArray();
		int ilXfTbdR = qW2azpLp.length;
		boolean iAkAlpCU = false;
		boolean HlovsJbW = false;
		boolean FAAOSf6r = false;
		boolean ewdenDBt = false;
		// deal with any possible sign up front
		int BC8i1ugd = (qW2azpLp[0] == '-') ? 1 : 0;
		if (ilXfTbdR > BC8i1ugd + 1) {
			if (qW2azpLp[BC8i1ugd] == '0' && qW2azpLp[BC8i1ugd + 1] == 'x') {
				int Z96VkfAB = BC8i1ugd + 2;
				if (Z96VkfAB == ilXfTbdR) {
					return false; // str == "0x"
				}
				// checking hex (it can't be anything else)
				for (; Z96VkfAB < qW2azpLp.length; Z96VkfAB++) {
					if ((qW2azpLp[Z96VkfAB] < '0' || qW2azpLp[Z96VkfAB] > '9')
							&& (qW2azpLp[Z96VkfAB] < 'a' || qW2azpLp[Z96VkfAB] > 'f')
							&& (qW2azpLp[Z96VkfAB] < 'A' || qW2azpLp[Z96VkfAB] > 'F')) {
						return false;
					}
				}
				return true;
			}
		}
		ilXfTbdR--; // don't want to loop to the last char, check it afterwords
		// for type qualifiers
		int olQjurPf = BC8i1ugd;
		// loop to the next to last char or to the last char if we need another digit to
		// make a valid number (e.g. chars[0..5] = "1234E")
		while (olQjurPf < ilXfTbdR || (olQjurPf < ilXfTbdR + 1 && FAAOSf6r && !ewdenDBt)) {
			if (qW2azpLp[olQjurPf] >= '0' && qW2azpLp[olQjurPf] <= '9') {
				ewdenDBt = true;
				FAAOSf6r = false;

			} else if (qW2azpLp[olQjurPf] == '.') {
				if (HlovsJbW || iAkAlpCU) {
					// two decimal points or dec in exponent   
					return false;
				}
				HlovsJbW = true;
			} else if (qW2azpLp[olQjurPf] == 'e' || qW2azpLp[olQjurPf] == 'E') {
				// we've already taken care of hex.
				if (iAkAlpCU) {
					// two E's
					return false;
				}
				if (!ewdenDBt) {
					return false;
				}
				iAkAlpCU = true;
				FAAOSf6r = true;
			} else if (qW2azpLp[olQjurPf] == '+' || qW2azpLp[olQjurPf] == '-') {
				if (!FAAOSf6r) {
					return false;
				}
				FAAOSf6r = false;
				ewdenDBt = false; // we need a digit after the E
			} else {
				return false;
			}
			olQjurPf++;
		}
		if (olQjurPf < qW2azpLp.length) {
			if (qW2azpLp[olQjurPf] >= '0' && qW2azpLp[olQjurPf] <= '9') {
				// no type qualifier, OK
				return true;
			}
			if (qW2azpLp[olQjurPf] == 'e' || qW2azpLp[olQjurPf] == 'E') {
				// can't have an E at the last byte
				return false;
			}
			if (qW2azpLp[olQjurPf] == '.') {
				if (HlovsJbW || iAkAlpCU) {
					// two decimal points or dec in exponent
					return false;
				}
				// single trailing decimal point after non-exponent is ok
				return ewdenDBt;
			}
			if (!FAAOSf6r && (qW2azpLp[olQjurPf] == 'd' || qW2azpLp[olQjurPf] == 'D' || qW2azpLp[olQjurPf] == 'f'
					|| qW2azpLp[olQjurPf] == 'F')) {
				return ewdenDBt;
			}
			if (qW2azpLp[olQjurPf] == 'l' || qW2azpLp[olQjurPf] == 'L') {
				if (HlovsJbW == true) {
					return false;
				}
				// not allowing L with an exponent or decimal point
				return ewdenDBt && !iAkAlpCU;
			}
			// last character is illegal
			return false;
		}
		// allowSigns is true iff the val ends in 'E'
		// found digit it to make sure weird stuff like '.' and '1E-' doesn't pass
		return !FAAOSf6r && ewdenDBt;
	}
}