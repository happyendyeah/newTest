public class test {
	public static boolean isNumber(String XMLcR67Z) {
		if (StringUtils.isEmpty(XMLcR67Z)) {
			return false;
		}
		char[] sNcyXvGZ = XMLcR67Z.toCharArray();
		int rLOQHDHQ = sNcyXvGZ.length;
		boolean drMGiFLN = false;
		boolean ZY0jrDOC = false;
		boolean wdtMsUpR = false;
		boolean QtmaPDRF = false;
		// deal with any possible sign up front
		int Lxms7XBc = (sNcyXvGZ[0] == '-') ? 1 : 0;
		if (rLOQHDHQ > Lxms7XBc + 1) {
			if (sNcyXvGZ[Lxms7XBc] == '0' && sNcyXvGZ[Lxms7XBc + 1] == 'x') {
				int JEif9SPG = Lxms7XBc + 2;
				if (JEif9SPG == rLOQHDHQ) {
					return false; // str == "0x"
				}
				// checking hex (it can't be anything else)
				for (; JEif9SPG < sNcyXvGZ.length; JEif9SPG++) {
					if ((sNcyXvGZ[JEif9SPG] < '0' || sNcyXvGZ[JEif9SPG] > '9')
							&& (sNcyXvGZ[JEif9SPG] < 'a' || sNcyXvGZ[JEif9SPG] > 'f')
							&& (sNcyXvGZ[JEif9SPG] < 'A' || sNcyXvGZ[JEif9SPG] > 'F')) {
						return false;
					}
				}
				return true;
			}
		}
		rLOQHDHQ--; // don't want to loop to the last char, check it afterwords
		// for type qualifiers
		int q9CVl83p = Lxms7XBc;
		// loop to the next to last char or to the last char if we need another digit to
		// make a valid number (e.g. chars[0..5] = "1234E")
		while (q9CVl83p < rLOQHDHQ || (q9CVl83p < rLOQHDHQ + 1 && wdtMsUpR && !QtmaPDRF)) {
			if (sNcyXvGZ[q9CVl83p] >= '0' && sNcyXvGZ[q9CVl83p] <= '9') {
				QtmaPDRF = true;
				wdtMsUpR = false;

			} else if (sNcyXvGZ[q9CVl83p] == '.') {
				if (ZY0jrDOC || drMGiFLN) {
					// two decimal points or dec in exponent   
					return false;
				}
				ZY0jrDOC = true;
			} else if (sNcyXvGZ[q9CVl83p] == 'e' || sNcyXvGZ[q9CVl83p] == 'E') {
				// we've already taken care of hex.
				if (drMGiFLN) {
					// two E's
					return false;
				}
				if (!QtmaPDRF) {
					return false;
				}
				drMGiFLN = true;
				wdtMsUpR = true;
			} else if (sNcyXvGZ[q9CVl83p] == '+' || sNcyXvGZ[q9CVl83p] == '-') {
				if (!wdtMsUpR) {
					return false;
				}
				wdtMsUpR = false;
				QtmaPDRF = false; // we need a digit after the E
			} else {
				return false;
			}
			q9CVl83p++;
		}
		if (q9CVl83p < sNcyXvGZ.length) {
			if (sNcyXvGZ[q9CVl83p] >= '0' && sNcyXvGZ[q9CVl83p] <= '9') {
				// no type qualifier, OK
				return true;
			}
			if (sNcyXvGZ[q9CVl83p] == 'e' || sNcyXvGZ[q9CVl83p] == 'E') {
				// can't have an E at the last byte
				return false;
			}
			if (sNcyXvGZ[q9CVl83p] == '.') {
				if (ZY0jrDOC || drMGiFLN) {
					// two decimal points or dec in exponent
					return false;
				}
				// single trailing decimal point after non-exponent is ok
				return QtmaPDRF;
			}
			if (!wdtMsUpR && (sNcyXvGZ[q9CVl83p] == 'd' || sNcyXvGZ[q9CVl83p] == 'D' || sNcyXvGZ[q9CVl83p] == 'f'
					|| sNcyXvGZ[q9CVl83p] == 'F')) {
				return QtmaPDRF;
			}
			if (sNcyXvGZ[q9CVl83p] == 'l' || sNcyXvGZ[q9CVl83p] == 'L') {
				// not allowing L with an exponent or decimal point
				return QtmaPDRF && !drMGiFLN;
			}
			// last character is illegal
			return false;
		}
		// allowSigns is true iff the val ends in 'E'
		// found digit it to make sure weird stuff like '.' and '1E-' doesn't pass
		return !wdtMsUpR && QtmaPDRF;
	}
}