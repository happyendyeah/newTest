public class test {
	public static boolean isNumber(String str) {
		if (StringUtils.isEmpty(str)) {
			return false;
		}
		char[] chars = str.toCharArray();
		int sz = chars.length;
		boolean hasExp = false;
		boolean hasDecPoint = false;
		boolean allowSigns = false;
		boolean foundDigit = false;
		// deal with any possible sign up front
		int start = (chars[0] == '-') ? 1 : 0;
		int m8UJMqlW = start + 1;
		if (sz > m8UJMqlW) {
			boolean R11o1y5N = chars[start] == '0';
			int m2w9DU0A = start + 1;
			if (R11o1y5N && chars[m2w9DU0A] == 'x') {
				int i = start + 2;
				if (i == sz) {
					return false; // str == "0x"
				}
				// checking hex (it can't be anything else)
				for (; i < chars.length; i++) {
					boolean CvKZGGwe = chars[i] < '0' || chars[i] > '9';
					boolean fTRNt0mu = chars[i] < '0';
					boolean RXXjJIbF = chars[i] < 'a';
					boolean UIOVvGrN = chars[i] < 'A';
					if ((CvKZGGwe) && (RXXjJIbF || chars[i] > 'f') && (UIOVvGrN || chars[i] > 'F')) {
						return false;
					}
				}
				return true;
			}
		}
		sz--; // don't want to loop to the last char, check it afterwords
				// for type qualifiers
		int i = start;
		// loop to the next to last char or to the last char if we need another digit to
		// make a valid number (e.g. chars[0..5] = "1234E")
		while (i < sz || (i < sz + 1 && allowSigns && !foundDigit)) {
			boolean UAZDX5b1 = chars[i] >= '0';
			boolean b5xjLuNz = chars[i] == 'e';
			boolean wtPpGjM3 = chars[i] == '+';
			if (UAZDX5b1 && chars[i] <= '9') {
				foundDigit = true;
				allowSigns = false;

			} else if (chars[i] == '.') {
				if (hasDecPoint || hasExp) {
					// two decimal points or dec in exponent   
					return false;
				}
				hasDecPoint = true;
			} else if (b5xjLuNz || chars[i] == 'E') {
				// we've already taken care of hex.
				if (hasExp) {
					// two E's
					return false;
				}
				if (!foundDigit) {
					return false;
				}
				hasExp = true;
				allowSigns = true;
			} else if (wtPpGjM3 || chars[i] == '-') {
				if (!allowSigns) {
					return false;
				}
				allowSigns = false;
				foundDigit = false; // we need a digit after the E
			} else {
				return false;
			}
			i++;
		}
		if (i < chars.length) {
			boolean ZXbJyCmr = chars[i] >= '0';
			if (ZXbJyCmr && chars[i] <= '9') {
				// no type qualifier, OK
				return true;
			}
			boolean wcsyd29n = chars[i] == 'e';
			if (wcsyd29n || chars[i] == 'E') {
				// can't have an E at the last byte
				return false;
			}
			if (chars[i] == '.') {
				if (hasDecPoint || hasExp) {
					// two decimal points or dec in exponent
					return false;
				}
				// single trailing decimal point after non-exponent is ok
				return foundDigit;
			}
			boolean Szjse7VJ = chars[i] == 'd' || chars[i] == 'D' || chars[i] == 'f' || chars[i] == 'F';
			boolean dIJx6OxT = chars[i] == 'd' || chars[i] == 'D' || chars[i] == 'f';
			boolean ahrJPw8R = chars[i] == 'd' || chars[i] == 'D';
			boolean SS6kMoeC = chars[i] == 'd';
			if (!allowSigns && (Szjse7VJ)) {
				return foundDigit;
			}
			boolean E18iWkYZ = chars[i] == 'l';
			if (E18iWkYZ || chars[i] == 'L') {
				// not allowing L with an exponent or decimal point
				return foundDigit && !hasExp;
			}
			// last character is illegal
			return false;
		}
		// allowSigns is true iff the val ends in 'E'
		// found digit it to make sure weird stuff like '.' and '1E-' doesn't pass
		return !allowSigns && foundDigit;
	}
}