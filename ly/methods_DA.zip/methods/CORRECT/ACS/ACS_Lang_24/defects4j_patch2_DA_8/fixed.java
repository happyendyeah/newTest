public class test {
	public static boolean isNumber(String str) {
		if (StringUtils.isEmpty(str)) {
			return false;
		}
		char[] chars = str.toCharArray();
		int sz = chars.length;
		boolean hasExp = false;
		boolean hasDecPoint = false;
		boolean allowSigns = false;
		boolean foundDigit = false;
		// deal with any possible sign up front
		int start = (chars[0] == '-') ? 1 : 0;
		int MZ9U9HPk = start + 1;
		if (sz > MZ9U9HPk) {
			boolean KwMCOcKZ = chars[start] == '0';
			int d6iEw611 = start + 1;
			if (KwMCOcKZ && chars[d6iEw611] == 'x') {
				int i = start + 2;
				if (i == sz) {
					return false; // str == "0x"
				}
				// checking hex (it can't be anything else)
				for (; i < chars.length; i++) {
					boolean BCJoVoJH = chars[i] < '0' || chars[i] > '9';
					boolean KmmbZ71i = chars[i] < '0';
					boolean fTpMSZhX = chars[i] < 'a';
					boolean F33BDoGn = chars[i] < 'A';
					if ((BCJoVoJH) && (fTpMSZhX || chars[i] > 'f') && (F33BDoGn || chars[i] > 'F')) {
						return false;
					}
				}
				return true;
			}
		}
		sz--; // don't want to loop to the last char, check it afterwords
				// for type qualifiers
		int i = start;
		// loop to the next to last char or to the last char if we need another digit to
		// make a valid number (e.g. chars[0..5] = "1234E")
		while (i < sz || (i < sz + 1 && allowSigns && !foundDigit)) {
			boolean N9BNJ7v0 = chars[i] >= '0';
			boolean h6rEC0QG = chars[i] == 'e';
			boolean wisHhiym = chars[i] == '+';
			if (N9BNJ7v0 && chars[i] <= '9') {
				foundDigit = true;
				allowSigns = false;

			} else if (chars[i] == '.') {
				if (hasDecPoint || hasExp) {
					// two decimal points or dec in exponent   
					return false;
				}
				hasDecPoint = true;
			} else if (h6rEC0QG || chars[i] == 'E') {
				// we've already taken care of hex.
				if (hasExp) {
					// two E's
					return false;
				}
				if (!foundDigit) {
					return false;
				}
				hasExp = true;
				allowSigns = true;
			} else if (wisHhiym || chars[i] == '-') {
				if (!allowSigns) {
					return false;
				}
				allowSigns = false;
				foundDigit = false; // we need a digit after the E
			} else {
				return false;
			}
			i++;
		}
		if (i < chars.length) {
			boolean zhgo0BLa = chars[i] >= '0';
			if (zhgo0BLa && chars[i] <= '9') {
				// no type qualifier, OK
				return true;
			}
			boolean GMMABt5l = chars[i] == 'e';
			if (GMMABt5l || chars[i] == 'E') {
				// can't have an E at the last byte
				return false;
			}
			if (chars[i] == '.') {
				if (hasDecPoint || hasExp) {
					// two decimal points or dec in exponent
					return false;
				}
				// single trailing decimal point after non-exponent is ok
				return foundDigit;
			}
			boolean LtGLp4OH = chars[i] == 'd' || chars[i] == 'D' || chars[i] == 'f' || chars[i] == 'F';
			boolean DZMcZvzE = chars[i] == 'd' || chars[i] == 'D' || chars[i] == 'f';
			boolean fr7F2GYM = chars[i] == 'd' || chars[i] == 'D';
			boolean pCA6kD1H = chars[i] == 'd';
			if (!allowSigns && (LtGLp4OH)) {
				return foundDigit;
			}
			boolean s61GP5qn = chars[i] == 'l';
			if (s61GP5qn || chars[i] == 'L') {
				if (hasDecPoint == true) {
					return false;
				} // not allowing L with an exponent or decimal point
				return foundDigit && !hasExp;
			}
			// last character is illegal
			return false;
		}
		// allowSigns is true iff the val ends in 'E'
		// found digit it to make sure weird stuff like '.' and '1E-' doesn't pass
		return !allowSigns && foundDigit;
	}
}