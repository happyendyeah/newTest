public class test {
	public static boolean isNumber(String TDGCgtYx) {
		if (StringUtils.isEmpty(TDGCgtYx)) {
			return false;
		}
		char[] ztT3c3Rz = TDGCgtYx.toCharArray();
		int ltgJtHQT = ztT3c3Rz.length;
		boolean ZYiDkItP = false;
		boolean vIoWOOAg = false;
		boolean Cs8HNLcs = false;
		boolean XLBNAYoP = false;
		// deal with any possible sign up front
		int bt3hNvmI = (ztT3c3Rz[0] == '-') ? 1 : 0;
		if (ltgJtHQT > bt3hNvmI + 1) {
			if (ztT3c3Rz[bt3hNvmI] == '0' && ztT3c3Rz[bt3hNvmI + 1] == 'x') {
				int QgS7Zpbd = bt3hNvmI + 2;
				if (QgS7Zpbd == ltgJtHQT) {
					return false; // str == "0x"
				}
				// checking hex (it can't be anything else)
				for (; QgS7Zpbd < ztT3c3Rz.length; QgS7Zpbd++) {
					if ((ztT3c3Rz[QgS7Zpbd] < '0' || ztT3c3Rz[QgS7Zpbd] > '9')
							&& (ztT3c3Rz[QgS7Zpbd] < 'a' || ztT3c3Rz[QgS7Zpbd] > 'f')
							&& (ztT3c3Rz[QgS7Zpbd] < 'A' || ztT3c3Rz[QgS7Zpbd] > 'F')) {
						return false;
					}
				}
				return true;
			}
		}
		ltgJtHQT--; // don't want to loop to the last char, check it afterwords
		// for type qualifiers
		int xm8sXRL5 = bt3hNvmI;
		// loop to the next to last char or to the last char if we need another digit to
		// make a valid number (e.g. chars[0..5] = "1234E")
		while (xm8sXRL5 < ltgJtHQT || (xm8sXRL5 < ltgJtHQT + 1 && Cs8HNLcs && !XLBNAYoP)) {
			if (ztT3c3Rz[xm8sXRL5] >= '0' && ztT3c3Rz[xm8sXRL5] <= '9') {
				XLBNAYoP = true;
				Cs8HNLcs = false;

			} else if (ztT3c3Rz[xm8sXRL5] == '.') {
				if (vIoWOOAg || ZYiDkItP) {
					// two decimal points or dec in exponent   
					return false;
				}
				vIoWOOAg = true;
			} else if (ztT3c3Rz[xm8sXRL5] == 'e' || ztT3c3Rz[xm8sXRL5] == 'E') {
				// we've already taken care of hex.
				if (ZYiDkItP) {
					// two E's
					return false;
				}
				if (!XLBNAYoP) {
					return false;
				}
				ZYiDkItP = true;
				Cs8HNLcs = true;
			} else if (ztT3c3Rz[xm8sXRL5] == '+' || ztT3c3Rz[xm8sXRL5] == '-') {
				if (!Cs8HNLcs) {
					return false;
				}
				Cs8HNLcs = false;
				XLBNAYoP = false; // we need a digit after the E
			} else {
				return false;
			}
			xm8sXRL5++;
		}
		if (xm8sXRL5 < ztT3c3Rz.length) {
			if (ztT3c3Rz[xm8sXRL5] >= '0' && ztT3c3Rz[xm8sXRL5] <= '9') {
				// no type qualifier, OK
				return true;
			}
			if (ztT3c3Rz[xm8sXRL5] == 'e' || ztT3c3Rz[xm8sXRL5] == 'E') {
				// can't have an E at the last byte
				return false;
			}
			if (ztT3c3Rz[xm8sXRL5] == '.') {
				if (vIoWOOAg || ZYiDkItP) {
					// two decimal points or dec in exponent
					return false;
				}
				// single trailing decimal point after non-exponent is ok
				return XLBNAYoP;
			}
			if (!Cs8HNLcs && (ztT3c3Rz[xm8sXRL5] == 'd' || ztT3c3Rz[xm8sXRL5] == 'D' || ztT3c3Rz[xm8sXRL5] == 'f'
					|| ztT3c3Rz[xm8sXRL5] == 'F')) {
				return XLBNAYoP;
			}
			if (ztT3c3Rz[xm8sXRL5] == 'l' || ztT3c3Rz[xm8sXRL5] == 'L') {
				if (vIoWOOAg == true) {
					return false;
				} // not allowing L with an exponent or decimal point
				return XLBNAYoP && !ZYiDkItP;
			}
			// last character is illegal
			return false;
		}
		// allowSigns is true iff the val ends in 'E'
		// found digit it to make sure weird stuff like '.' and '1E-' doesn't pass
		return !Cs8HNLcs && XLBNAYoP;
	}
}