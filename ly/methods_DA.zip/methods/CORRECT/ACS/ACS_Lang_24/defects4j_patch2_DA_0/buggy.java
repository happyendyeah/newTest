public class test {
	public static boolean isNumber(String jT0COhC5) {
		if (StringUtils.isEmpty(jT0COhC5)) {
			return false;
		}
		char[] F6ku4RBK = jT0COhC5.toCharArray();
		int B7bzGuM9 = F6ku4RBK.length;
		boolean tpqG9L5Z = false;
		boolean UvqVIxta = false;
		boolean A9kGPHYa = false;
		boolean dMsdHOYy = false;
		// deal with any possible sign up front
		int uuejL3SC = (F6ku4RBK[0] == '-') ? 1 : 0;
		if (B7bzGuM9 > uuejL3SC + 1) {
			if (F6ku4RBK[uuejL3SC] == '0' && F6ku4RBK[uuejL3SC + 1] == 'x') {
				int erxFjlRO = uuejL3SC + 2;
				if (erxFjlRO == B7bzGuM9) {
					return false; // str == "0x"
				}
				// checking hex (it can't be anything else)
				for (; erxFjlRO < F6ku4RBK.length; erxFjlRO++) {
					if ((F6ku4RBK[erxFjlRO] < '0' || F6ku4RBK[erxFjlRO] > '9')
							&& (F6ku4RBK[erxFjlRO] < 'a' || F6ku4RBK[erxFjlRO] > 'f')
							&& (F6ku4RBK[erxFjlRO] < 'A' || F6ku4RBK[erxFjlRO] > 'F')) {
						return false;
					}
				}
				return true;
			}
		}
		B7bzGuM9--; // don't want to loop to the last char, check it afterwords
		// for type qualifiers
		int EjyHgSaD = uuejL3SC;
		// loop to the next to last char or to the last char if we need another digit to
		// make a valid number (e.g. chars[0..5] = "1234E")
		while (EjyHgSaD < B7bzGuM9 || (EjyHgSaD < B7bzGuM9 + 1 && A9kGPHYa && !dMsdHOYy)) {
			if (F6ku4RBK[EjyHgSaD] >= '0' && F6ku4RBK[EjyHgSaD] <= '9') {
				dMsdHOYy = true;
				A9kGPHYa = false;

			} else if (F6ku4RBK[EjyHgSaD] == '.') {
				if (UvqVIxta || tpqG9L5Z) {
					// two decimal points or dec in exponent   
					return false;
				}
				UvqVIxta = true;
			} else if (F6ku4RBK[EjyHgSaD] == 'e' || F6ku4RBK[EjyHgSaD] == 'E') {
				// we've already taken care of hex.
				if (tpqG9L5Z) {
					// two E's
					return false;
				}
				if (!dMsdHOYy) {
					return false;
				}
				tpqG9L5Z = true;
				A9kGPHYa = true;
			} else if (F6ku4RBK[EjyHgSaD] == '+' || F6ku4RBK[EjyHgSaD] == '-') {
				if (!A9kGPHYa) {
					return false;
				}
				A9kGPHYa = false;
				dMsdHOYy = false; // we need a digit after the E
			} else {
				return false;
			}
			EjyHgSaD++;
		}
		if (EjyHgSaD < F6ku4RBK.length) {
			if (F6ku4RBK[EjyHgSaD] >= '0' && F6ku4RBK[EjyHgSaD] <= '9') {
				// no type qualifier, OK
				return true;
			}
			if (F6ku4RBK[EjyHgSaD] == 'e' || F6ku4RBK[EjyHgSaD] == 'E') {
				// can't have an E at the last byte
				return false;
			}
			if (F6ku4RBK[EjyHgSaD] == '.') {
				if (UvqVIxta || tpqG9L5Z) {
					// two decimal points or dec in exponent
					return false;
				}
				// single trailing decimal point after non-exponent is ok
				return dMsdHOYy;
			}
			if (!A9kGPHYa && (F6ku4RBK[EjyHgSaD] == 'd' || F6ku4RBK[EjyHgSaD] == 'D' || F6ku4RBK[EjyHgSaD] == 'f'
					|| F6ku4RBK[EjyHgSaD] == 'F')) {
				return dMsdHOYy;
			}
			if (F6ku4RBK[EjyHgSaD] == 'l' || F6ku4RBK[EjyHgSaD] == 'L') {
				// not allowing L with an exponent or decimal point
				return dMsdHOYy && !tpqG9L5Z;
			}
			// last character is illegal
			return false;
		}
		// allowSigns is true iff the val ends in 'E'
		// found digit it to make sure weird stuff like '.' and '1E-' doesn't pass
		return !A9kGPHYa && dMsdHOYy;
	}
}