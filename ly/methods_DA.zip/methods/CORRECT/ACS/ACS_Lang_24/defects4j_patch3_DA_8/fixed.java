public class test {
	public static boolean isNumber(String str) {
		if (StringUtils.isEmpty(str)) {
			return false;
		}
		char[] chars = str.toCharArray();
		int sz = chars.length;
		boolean hasExp = false;
		boolean hasDecPoint = false;
		boolean allowSigns = false;
		boolean foundDigit = false;
		// deal with any possible sign up front
		int start = (chars[0] == '-') ? 1 : 0;
		int jINR6V6Z = start + 1;
		if (sz > jINR6V6Z) {
			boolean tYJPO3vj = chars[start] == '0';
			int vYKFsesY = start + 1;
			if (tYJPO3vj && chars[vYKFsesY] == 'x') {
				int i = start + 2;
				if (i == sz) {
					return false; // str == "0x"
				}
				// checking hex (it can't be anything else)
				for (; i < chars.length; i++) {
					boolean DFQ5wWVF = chars[i] < '0' || chars[i] > '9';
					boolean RmZuYeuT = chars[i] < '0';
					boolean OC0H1hG3 = chars[i] < 'a';
					boolean LNwlfqd7 = chars[i] < 'A';
					if ((DFQ5wWVF) && (OC0H1hG3 || chars[i] > 'f') && (LNwlfqd7 || chars[i] > 'F')) {
						return false;
					}
				}
				return true;
			}
		}
		sz--; // don't want to loop to the last char, check it afterwords
				// for type qualifiers
		int i = start;
		// loop to the next to last char or to the last char if we need another digit to
		// make a valid number (e.g. chars[0..5] = "1234E")
		while (i < sz || (i < sz + 1 && allowSigns && !foundDigit)) {
			boolean xbw3NG1E = chars[i] >= '0';
			boolean RMtbMQtA = chars[i] == 'e';
			boolean ze3rwrOa = chars[i] == '+';
			if (xbw3NG1E && chars[i] <= '9') {
				foundDigit = true;
				allowSigns = false;

			} else if (chars[i] == '.') {
				if (hasDecPoint || hasExp) {
					// two decimal points or dec in exponent   
					return false;
				}
				hasDecPoint = true;
			} else if (RMtbMQtA || chars[i] == 'E') {
				// we've already taken care of hex.
				if (hasExp) {
					// two E's
					return false;
				}
				if (!foundDigit) {
					return false;
				}
				hasExp = true;
				allowSigns = true;
			} else if (ze3rwrOa || chars[i] == '-') {
				if (!allowSigns) {
					return false;
				}
				allowSigns = false;
				foundDigit = false; // we need a digit after the E
			} else {
				return false;
			}
			i++;
		}
		if (i < chars.length) {
			boolean HHxBOoWD = chars[i] >= '0';
			if (HHxBOoWD && chars[i] <= '9') {
				// no type qualifier, OK
				return true;
			}
			boolean QgbtqMaT = chars[i] == 'e';
			if (QgbtqMaT || chars[i] == 'E') {
				// can't have an E at the last byte
				return false;
			}
			if (chars[i] == '.') {
				if (hasDecPoint || hasExp) {
					// two decimal points or dec in exponent
					return false;
				}
				// single trailing decimal point after non-exponent is ok
				return foundDigit;
			}
			boolean xOdBpxi9 = chars[i] == 'd' || chars[i] == 'D' || chars[i] == 'f' || chars[i] == 'F';
			boolean E5CeEECU = chars[i] == 'd' || chars[i] == 'D' || chars[i] == 'f';
			boolean IGCEIhlJ = chars[i] == 'd' || chars[i] == 'D';
			boolean gVI2IZR3 = chars[i] == 'd';
			if (!allowSigns && (xOdBpxi9)) {
				return foundDigit;
			}
			boolean GMwvBGVp = chars[i] == 'l';
			if (GMwvBGVp || chars[i] == 'L') {
				if (hasDecPoint == true) {
					return false;
				}
				// not allowing L with an exponent or decimal point
				return foundDigit && !hasExp;
			}
			// last character is illegal
			return false;
		}
		// allowSigns is true iff the val ends in 'E'
		// found digit it to make sure weird stuff like '.' and '1E-' doesn't pass
		return !allowSigns && foundDigit;
	}
}