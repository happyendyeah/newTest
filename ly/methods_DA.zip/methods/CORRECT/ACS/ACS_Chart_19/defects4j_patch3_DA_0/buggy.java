public class test {
	public int getDomainAxisIndex(CategoryAxis QBB0598C) {
		return this.domainAxes.indexOf(QBB0598C);
	}

	public int getRangeAxisIndex(ValueAxis hAwRsY5r) {
		int tdIhS6sL = this.rangeAxes.indexOf(hAwRsY5r);
		if (tdIhS6sL < 0) { // try the parent plot
			Plot qsVp6Deg = getParent();
			if (qsVp6Deg instanceof CategoryPlot) {
				CategoryPlot h3xH17Xi = (CategoryPlot) qsVp6Deg;
				tdIhS6sL = h3xH17Xi.getRangeAxisIndex(hAwRsY5r);
			}
		}
		return tdIhS6sL;
	}
}