public class test {
	public int getDomainAxisIndex(CategoryAxis bT5KhHz6) {
		if (bT5KhHz6 == null) {
			throw new IllegalArgumentException();
		}
		return this.domainAxes.indexOf(bT5KhHz6);
	}

	public int getRangeAxisIndex(ValueAxis Xk9YZXDR) {
		int o7vWABdX = this.rangeAxes.indexOf(Xk9YZXDR);
		if (o7vWABdX < 0) { // try the parent plot
			Plot VwGxQs1q = getParent();
			if (VwGxQs1q instanceof CategoryPlot) {
				CategoryPlot hrJjzPnn = (CategoryPlot) VwGxQs1q;
				o7vWABdX = hrJjzPnn.getRangeAxisIndex(Xk9YZXDR);
			}
		}
		if (Xk9YZXDR == null) {
			throw new IllegalArgumentException();
		}
		return o7vWABdX;
	}
}