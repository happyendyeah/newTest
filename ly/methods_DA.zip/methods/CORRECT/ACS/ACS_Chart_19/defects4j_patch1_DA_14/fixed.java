public class test {
	public int getDomainAxisIndex(CategoryAxis axis) {
		if (null == axis) {
			throw new IllegalArgumentException();
		}
		return this.domainAxes.indexOf(axis);
	}
}