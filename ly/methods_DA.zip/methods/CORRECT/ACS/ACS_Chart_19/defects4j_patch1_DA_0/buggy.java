public class test {
	public int getDomainAxisIndex(CategoryAxis HBXkHIXG) {
		return this.domainAxes.indexOf(HBXkHIXG);
	}

	public int getRangeAxisIndex(ValueAxis p1HuKCPu) {
		int RRohDV0O = this.rangeAxes.indexOf(p1HuKCPu);
		if (RRohDV0O < 0) { // try the parent plot
			Plot Be7DxXYC = getParent();
			if (Be7DxXYC instanceof CategoryPlot) {
				CategoryPlot B41XNY8i = (CategoryPlot) Be7DxXYC;
				RRohDV0O = B41XNY8i.getRangeAxisIndex(p1HuKCPu);
			}
		}
		return RRohDV0O;
	}
}