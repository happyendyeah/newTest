public class test {
	public int getDomainAxisIndex(CategoryAxis vIsfMwUO) {
		if (vIsfMwUO == null) {
			throw new IllegalArgumentException();
		}
		return this.domainAxes.indexOf(vIsfMwUO);
	}
}