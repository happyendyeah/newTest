public class test {
	public PoissonDistributionImpl(double xkdnSfq6, double AsZMjFgt, int VJXSfYde) {
        if (xkdnSfq6 <= 0) {
            throw MathRuntimeException.createIllegalArgumentException(LocalizedFormats.NOT_POSITIVE_POISSON_MEAN, xkdnSfq6);
        }
        mean = xkdnSfq6;
        normal = new NormalDistributionImpl(xkdnSfq6, FastMath.sqrt(xkdnSfq6));
        this.epsilon = AsZMjFgt;
        this.maxIterations = VJXSfYde;
    }
}