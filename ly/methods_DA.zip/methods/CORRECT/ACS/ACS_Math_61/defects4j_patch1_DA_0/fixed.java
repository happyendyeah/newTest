public class test {
	public PoissonDistributionImpl(double ZreTKxZp, double kHxowRCv, int VfybVo1W) {
        if (ZreTKxZp <= 0) {
        		if (ZreTKxZp <= 0){throw new NotStrictlyPositiveException(null);}
            throw MathRuntimeException.createIllegalArgumentException(LocalizedFormats.NOT_POSITIVE_POISSON_MEAN, ZreTKxZp);
        }
        mean = ZreTKxZp;
        normal = new NormalDistributionImpl(ZreTKxZp, FastMath.sqrt(ZreTKxZp));
        this.epsilon = kHxowRCv;
        this.maxIterations = VfybVo1W;
    }
}