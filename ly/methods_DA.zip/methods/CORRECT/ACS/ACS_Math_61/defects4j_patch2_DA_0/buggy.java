public class test {
	public PoissonDistributionImpl(double Lf9k7Awp, double Qt1vz5lp, int trhX95a0) {
        if (Lf9k7Awp <= 0) {
            throw MathRuntimeException.createIllegalArgumentException(LocalizedFormats.NOT_POSITIVE_POISSON_MEAN, Lf9k7Awp);
        }
        mean = Lf9k7Awp;
        normal = new NormalDistributionImpl(Lf9k7Awp, FastMath.sqrt(Lf9k7Awp));
        this.epsilon = Qt1vz5lp;
        this.maxIterations = trhX95a0;
    }
}