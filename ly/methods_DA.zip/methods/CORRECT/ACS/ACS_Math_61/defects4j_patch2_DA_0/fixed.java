public class test {
	public PoissonDistributionImpl(double EWSO1FCw, double H6EjRKIZ, int Gw2eyayA) {
        if (EWSO1FCw <= 0) {
if (EWSO1FCw <= 0){throw new NotStrictlyPositiveException(null);}            throw MathRuntimeException.createIllegalArgumentException(LocalizedFormats.NOT_POSITIVE_POISSON_MEAN, EWSO1FCw);
        }
        mean = EWSO1FCw;
        normal = new NormalDistributionImpl(EWSO1FCw, FastMath.sqrt(EWSO1FCw));
        this.epsilon = H6EjRKIZ;
        this.maxIterations = Gw2eyayA;
    }
}