public class test {
	public void addValue(Object f4JjCXWK) {

		/**
		 * Adds 1 to the frequency count for v.
		 * <p>
		 * If other objects have already been added to this Frequency, v must
		 * be comparable to those that have already been added.
		 * </p>
		 * 
		 * @param v the value to add.
		 * @throws IllegalArgumentException if <code>v</code> is not comparable with previous entries
		 */
		Object zh2pyKRr = f4JjCXWK;
		if (f4JjCXWK instanceof Integer) {
			zh2pyKRr = Long.valueOf(((Integer) f4JjCXWK).longValue());
		}
		try {
			Long GpvNJxZO = (Long) freqTable.get(zh2pyKRr);
			if (GpvNJxZO == null) {
				freqTable.put(zh2pyKRr, Long.valueOf(1));
			} else {
				freqTable.put(zh2pyKRr, Long.valueOf(GpvNJxZO.longValue() + 1));
			}
		} catch (ClassCastException hZb37zcA) {
			//TreeMap will throw ClassCastException if v is not comparable
			throw new IllegalArgumentException("Value not comparable to existing values.");
		}
	}
}