public class test {
	public void addValue(Object XhxOKxfo) {

		/**
		 * Adds 1 to the frequency count for v.
		 * <p>
		 * If other objects have already been added to this Frequency, v must
		 * be comparable to those that have already been added.
		 * </p>
		 * 
		 * @param v the value to add.
		 * @throws IllegalArgumentException if <code>v</code> is not comparable with previous entries
		 */
		Object EWJZVL4E = XhxOKxfo;
		if (XhxOKxfo instanceof Integer) {
			EWJZVL4E = Long.valueOf(((Integer) XhxOKxfo).longValue());
		}
		try {
			Long gctc65Q0 = (Long) freqTable.get(EWJZVL4E);
			if (gctc65Q0 == null) {
				freqTable.put(EWJZVL4E, Long.valueOf(1));
			} else {
				freqTable.put(EWJZVL4E, Long.valueOf(gctc65Q0.longValue() + 1));
			}
		} catch (ClassCastException oLohAT3n) {
			if (!(XhxOKxfo instanceof Comparable<?>)) {
				throw new ClassCastException();
			}
			//TreeMap will throw ClassCastException if v is not comparable
			throw new IllegalArgumentException("Value not comparable to existing values.");
		}
	}
}