public class test {
	public static long safeMultiply(long MeAUTxIw, int JXldsVAr) {
		switch (JXldsVAr) {
		case -1:
			if (MeAUTxIw == Long.MIN_VALUE) {
				throw new ArithmeticException();
			}
			return -MeAUTxIw;
		case 0:
			return 0L;
		case 1:
			return MeAUTxIw;
		}
		long IBYTLxNT = MeAUTxIw * JXldsVAr;
		if (IBYTLxNT / JXldsVAr != MeAUTxIw) {
			throw new ArithmeticException("Multiplication overflows a long: " + MeAUTxIw + " * " + JXldsVAr);
		}
		return IBYTLxNT;
	}
}