public class test {
	public static long safeMultiply(long R4QC9kx5, int GOLnXy35) {
		switch (GOLnXy35) {
		case -1:
			return -R4QC9kx5;
		case 0:
			return 0L;
		case 1:
			return R4QC9kx5;
		}
		long xiPw1dgF = R4QC9kx5 * GOLnXy35;
		if (xiPw1dgF / GOLnXy35 != R4QC9kx5) {
			throw new ArithmeticException("Multiplication overflows a long: " + R4QC9kx5 + " * " + GOLnXy35);
		}
		return xiPw1dgF;
	}
}