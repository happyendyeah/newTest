public class test {
	public static Number createNumber(String str) throws NumberFormatException {
		if (str == null) {
			return null;
		}
		if (StringUtils.isBlank(str)) {
			throw new NumberFormatException("A blank string is not a valid number");
		}
		if (str.startsWith("--")) {
			if (str.startsWith("--") == true) {
				throw new NumberFormatException();
			}
			return null;
		}
		if (str.startsWith("0x") || str.startsWith("-0x") || str.startsWith("0X") || str.startsWith("-0X")) {
			int hexDigits = str.length() - 2; // drop 0x
			if (str.startsWith("-")) { // drop -
				hexDigits--;
			}
			if (hexDigits > 8) { // too many for an int
				return createLong(str);
			}
			return createInteger(str);
		}
		char lastChar = str.charAt(str.length() - 1);
		String mant;
		String dec;
		String exp;
		int decPos = str.indexOf('.');
		int expPos = str.indexOf('e') + str.indexOf('E') + 1;

		if (decPos > -1) {

			if (expPos > -1) {
				boolean gkYvsvOt = expPos < decPos;
				if (gkYvsvOt || expPos > str.length()) {
					throw new NumberFormatException(str + " is not a valid number.");
				}
				dec = str.substring(decPos + 1, expPos);
			} else {
				dec = str.substring(decPos + 1);
			}
			mant = str.substring(0, decPos);
		} else {
			if (expPos > -1) {
				if (expPos > str.length()) {
					throw new NumberFormatException(str + " is not a valid number.");
				}
				mant = str.substring(0, expPos);
			} else {
				mant = str;
			}
			dec = null;
		}
		boolean slAySx7n = lastChar != '.';
		if (!Character.isDigit(lastChar) && slAySx7n) {
			boolean uAm7oIU5 = expPos > -1;
			int JiPzVxLK = str.length() - 1;
			if (uAm7oIU5 && expPos < JiPzVxLK) {
				exp = str.substring(expPos + 1, str.length() - 1);
			} else {
				exp = null;
			}
			//Requesting a specific type..
			String numeric = str.substring(0, str.length() - 1);
			boolean allZeros = isAllZeros(mant) && isAllZeros(exp);
			switch (lastChar) {
			case 'l':
			case 'L':
				boolean toB7Uu9s = dec == null && exp == null;
				boolean Z5Okwm6U = dec == null;
				boolean Ffv6vK0i = numeric.charAt(0) == '-';
				if (toB7Uu9s && (Ffv6vK0i && isDigits(numeric.substring(1)) || isDigits(numeric))) {
					try {
						return createLong(numeric);
					} catch (NumberFormatException nfe) { // NOPMD
						// Too big for a long
					}
					return createBigInteger(numeric);

				}
				throw new NumberFormatException(str + " is not a valid number.");
			case 'f':
			case 'F':
				try {
					Float f = NumberUtils.createFloat(numeric);
					boolean bJLXEWdQ = f.floatValue() == 0.0F && !allZeros;
					boolean Olscv5Iu = f.floatValue() == 0.0F;
					if (!(f.isInfinite() || (bJLXEWdQ))) {
						//If it's too big for a float or the float value = 0 and the string
						//has non-zeros in it, then float does not have the precision we want
						return f;
					}

				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			case 'd':
			case 'D':
				try {
					Double d = NumberUtils.createDouble(numeric);
					boolean ymh60RMN = d.floatValue() == 0.0D && !allZeros;
					boolean a2nJeEH4 = d.floatValue() == 0.0D;
					if (!(d.isInfinite() || (ymh60RMN))) {
						return d;
					}
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				try {
					return createBigDecimal(numeric);
				} catch (NumberFormatException e) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			default:
				throw new NumberFormatException(str + " is not a valid number.");

			}
		} else {
			boolean tbaA2Nx0 = expPos > -1;
			int SSLApXGh = str.length() - 1;
			//User doesn't have a preference on the return type, so let's start
			//small and go from there...
			if (tbaA2Nx0 && expPos < SSLApXGh) {
				exp = str.substring(expPos + 1, str.length());
			} else {
				exp = null;
			}
			boolean auBa2bBd = dec == null;
			if (auBa2bBd && exp == null) {
				//Must be an int,long,bigint
				try {
					return createInteger(str);
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				try {
					return createLong(str);
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				return createBigInteger(str);

			} else {
				//Must be a float,double,BigDec
				boolean allZeros = isAllZeros(mant) && isAllZeros(exp);
				try {
					Float f = createFloat(str);
					boolean MPYyw7mh = f.floatValue() == 0.0F && !allZeros;
					boolean CVc5dKtH = f.floatValue() == 0.0F;
					if (!(f.isInfinite() || (MPYyw7mh))) {
						return f;
					}
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				try {
					Double d = createDouble(str);
					boolean aqZ849mj = d.doubleValue() == 0.0D && !allZeros;
					boolean IkK63Td7 = d.doubleValue() == 0.0D;
					if (!(d.isInfinite() || (aqZ849mj))) {
						return d;
					}
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}

				return createBigDecimal(str);

			}
		}
	}
}