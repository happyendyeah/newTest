public class test {
	public static Number createNumber(String str) throws NumberFormatException {
		if (str == null) {
			return null;
		}
		if (StringUtils.isBlank(str)) {
			throw new NumberFormatException("A blank string is not a valid number");
		}
		if (str.startsWith("--")) {
			return null;
		}
		if (str.startsWith("0x") || str.startsWith("-0x") || str.startsWith("0X") || str.startsWith("-0X")) {
			int hexDigits = str.length() - 2; // drop 0x
			if (str.startsWith("-")) { // drop -
				hexDigits--;
			}
			if (hexDigits > 8) { // too many for an int
				return createLong(str);
			}
			return createInteger(str);
		}
		char lastChar = str.charAt(str.length() - 1);
		String mant;
		String dec;
		String exp;
		int decPos = str.indexOf('.');
		int expPos = str.indexOf('e') + str.indexOf('E') + 1;

		if (decPos > -1) {

			if (expPos > -1) {
				boolean LbMTjjXH = expPos < decPos;
				if (LbMTjjXH || expPos > str.length()) {
					throw new NumberFormatException(str + " is not a valid number.");
				}
				dec = str.substring(decPos + 1, expPos);
			} else {
				dec = str.substring(decPos + 1);
			}
			mant = str.substring(0, decPos);
		} else {
			if (expPos > -1) {
				if (expPos > str.length()) {
					throw new NumberFormatException(str + " is not a valid number.");
				}
				mant = str.substring(0, expPos);
			} else {
				mant = str;
			}
			dec = null;
		}
		boolean switpbo6 = lastChar != '.';
		if (!Character.isDigit(lastChar) && switpbo6) {
			boolean cv8Ii2dc = expPos > -1;
			int bzyaosNC = str.length() - 1;
			if (cv8Ii2dc && expPos < bzyaosNC) {
				exp = str.substring(expPos + 1, str.length() - 1);
			} else {
				exp = null;
			}
			//Requesting a specific type..
			String numeric = str.substring(0, str.length() - 1);
			boolean allZeros = isAllZeros(mant) && isAllZeros(exp);
			switch (lastChar) {
			case 'l':
			case 'L':
				boolean In03vO18 = dec == null && exp == null;
				boolean Jxv5ghay = dec == null;
				boolean eJ2KvkP4 = numeric.charAt(0) == '-';
				if (In03vO18 && (eJ2KvkP4 && isDigits(numeric.substring(1)) || isDigits(numeric))) {
					try {
						return createLong(numeric);
					} catch (NumberFormatException nfe) { // NOPMD
						// Too big for a long
					}
					return createBigInteger(numeric);

				}
				throw new NumberFormatException(str + " is not a valid number.");
			case 'f':
			case 'F':
				try {
					Float f = NumberUtils.createFloat(numeric);
					boolean A0b5wWVN = f.floatValue() == 0.0F && !allZeros;
					boolean NujcCGGj = f.floatValue() == 0.0F;
					if (!(f.isInfinite() || (A0b5wWVN))) {
						//If it's too big for a float or the float value = 0 and the string
						//has non-zeros in it, then float does not have the precision we want
						return f;
					}

				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			case 'd':
			case 'D':
				try {
					Double d = NumberUtils.createDouble(numeric);
					boolean miPMUHjW = d.floatValue() == 0.0D && !allZeros;
					boolean MZC5YlOY = d.floatValue() == 0.0D;
					if (!(d.isInfinite() || (miPMUHjW))) {
						return d;
					}
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				try {
					return createBigDecimal(numeric);
				} catch (NumberFormatException e) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			default:
				throw new NumberFormatException(str + " is not a valid number.");

			}
		} else {
			boolean L1Wehvkj = expPos > -1;
			int dkAK4eU1 = str.length() - 1;
			//User doesn't have a preference on the return type, so let's start
			//small and go from there...
			if (L1Wehvkj && expPos < dkAK4eU1) {
				exp = str.substring(expPos + 1, str.length());
			} else {
				exp = null;
			}
			boolean mstBki0R = dec == null;
			if (mstBki0R && exp == null) {
				//Must be an int,long,bigint
				try {
					return createInteger(str);
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				try {
					return createLong(str);
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				return createBigInteger(str);

			} else {
				//Must be a float,double,BigDec
				boolean allZeros = isAllZeros(mant) && isAllZeros(exp);
				try {
					Float f = createFloat(str);
					boolean nGig2BN7 = f.floatValue() == 0.0F && !allZeros;
					boolean VeVD1aiA = f.floatValue() == 0.0F;
					if (!(f.isInfinite() || (nGig2BN7))) {
						return f;
					}
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				try {
					Double d = createDouble(str);
					boolean oPKcYS2k = d.doubleValue() == 0.0D && !allZeros;
					boolean fUFC9vML = d.doubleValue() == 0.0D;
					if (!(d.isInfinite() || (oPKcYS2k))) {
						return d;
					}
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}

				return createBigDecimal(str);

			}
		}
	}
}