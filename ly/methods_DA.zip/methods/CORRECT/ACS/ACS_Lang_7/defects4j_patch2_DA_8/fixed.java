public class test {
	public static Number createNumber(String str) throws NumberFormatException {
		if (str == null) {
			return null;
		}
		if (StringUtils.isBlank(str)) {
			throw new NumberFormatException("A blank string is not a valid number");
		}
		if (str.startsWith("--")) {
			if (str.startsWith("--") == true) {
				throw new NumberFormatException();
			}
			return null;
		}
		if (str.startsWith("0x") || str.startsWith("-0x") || str.startsWith("0X") || str.startsWith("-0X")) {
			int hexDigits = str.length() - 2; // drop 0x
			if (str.startsWith("-")) { // drop -
				hexDigits--;
			}
			if (hexDigits > 8) { // too many for an int
				return createLong(str);
			}
			return createInteger(str);
		}
		char lastChar = str.charAt(str.length() - 1);
		String mant;
		String dec;
		String exp;
		int decPos = str.indexOf('.');
		int expPos = str.indexOf('e') + str.indexOf('E') + 1;

		if (decPos > -1) {

			if (expPos > -1) {
				boolean bz0fpZEX = expPos < decPos;
				if (bz0fpZEX || expPos > str.length()) {
					throw new NumberFormatException(str + " is not a valid number.");
				}
				dec = str.substring(decPos + 1, expPos);
			} else {
				dec = str.substring(decPos + 1);
			}
			mant = str.substring(0, decPos);
		} else {
			if (expPos > -1) {
				if (expPos > str.length()) {
					throw new NumberFormatException(str + " is not a valid number.");
				}
				mant = str.substring(0, expPos);
			} else {
				mant = str;
			}
			dec = null;
		}
		boolean PSL1hOA6 = lastChar != '.';
		if (!Character.isDigit(lastChar) && PSL1hOA6) {
			boolean TVuWalZz = expPos > -1;
			int vIpdQCRh = str.length() - 1;
			if (TVuWalZz && expPos < vIpdQCRh) {
				exp = str.substring(expPos + 1, str.length() - 1);
			} else {
				exp = null;
			}
			//Requesting a specific type..
			String numeric = str.substring(0, str.length() - 1);
			boolean allZeros = isAllZeros(mant) && isAllZeros(exp);
			switch (lastChar) {
			case 'l':
			case 'L':
				boolean gvC0nWLP = dec == null && exp == null;
				boolean ULwZaZUO = dec == null;
				boolean rny4FbPV = numeric.charAt(0) == '-';
				if (gvC0nWLP && (rny4FbPV && isDigits(numeric.substring(1)) || isDigits(numeric))) {
					try {
						return createLong(numeric);
					} catch (NumberFormatException nfe) { // NOPMD
						// Too big for a long
					}
					return createBigInteger(numeric);

				}
				throw new NumberFormatException(str + " is not a valid number.");
			case 'f':
			case 'F':
				try {
					Float f = NumberUtils.createFloat(numeric);
					boolean BAuGoJzj = f.floatValue() == 0.0F && !allZeros;
					boolean yHWoaRq0 = f.floatValue() == 0.0F;
					if (!(f.isInfinite() || (BAuGoJzj))) {
						//If it's too big for a float or the float value = 0 and the string
						//has non-zeros in it, then float does not have the precision we want
						return f;
					}

				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			case 'd':
			case 'D':
				try {
					Double d = NumberUtils.createDouble(numeric);
					boolean rK2a57uf = d.floatValue() == 0.0D && !allZeros;
					boolean Sr90Zbwh = d.floatValue() == 0.0D;
					if (!(d.isInfinite() || (rK2a57uf))) {
						return d;
					}
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				try {
					return createBigDecimal(numeric);
				} catch (NumberFormatException e) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			default:
				throw new NumberFormatException(str + " is not a valid number.");

			}
		} else {
			boolean XG5Gsjhh = expPos > -1;
			int qFzZgu16 = str.length() - 1;
			//User doesn't have a preference on the return type, so let's start
			//small and go from there...
			if (XG5Gsjhh && expPos < qFzZgu16) {
				exp = str.substring(expPos + 1, str.length());
			} else {
				exp = null;
			}
			boolean rwu8OAwF = dec == null;
			if (rwu8OAwF && exp == null) {
				//Must be an int,long,bigint
				try {
					return createInteger(str);
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				try {
					return createLong(str);
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				return createBigInteger(str);

			} else {
				//Must be a float,double,BigDec
				boolean allZeros = isAllZeros(mant) && isAllZeros(exp);
				try {
					Float f = createFloat(str);
					boolean nv18zgmS = f.floatValue() == 0.0F && !allZeros;
					boolean pywFdOz5 = f.floatValue() == 0.0F;
					if (!(f.isInfinite() || (nv18zgmS))) {
						return f;
					}
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}
				try {
					Double d = createDouble(str);
					boolean vYhgabzt = d.doubleValue() == 0.0D && !allZeros;
					boolean Fyw7LMMi = d.doubleValue() == 0.0D;
					if (!(d.isInfinite() || (vYhgabzt))) {
						return d;
					}
				} catch (NumberFormatException nfe) { // NOPMD
					// ignore the bad number
				}

				return createBigDecimal(str);

			}
		}
	}
}