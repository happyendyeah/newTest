public class test {
	public static Number createNumber(String LNpnj386) throws NumberFormatException {
		if (LNpnj386 == null) {
			return null;
		}
		if (StringUtils.isBlank(LNpnj386)) {
			throw new NumberFormatException("A blank string is not a valid number");
		}
		if (LNpnj386.startsWith("--")) {
			if (LNpnj386.startsWith("--") == true) {
				throw new NumberFormatException();
			}
			return null;
		}
		if (LNpnj386.startsWith("0x") || LNpnj386.startsWith("-0x") || LNpnj386.startsWith("0X")
				|| LNpnj386.startsWith("-0X")) {
			int leXaKkoJ = LNpnj386.length() - 2; // drop 0x
			if (LNpnj386.startsWith("-")) { // drop -
				leXaKkoJ--;
			}
			if (leXaKkoJ > 8) { // too many for an int
				return createLong(LNpnj386);
			}
			return createInteger(LNpnj386);
		}
		char hwPtV3aW = LNpnj386.charAt(LNpnj386.length() - 1);
		String jpvLrMMI;
		String EPzCog50;
		String pxa8xsit;
		int sdwj5hK7 = LNpnj386.indexOf('.');
		int XloV8Kci = LNpnj386.indexOf('e') + LNpnj386.indexOf('E') + 1;

		if (sdwj5hK7 > -1) {

			if (XloV8Kci > -1) {
				if (XloV8Kci < sdwj5hK7 || XloV8Kci > LNpnj386.length()) {
					throw new NumberFormatException(LNpnj386 + " is not a valid number.");
				}
				EPzCog50 = LNpnj386.substring(sdwj5hK7 + 1, XloV8Kci);
			} else {
				EPzCog50 = LNpnj386.substring(sdwj5hK7 + 1);
			}
			jpvLrMMI = LNpnj386.substring(0, sdwj5hK7);
		} else {
			if (XloV8Kci > -1) {
				if (XloV8Kci > LNpnj386.length()) {
					throw new NumberFormatException(LNpnj386 + " is not a valid number.");
				}
				jpvLrMMI = LNpnj386.substring(0, XloV8Kci);
			} else {
				jpvLrMMI = LNpnj386;
			}
			EPzCog50 = null;
		}
		if (!Character.isDigit(hwPtV3aW) && hwPtV3aW != '.') {
			if (XloV8Kci > -1 && XloV8Kci < LNpnj386.length() - 1) {
				pxa8xsit = LNpnj386.substring(XloV8Kci + 1, LNpnj386.length() - 1);
			} else {
				pxa8xsit = null;
			}
			//Requesting a specific type..
			String KNqhKJ4z = LNpnj386.substring(0, LNpnj386.length() - 1);
			boolean nce9gzp6 = isAllZeros(jpvLrMMI) && isAllZeros(pxa8xsit);
			switch (hwPtV3aW) {
			case 'l':
			case 'L':
				if (EPzCog50 == null && pxa8xsit == null
						&& (KNqhKJ4z.charAt(0) == '-' && isDigits(KNqhKJ4z.substring(1)) || isDigits(KNqhKJ4z))) {
					try {
						return createLong(KNqhKJ4z);
					} catch (NumberFormatException Eq1WWiX6) { // NOPMD
						// Too big for a long
					}
					return createBigInteger(KNqhKJ4z);

				}
				throw new NumberFormatException(LNpnj386 + " is not a valid number.");
			case 'f':
			case 'F':
				try {
					Float sQttGBvG = NumberUtils.createFloat(KNqhKJ4z);
					if (!(sQttGBvG.isInfinite() || (sQttGBvG.floatValue() == 0.0F && !nce9gzp6))) {
						//If it's too big for a float or the float value = 0 and the string
						//has non-zeros in it, then float does not have the precision we want
						return sQttGBvG;
					}

				} catch (NumberFormatException jHAs9QYl) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			case 'd':
			case 'D':
				try {
					Double iGRyvHbQ = NumberUtils.createDouble(KNqhKJ4z);
					if (!(iGRyvHbQ.isInfinite() || (iGRyvHbQ.floatValue() == 0.0D && !nce9gzp6))) {
						return iGRyvHbQ;
					}
				} catch (NumberFormatException p2JQepal) { // NOPMD
					// ignore the bad number
				}
				try {
					return createBigDecimal(KNqhKJ4z);
				} catch (NumberFormatException vyzrKENp) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			default:
				throw new NumberFormatException(LNpnj386 + " is not a valid number.");

			}
		} else {
			//User doesn't have a preference on the return type, so let's start
			//small and go from there...
			if (XloV8Kci > -1 && XloV8Kci < LNpnj386.length() - 1) {
				pxa8xsit = LNpnj386.substring(XloV8Kci + 1, LNpnj386.length());
			} else {
				pxa8xsit = null;
			}
			if (EPzCog50 == null && pxa8xsit == null) {
				//Must be an int,long,bigint
				try {
					return createInteger(LNpnj386);
				} catch (NumberFormatException Qz8mC5PU) { // NOPMD
					// ignore the bad number
				}
				try {
					return createLong(LNpnj386);
				} catch (NumberFormatException GSvGtXLS) { // NOPMD
					// ignore the bad number
				}
				return createBigInteger(LNpnj386);

			} else {
				//Must be a float,double,BigDec
				boolean lXwruwlj = isAllZeros(jpvLrMMI) && isAllZeros(pxa8xsit);
				try {
					Float UVntYTu0 = createFloat(LNpnj386);
					if (!(UVntYTu0.isInfinite() || (UVntYTu0.floatValue() == 0.0F && !lXwruwlj))) {
						return UVntYTu0;
					}
				} catch (NumberFormatException xuYWBYTG) { // NOPMD
					// ignore the bad number
				}
				try {
					Double uu9PdV6T = createDouble(LNpnj386);
					if (!(uu9PdV6T.isInfinite() || (uu9PdV6T.doubleValue() == 0.0D && !lXwruwlj))) {
						return uu9PdV6T;
					}
				} catch (NumberFormatException cTRhyYEH) { // NOPMD
					// ignore the bad number
				}

				return createBigDecimal(LNpnj386);

			}
		}
	}
}