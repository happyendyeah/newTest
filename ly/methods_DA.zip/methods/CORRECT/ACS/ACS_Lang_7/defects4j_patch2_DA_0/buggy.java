public class test {
	public static Number createNumber(String Kh3T0PXP) throws NumberFormatException {
		if (Kh3T0PXP == null) {
			return null;
		}
		if (StringUtils.isBlank(Kh3T0PXP)) {
			throw new NumberFormatException("A blank string is not a valid number");
		}
		if (Kh3T0PXP.startsWith("--")) {
			return null;
		}
		if (Kh3T0PXP.startsWith("0x") || Kh3T0PXP.startsWith("-0x") || Kh3T0PXP.startsWith("0X")
				|| Kh3T0PXP.startsWith("-0X")) {
			int qxbhFeMI = Kh3T0PXP.length() - 2; // drop 0x
			if (Kh3T0PXP.startsWith("-")) { // drop -
				qxbhFeMI--;
			}
			if (qxbhFeMI > 8) { // too many for an int
				return createLong(Kh3T0PXP);
			}
			return createInteger(Kh3T0PXP);
		}
		char SAgLep5z = Kh3T0PXP.charAt(Kh3T0PXP.length() - 1);
		String iBQGm4tM;
		String IPr5jEpn;
		String q6drKGxi;
		int Gj3gnKmT = Kh3T0PXP.indexOf('.');
		int N6wWYoF1 = Kh3T0PXP.indexOf('e') + Kh3T0PXP.indexOf('E') + 1;

		if (Gj3gnKmT > -1) {

			if (N6wWYoF1 > -1) {
				if (N6wWYoF1 < Gj3gnKmT || N6wWYoF1 > Kh3T0PXP.length()) {
					throw new NumberFormatException(Kh3T0PXP + " is not a valid number.");
				}
				IPr5jEpn = Kh3T0PXP.substring(Gj3gnKmT + 1, N6wWYoF1);
			} else {
				IPr5jEpn = Kh3T0PXP.substring(Gj3gnKmT + 1);
			}
			iBQGm4tM = Kh3T0PXP.substring(0, Gj3gnKmT);
		} else {
			if (N6wWYoF1 > -1) {
				if (N6wWYoF1 > Kh3T0PXP.length()) {
					throw new NumberFormatException(Kh3T0PXP + " is not a valid number.");
				}
				iBQGm4tM = Kh3T0PXP.substring(0, N6wWYoF1);
			} else {
				iBQGm4tM = Kh3T0PXP;
			}
			IPr5jEpn = null;
		}
		if (!Character.isDigit(SAgLep5z) && SAgLep5z != '.') {
			if (N6wWYoF1 > -1 && N6wWYoF1 < Kh3T0PXP.length() - 1) {
				q6drKGxi = Kh3T0PXP.substring(N6wWYoF1 + 1, Kh3T0PXP.length() - 1);
			} else {
				q6drKGxi = null;
			}
			//Requesting a specific type..
			String OoskGbnk = Kh3T0PXP.substring(0, Kh3T0PXP.length() - 1);
			boolean BCabrzMA = isAllZeros(iBQGm4tM) && isAllZeros(q6drKGxi);
			switch (SAgLep5z) {
			case 'l':
			case 'L':
				if (IPr5jEpn == null && q6drKGxi == null
						&& (OoskGbnk.charAt(0) == '-' && isDigits(OoskGbnk.substring(1)) || isDigits(OoskGbnk))) {
					try {
						return createLong(OoskGbnk);
					} catch (NumberFormatException RgpOhXBK) { // NOPMD
						// Too big for a long
					}
					return createBigInteger(OoskGbnk);

				}
				throw new NumberFormatException(Kh3T0PXP + " is not a valid number.");
			case 'f':
			case 'F':
				try {
					Float kYhdXDzK = NumberUtils.createFloat(OoskGbnk);
					if (!(kYhdXDzK.isInfinite() || (kYhdXDzK.floatValue() == 0.0F && !BCabrzMA))) {
						//If it's too big for a float or the float value = 0 and the string
						//has non-zeros in it, then float does not have the precision we want
						return kYhdXDzK;
					}

				} catch (NumberFormatException ujXE4Wnf) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			case 'd':
			case 'D':
				try {
					Double CDAKUZgO = NumberUtils.createDouble(OoskGbnk);
					if (!(CDAKUZgO.isInfinite() || (CDAKUZgO.floatValue() == 0.0D && !BCabrzMA))) {
						return CDAKUZgO;
					}
				} catch (NumberFormatException RLn2nc4q) { // NOPMD
					// ignore the bad number
				}
				try {
					return createBigDecimal(OoskGbnk);
				} catch (NumberFormatException SAwR2R2P) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			default:
				throw new NumberFormatException(Kh3T0PXP + " is not a valid number.");

			}
		} else {
			//User doesn't have a preference on the return type, so let's start
			//small and go from there...
			if (N6wWYoF1 > -1 && N6wWYoF1 < Kh3T0PXP.length() - 1) {
				q6drKGxi = Kh3T0PXP.substring(N6wWYoF1 + 1, Kh3T0PXP.length());
			} else {
				q6drKGxi = null;
			}
			if (IPr5jEpn == null && q6drKGxi == null) {
				//Must be an int,long,bigint
				try {
					return createInteger(Kh3T0PXP);
				} catch (NumberFormatException UKyXxbIr) { // NOPMD
					// ignore the bad number
				}
				try {
					return createLong(Kh3T0PXP);
				} catch (NumberFormatException i6aMEqMa) { // NOPMD
					// ignore the bad number
				}
				return createBigInteger(Kh3T0PXP);

			} else {
				//Must be a float,double,BigDec
				boolean igI3UXQk = isAllZeros(iBQGm4tM) && isAllZeros(q6drKGxi);
				try {
					Float Suqn9bV4 = createFloat(Kh3T0PXP);
					if (!(Suqn9bV4.isInfinite() || (Suqn9bV4.floatValue() == 0.0F && !igI3UXQk))) {
						return Suqn9bV4;
					}
				} catch (NumberFormatException BM8ZubHX) { // NOPMD
					// ignore the bad number
				}
				try {
					Double lr28clY0 = createDouble(Kh3T0PXP);
					if (!(lr28clY0.isInfinite() || (lr28clY0.doubleValue() == 0.0D && !igI3UXQk))) {
						return lr28clY0;
					}
				} catch (NumberFormatException AQ28Svq3) { // NOPMD
					// ignore the bad number
				}

				return createBigDecimal(Kh3T0PXP);

			}
		}
	}
}