public class test {
	public static Number createNumber(String CBLJUL4m) throws NumberFormatException {
		if (CBLJUL4m == null) {
			return null;
		}
		if (StringUtils.isBlank(CBLJUL4m)) {
			throw new NumberFormatException("A blank string is not a valid number");
		}
		if (CBLJUL4m.startsWith("--")) {
			if (CBLJUL4m.startsWith("--") == true) {
				throw new NumberFormatException();
			}
			return null;
		}
		if (CBLJUL4m.startsWith("0x") || CBLJUL4m.startsWith("-0x") || CBLJUL4m.startsWith("0X")
				|| CBLJUL4m.startsWith("-0X")) {
			int GiYZVO6f = CBLJUL4m.length() - 2; // drop 0x
			if (CBLJUL4m.startsWith("-")) { // drop -
				GiYZVO6f--;
			}
			if (GiYZVO6f > 8) { // too many for an int
				return createLong(CBLJUL4m);
			}
			return createInteger(CBLJUL4m);
		}
		char DMY9g38y = CBLJUL4m.charAt(CBLJUL4m.length() - 1);
		String DcmXW0cn;
		String S7x4Ff7a;
		String wDFEa1xH;
		int FGaysOze = CBLJUL4m.indexOf('.');
		int rfCzK4uu = CBLJUL4m.indexOf('e') + CBLJUL4m.indexOf('E') + 1;

		if (FGaysOze > -1) {

			if (rfCzK4uu > -1) {
				if (rfCzK4uu < FGaysOze || rfCzK4uu > CBLJUL4m.length()) {
					throw new NumberFormatException(CBLJUL4m + " is not a valid number.");
				}
				S7x4Ff7a = CBLJUL4m.substring(FGaysOze + 1, rfCzK4uu);
			} else {
				S7x4Ff7a = CBLJUL4m.substring(FGaysOze + 1);
			}
			DcmXW0cn = CBLJUL4m.substring(0, FGaysOze);
		} else {
			if (rfCzK4uu > -1) {
				if (rfCzK4uu > CBLJUL4m.length()) {
					throw new NumberFormatException(CBLJUL4m + " is not a valid number.");
				}
				DcmXW0cn = CBLJUL4m.substring(0, rfCzK4uu);
			} else {
				DcmXW0cn = CBLJUL4m;
			}
			S7x4Ff7a = null;
		}
		if (!Character.isDigit(DMY9g38y) && DMY9g38y != '.') {
			if (rfCzK4uu > -1 && rfCzK4uu < CBLJUL4m.length() - 1) {
				wDFEa1xH = CBLJUL4m.substring(rfCzK4uu + 1, CBLJUL4m.length() - 1);
			} else {
				wDFEa1xH = null;
			}
			//Requesting a specific type..
			String JFcpNMdu = CBLJUL4m.substring(0, CBLJUL4m.length() - 1);
			boolean opiqLy9o = isAllZeros(DcmXW0cn) && isAllZeros(wDFEa1xH);
			switch (DMY9g38y) {
			case 'l':
			case 'L':
				if (S7x4Ff7a == null && wDFEa1xH == null
						&& (JFcpNMdu.charAt(0) == '-' && isDigits(JFcpNMdu.substring(1)) || isDigits(JFcpNMdu))) {
					try {
						return createLong(JFcpNMdu);
					} catch (NumberFormatException ob1njtMX) { // NOPMD
						// Too big for a long
					}
					return createBigInteger(JFcpNMdu);

				}
				throw new NumberFormatException(CBLJUL4m + " is not a valid number.");
			case 'f':
			case 'F':
				try {
					Float MF81oZk6 = NumberUtils.createFloat(JFcpNMdu);
					if (!(MF81oZk6.isInfinite() || (MF81oZk6.floatValue() == 0.0F && !opiqLy9o))) {
						//If it's too big for a float or the float value = 0 and the string
						//has non-zeros in it, then float does not have the precision we want
						return MF81oZk6;
					}

				} catch (NumberFormatException toUG8Deh) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			case 'd':
			case 'D':
				try {
					Double YawfKxYM = NumberUtils.createDouble(JFcpNMdu);
					if (!(YawfKxYM.isInfinite() || (YawfKxYM.floatValue() == 0.0D && !opiqLy9o))) {
						return YawfKxYM;
					}
				} catch (NumberFormatException CYM8csIf) { // NOPMD
					// ignore the bad number
				}
				try {
					return createBigDecimal(JFcpNMdu);
				} catch (NumberFormatException pdQxcQPG) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			default:
				throw new NumberFormatException(CBLJUL4m + " is not a valid number.");

			}
		} else {
			//User doesn't have a preference on the return type, so let's start
			//small and go from there...
			if (rfCzK4uu > -1 && rfCzK4uu < CBLJUL4m.length() - 1) {
				wDFEa1xH = CBLJUL4m.substring(rfCzK4uu + 1, CBLJUL4m.length());
			} else {
				wDFEa1xH = null;
			}
			if (S7x4Ff7a == null && wDFEa1xH == null) {
				//Must be an int,long,bigint
				try {
					return createInteger(CBLJUL4m);
				} catch (NumberFormatException ua1l57Fe) { // NOPMD
					// ignore the bad number
				}
				try {
					return createLong(CBLJUL4m);
				} catch (NumberFormatException gZ2EZEGT) { // NOPMD
					// ignore the bad number
				}
				return createBigInteger(CBLJUL4m);

			} else {
				//Must be a float,double,BigDec
				boolean bpFHP6oA = isAllZeros(DcmXW0cn) && isAllZeros(wDFEa1xH);
				try {
					Float wh0SUh6E = createFloat(CBLJUL4m);
					if (!(wh0SUh6E.isInfinite() || (wh0SUh6E.floatValue() == 0.0F && !bpFHP6oA))) {
						return wh0SUh6E;
					}
				} catch (NumberFormatException cWFAoOjR) { // NOPMD
					// ignore the bad number
				}
				try {
					Double LTzyHRkt = createDouble(CBLJUL4m);
					if (!(LTzyHRkt.isInfinite() || (LTzyHRkt.doubleValue() == 0.0D && !bpFHP6oA))) {
						return LTzyHRkt;
					}
				} catch (NumberFormatException jUbPVHIK) { // NOPMD
					// ignore the bad number
				}

				return createBigDecimal(CBLJUL4m);

			}
		}
	}
}