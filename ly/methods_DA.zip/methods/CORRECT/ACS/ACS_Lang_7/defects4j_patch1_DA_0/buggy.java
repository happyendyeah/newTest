public class test {
	public static Number createNumber(String JIhbGi9V) throws NumberFormatException {
		if (JIhbGi9V == null) {
			return null;
		}
		if (StringUtils.isBlank(JIhbGi9V)) {
			throw new NumberFormatException("A blank string is not a valid number");
		}
		if (JIhbGi9V.startsWith("--")) {
			return null;
		}
		if (JIhbGi9V.startsWith("0x") || JIhbGi9V.startsWith("-0x") || JIhbGi9V.startsWith("0X")
				|| JIhbGi9V.startsWith("-0X")) {
			int OvjcSTTy = JIhbGi9V.length() - 2; // drop 0x
			if (JIhbGi9V.startsWith("-")) { // drop -
				OvjcSTTy--;
			}
			if (OvjcSTTy > 8) { // too many for an int
				return createLong(JIhbGi9V);
			}
			return createInteger(JIhbGi9V);
		}
		char FXI70NUA = JIhbGi9V.charAt(JIhbGi9V.length() - 1);
		String lL7FqDyx;
		String Xtye5phD;
		String tDqlX9rJ;
		int oPBwItkg = JIhbGi9V.indexOf('.');
		int JjAPwzY0 = JIhbGi9V.indexOf('e') + JIhbGi9V.indexOf('E') + 1;

		if (oPBwItkg > -1) {

			if (JjAPwzY0 > -1) {
				if (JjAPwzY0 < oPBwItkg || JjAPwzY0 > JIhbGi9V.length()) {
					throw new NumberFormatException(JIhbGi9V + " is not a valid number.");
				}
				Xtye5phD = JIhbGi9V.substring(oPBwItkg + 1, JjAPwzY0);
			} else {
				Xtye5phD = JIhbGi9V.substring(oPBwItkg + 1);
			}
			lL7FqDyx = JIhbGi9V.substring(0, oPBwItkg);
		} else {
			if (JjAPwzY0 > -1) {
				if (JjAPwzY0 > JIhbGi9V.length()) {
					throw new NumberFormatException(JIhbGi9V + " is not a valid number.");
				}
				lL7FqDyx = JIhbGi9V.substring(0, JjAPwzY0);
			} else {
				lL7FqDyx = JIhbGi9V;
			}
			Xtye5phD = null;
		}
		if (!Character.isDigit(FXI70NUA) && FXI70NUA != '.') {
			if (JjAPwzY0 > -1 && JjAPwzY0 < JIhbGi9V.length() - 1) {
				tDqlX9rJ = JIhbGi9V.substring(JjAPwzY0 + 1, JIhbGi9V.length() - 1);
			} else {
				tDqlX9rJ = null;
			}
			//Requesting a specific type..
			String ytLHyA27 = JIhbGi9V.substring(0, JIhbGi9V.length() - 1);
			boolean YXY9ocUA = isAllZeros(lL7FqDyx) && isAllZeros(tDqlX9rJ);
			switch (FXI70NUA) {
			case 'l':
			case 'L':
				if (Xtye5phD == null && tDqlX9rJ == null
						&& (ytLHyA27.charAt(0) == '-' && isDigits(ytLHyA27.substring(1)) || isDigits(ytLHyA27))) {
					try {
						return createLong(ytLHyA27);
					} catch (NumberFormatException DL4OL5RG) { // NOPMD
						// Too big for a long
					}
					return createBigInteger(ytLHyA27);

				}
				throw new NumberFormatException(JIhbGi9V + " is not a valid number.");
			case 'f':
			case 'F':
				try {
					Float wAordDF0 = NumberUtils.createFloat(ytLHyA27);
					if (!(wAordDF0.isInfinite() || (wAordDF0.floatValue() == 0.0F && !YXY9ocUA))) {
						//If it's too big for a float or the float value = 0 and the string
						//has non-zeros in it, then float does not have the precision we want
						return wAordDF0;
					}

				} catch (NumberFormatException kuUS6R6y) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			case 'd':
			case 'D':
				try {
					Double QISGjeQc = NumberUtils.createDouble(ytLHyA27);
					if (!(QISGjeQc.isInfinite() || (QISGjeQc.floatValue() == 0.0D && !YXY9ocUA))) {
						return QISGjeQc;
					}
				} catch (NumberFormatException X4sqIsbL) { // NOPMD
					// ignore the bad number
				}
				try {
					return createBigDecimal(ytLHyA27);
				} catch (NumberFormatException gmd6j8Rs) { // NOPMD
					// ignore the bad number
				}
				//$FALL-THROUGH$
			default:
				throw new NumberFormatException(JIhbGi9V + " is not a valid number.");

			}
		} else {
			//User doesn't have a preference on the return type, so let's start
			//small and go from there...
			if (JjAPwzY0 > -1 && JjAPwzY0 < JIhbGi9V.length() - 1) {
				tDqlX9rJ = JIhbGi9V.substring(JjAPwzY0 + 1, JIhbGi9V.length());
			} else {
				tDqlX9rJ = null;
			}
			if (Xtye5phD == null && tDqlX9rJ == null) {
				//Must be an int,long,bigint
				try {
					return createInteger(JIhbGi9V);
				} catch (NumberFormatException HL93kfn5) { // NOPMD
					// ignore the bad number
				}
				try {
					return createLong(JIhbGi9V);
				} catch (NumberFormatException eYQimnFa) { // NOPMD
					// ignore the bad number
				}
				return createBigInteger(JIhbGi9V);

			} else {
				//Must be a float,double,BigDec
				boolean iacnROoW = isAllZeros(lL7FqDyx) && isAllZeros(tDqlX9rJ);
				try {
					Float RfhuouoJ = createFloat(JIhbGi9V);
					if (!(RfhuouoJ.isInfinite() || (RfhuouoJ.floatValue() == 0.0F && !iacnROoW))) {
						return RfhuouoJ;
					}
				} catch (NumberFormatException svjmn6kf) { // NOPMD
					// ignore the bad number
				}
				try {
					Double fG5CRpvr = createDouble(JIhbGi9V);
					if (!(fG5CRpvr.isInfinite() || (fG5CRpvr.doubleValue() == 0.0D && !iacnROoW))) {
						return fG5CRpvr;
					}
				} catch (NumberFormatException qwTmf9hG) { // NOPMD
					// ignore the bad number
				}

				return createBigDecimal(JIhbGi9V);

			}
		}
	}
}