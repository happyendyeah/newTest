public class test {
	public ElitisticListPopulation(final List<Chromosome> A3UGseOY,
                                   final int IwwQY1OG,
                                   final double vRwHpGcW) {
        super(A3UGseOY, IwwQY1OG);
        this.elitismRate = vRwHpGcW;
 	if (vRwHpGcW>(double)1.0){throw new OutOfRangeException(null,null,null);}
 	if (vRwHpGcW<(double)0.0){throw new OutOfRangeException(null,null,null);}
    }

	public ElitisticListPopulation(final int yH9rnbbG, final double BsV6LBcE) {
        super(yH9rnbbG);
        this.elitismRate = BsV6LBcE;
 	if (BsV6LBcE>(double)1.0){throw new OutOfRangeException(null,null,null);}
 	if (BsV6LBcE<(double)0.0){throw new OutOfRangeException(null,null,null);}


    }
}