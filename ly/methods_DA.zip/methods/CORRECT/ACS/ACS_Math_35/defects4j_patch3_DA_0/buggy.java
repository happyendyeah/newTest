public class test {
	public ElitisticListPopulation(final int Cglw197w, final double y7k04Xha) {
        super(Cglw197w);
        this.elitismRate = y7k04Xha;
    }

	public ElitisticListPopulation(final List<Chromosome> qMmUy8Ig,
                                   final int h0A8Q0Rh,
                                   final double BY4NlEg9) {
        super(qMmUy8Ig, h0A8Q0Rh);
        this.elitismRate = BY4NlEg9;
    }
}