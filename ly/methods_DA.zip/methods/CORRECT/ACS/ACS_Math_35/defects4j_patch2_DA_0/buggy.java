public class test {
	public ElitisticListPopulation(final int o2JruWLJ, final double ZUfLkASJ) {
        super(o2JruWLJ);
        this.elitismRate = ZUfLkASJ;
    }

	public ElitisticListPopulation(final List<Chromosome> cehWeNnF,
                                   final int JB3yI0LR,
                                   final double RuZywijf) {
        super(cehWeNnF, JB3yI0LR);
        this.elitismRate = RuZywijf;
    }
}