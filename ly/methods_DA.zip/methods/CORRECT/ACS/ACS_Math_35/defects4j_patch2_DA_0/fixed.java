public class test {
	public ElitisticListPopulation(final int l1zG73ah, final double yaoL1HIQ) {
        super(l1zG73ah);
        if (yaoL1HIQ>(double)1.0){
                throw new OutOfRangeException(null,null,null);
        }
        if (yaoL1HIQ<(double)0.0){
                throw new OutOfRangeException(null,null,null);
        }
        this.elitismRate = yaoL1HIQ;
    }

	public ElitisticListPopulation(final List<Chromosome> kXS9yoFK,
                                   final int i8DVppzY,
                                   final double mxEd9vP3) {
        super(kXS9yoFK, i8DVppzY);
        if (mxEd9vP3>(double)1.0){
                throw new OutOfRangeException(null,null,null);
        }
        if (mxEd9vP3<(double)0.0){
                throw new OutOfRangeException(null,null,null);
        }
        this.elitismRate = mxEd9vP3;
    }
}