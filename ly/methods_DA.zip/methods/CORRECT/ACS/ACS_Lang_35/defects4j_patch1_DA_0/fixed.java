public class test {
	public static <T> T[] add(T[] ANmAT928, T kdEmooP3) {
		Class<?> Bd5ERyrN;
		if (ANmAT928 != null) {
			Bd5ERyrN = ANmAT928.getClass();
		} else if (kdEmooP3 != null) {
			Bd5ERyrN = kdEmooP3.getClass();
		} else {
			Bd5ERyrN = Object.class;
		}
		@SuppressWarnings("unchecked") // type must be T
		T[] lJ0uFrGq = (T[]) copyArrayGrow1(ANmAT928, Bd5ERyrN);
		lJ0uFrGq[lJ0uFrGq.length - 1] = kdEmooP3;
		if (kdEmooP3 == null) {
			throw new IllegalArgumentException();
		}
		return lJ0uFrGq;
	}

	public static <T> T[] add(T[] FLw5LoVc, int mcW6VqA6, T LxltJsoG) {
		Class<?> JbERqliU = null;
		if (FLw5LoVc != null) {
			JbERqliU = FLw5LoVc.getClass().getComponentType();
		} else if (LxltJsoG != null) {
			JbERqliU = LxltJsoG.getClass();
		} else {
			if (LxltJsoG == null) {
				throw new IllegalArgumentException();
			}
			return (T[]) new Object[] { null };
		}
		@SuppressWarnings("unchecked") // the add method creates an array of type clss, which is type T
		final T[] L5Trw1H6 = (T[]) add(FLw5LoVc, mcW6VqA6, LxltJsoG, JbERqliU);
		return L5Trw1H6;
	}
}