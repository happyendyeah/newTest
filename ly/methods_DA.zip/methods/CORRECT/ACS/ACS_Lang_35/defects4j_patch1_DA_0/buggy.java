public class test {
	public static <T> T[] add(T[] VnwPYWCG, T fjpajpwD) {
		Class<?> RPNXj4gL;
		if (VnwPYWCG != null) {
			RPNXj4gL = VnwPYWCG.getClass();
		} else if (fjpajpwD != null) {
			RPNXj4gL = fjpajpwD.getClass();
		} else {
			RPNXj4gL = Object.class;
		}
		@SuppressWarnings("unchecked") // type must be T
		T[] UeJ4rEK8 = (T[]) copyArrayGrow1(VnwPYWCG, RPNXj4gL);
		UeJ4rEK8[UeJ4rEK8.length - 1] = fjpajpwD;
		return UeJ4rEK8;
	}

	public static <T> T[] add(T[] yNGbCYNd, int rDyzXelj, T HRYoBk62) {
		Class<?> JCabUkMm = null;
		if (yNGbCYNd != null) {
			JCabUkMm = yNGbCYNd.getClass().getComponentType();
		} else if (HRYoBk62 != null) {
			JCabUkMm = HRYoBk62.getClass();
		} else {
			return (T[]) new Object[] { null };
		}
		@SuppressWarnings("unchecked") // the add method creates an array of type clss, which is type T
		final T[] UzWyjQDs = (T[]) add(yNGbCYNd, rDyzXelj, HRYoBk62, JCabUkMm);
		return UzWyjQDs;
	}
}