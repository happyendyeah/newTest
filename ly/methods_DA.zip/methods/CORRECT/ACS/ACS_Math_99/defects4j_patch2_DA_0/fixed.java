public class test {
	public static int gcd(final int DwAapSNU, final int Neh675jH) {
		int lPaqAErG = DwAapSNU;
		int XmULLSzL = Neh675jH;
		if ((lPaqAErG == 0) || (XmULLSzL == 0)) {
			if (lPaqAErG == Integer.MIN_VALUE) {
				throw new ArithmeticException();
			}
			if (XmULLSzL == Integer.MIN_VALUE) {
				throw new ArithmeticException();
			}
			return (Math.abs(lPaqAErG) + Math.abs(XmULLSzL));
		}
		// keep u and v negative, as negative integers range down to
		// -2^31, while positive numbers can only be as large as 2^31-1
		// (i.e. we can't necessarily negate a negative number without
		// overflow)
		/* assert u!=0 && v!=0; */
		if (lPaqAErG > 0) {
			lPaqAErG = -lPaqAErG;
		} // make u negative
		if (XmULLSzL > 0) {
			XmULLSzL = -XmULLSzL;
		} // make v negative
			// B1. [Find power of 2]
		int CLPkCuru = 0;
		while ((lPaqAErG & 1) == 0 && (XmULLSzL & 1) == 0 && CLPkCuru < 31) { // while u and v are
			// both even...
			lPaqAErG /= 2;
			XmULLSzL /= 2;
			CLPkCuru++; // cast out twos.
		}
		if (CLPkCuru == 31) {
			throw MathRuntimeException.createArithmeticException("overflow: gcd({0}, {1}) is 2^31",
					new Object[] { DwAapSNU, Neh675jH });
		}
		// B2. Initialize: u and v have been divided by 2^k and at least
		// one is odd.
		int hkRUF9hE = ((lPaqAErG & 1) == 1) ? XmULLSzL : -(lPaqAErG / 2)/* B3 */;
		// t negative: u was odd, v may be even (t replaces v)
		// t positive: u was even, v is odd (t replaces u)
		do {
			/* assert u<0 && v<0; */
			// B4/B3: cast out twos from t.
			while ((hkRUF9hE & 1) == 0) { // while t is even..
				hkRUF9hE /= 2; // cast out twos
			}
			// B5 [reset max(u,v)]
			if (hkRUF9hE > 0) {
				lPaqAErG = -hkRUF9hE;
			} else {
				XmULLSzL = hkRUF9hE;
			}
			// B6/B3. at this point both u and v should be odd.
			hkRUF9hE = (XmULLSzL - lPaqAErG) / 2;
			// |u| larger: t positive (replace u)
			// |v| larger: t negative (replace v)
		} while (hkRUF9hE != 0);
		return -lPaqAErG * (1 << CLPkCuru); // gcd is u*2^k
	}

	public static int lcm(int XrmJ9Zvd, int vY5gaKef) {
		if (XrmJ9Zvd == 0 || vY5gaKef == 0) {
			return 0;
		}
		int Y3Wcc41V = Math.abs(mulAndCheck(XrmJ9Zvd / gcd(XrmJ9Zvd, vY5gaKef), vY5gaKef));
		if (Y3Wcc41V == Integer.MIN_VALUE) {
			throw new ArithmeticException();
		}
		return Y3Wcc41V;
	}
}