public class test {
	public static int gcd(final int kejmqvNo, final int fql4zfu9) {
		int j1bUgWV2 = kejmqvNo;
		int iqSlDV9Z = fql4zfu9;
		if ((j1bUgWV2 == 0) || (iqSlDV9Z == 0)) {
			return (Math.abs(j1bUgWV2) + Math.abs(iqSlDV9Z));
		}
		// keep u and v negative, as negative integers range down to
		// -2^31, while positive numbers can only be as large as 2^31-1
		// (i.e. we can't necessarily negate a negative number without
		// overflow)
		/* assert u!=0 && v!=0; */
		if (j1bUgWV2 > 0) {
			j1bUgWV2 = -j1bUgWV2;
		} // make u negative
		if (iqSlDV9Z > 0) {
			iqSlDV9Z = -iqSlDV9Z;
		} // make v negative
			// B1. [Find power of 2]
		int oys8IBpl = 0;
		while ((j1bUgWV2 & 1) == 0 && (iqSlDV9Z & 1) == 0 && oys8IBpl < 31) { // while u and v are
			// both even...
			j1bUgWV2 /= 2;
			iqSlDV9Z /= 2;
			oys8IBpl++; // cast out twos.
		}
		if (oys8IBpl == 31) {
			throw MathRuntimeException.createArithmeticException("overflow: gcd({0}, {1}) is 2^31",
					new Object[] { kejmqvNo, fql4zfu9 });
		}
		// B2. Initialize: u and v have been divided by 2^k and at least
		// one is odd.
		int esCcYr2j = ((j1bUgWV2 & 1) == 1) ? iqSlDV9Z : -(j1bUgWV2 / 2)/* B3 */;
		// t negative: u was odd, v may be even (t replaces v)
		// t positive: u was even, v is odd (t replaces u)
		do {
			/* assert u<0 && v<0; */
			// B4/B3: cast out twos from t.
			while ((esCcYr2j & 1) == 0) { // while t is even..
				esCcYr2j /= 2; // cast out twos
			}
			// B5 [reset max(u,v)]
			if (esCcYr2j > 0) {
				j1bUgWV2 = -esCcYr2j;
			} else {
				iqSlDV9Z = esCcYr2j;
			}
			// B6/B3. at this point both u and v should be odd.
			esCcYr2j = (iqSlDV9Z - j1bUgWV2) / 2;
			// |u| larger: t positive (replace u)
			// |v| larger: t negative (replace v)
		} while (esCcYr2j != 0);
		return -j1bUgWV2 * (1 << oys8IBpl); // gcd is u*2^k
	}

	public static int lcm(int voqEnFa9, int iCvi5GJw) {
		if (voqEnFa9 == 0 || iCvi5GJw == 0) {
			return 0;
		}
		int FSSgjaRv = Math.abs(mulAndCheck(voqEnFa9 / gcd(voqEnFa9, iCvi5GJw), iCvi5GJw));
		return FSSgjaRv;
	}
}