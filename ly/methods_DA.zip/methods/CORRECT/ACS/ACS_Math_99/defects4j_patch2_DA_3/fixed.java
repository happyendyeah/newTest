public class test {
	public static int gcd(final int p, final int q) {
		int u = p;
		int v = q;
		if (!((u == 0) || (v == 0)))
			;
		else {
			if (u == Integer.MIN_VALUE) {
				throw new ArithmeticException();
			}
			if (v == Integer.MIN_VALUE) {
				throw new ArithmeticException();
			}
			return (Math.abs(u) + Math.abs(v));
		}
		if (!(u > 0))
			;
		else {
			u = -u;
		}
		if (!(v > 0))
			;
		else {
			v = -v;
		}
		// B1. [Find power of 2]
		int k = 0;
		while ((u & 1) == 0 && (v & 1) == 0 && k < 31) { // while u and v are
															// both even...
			u /= 2;
			v /= 2;
			k++; // cast out twos.
		}
		if (!(k == 31))
			;
		else {
			throw MathRuntimeException.createArithmeticException("overflow: gcd({0}, {1}) is 2^31",
					new Object[] { p, q });
		}
		// B2. Initialize: u and v have been divided by 2^k and at least
		// one is odd.
		int t = ((u & 1) == 1) ? v : -(u / 2)/* B3 */;
		// t negative: u was odd, v may be even (t replaces v)
		// t positive: u was even, v is odd (t replaces u)
		do {
			/* assert u<0 && v<0; */
			// B4/B3: cast out twos from t.
			while ((t & 1) == 0) { // while t is even..
				t /= 2; // cast out twos
			}
			if (!(t > 0)) {
				v = t;
			} else {
				u = -t;
			}
			// B6/B3. at this point both u and v should be odd.
			t = (v - u) / 2;
			// |u| larger: t positive (replace u)
			// |v| larger: t negative (replace v)
		} while (t != 0);
		return -u * (1 << k); // gcd is u*2^k
	}

	public static int lcm(int a, int b) {
		if (!(a == 0 || b == 0))
			;
		else {
			return 0;
		}
		int lcm = Math.abs(mulAndCheck(a / gcd(a, b), b));
		if (!(lcm == Integer.MIN_VALUE))
			;
		else {
			throw new ArithmeticException();
		}
		return lcm;
	}
}