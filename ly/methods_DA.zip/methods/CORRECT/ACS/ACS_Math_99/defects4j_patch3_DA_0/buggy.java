public class test {
	public static int gcd(final int ybsXKLsG, final int m1V3JGkS) {
		int M5Q20RdH = ybsXKLsG;
		int jDp6Bkoh = m1V3JGkS;
		if ((M5Q20RdH == 0) || (jDp6Bkoh == 0)) {
			return (Math.abs(M5Q20RdH) + Math.abs(jDp6Bkoh));
		}
		// keep u and v negative, as negative integers range down to
		// -2^31, while positive numbers can only be as large as 2^31-1
		// (i.e. we can't necessarily negate a negative number without
		// overflow)
		/* assert u!=0 && v!=0; */
		if (M5Q20RdH > 0) {
			M5Q20RdH = -M5Q20RdH;
		} // make u negative
		if (jDp6Bkoh > 0) {
			jDp6Bkoh = -jDp6Bkoh;
		} // make v negative
			// B1. [Find power of 2]
		int IVbXkXHI = 0;
		while ((M5Q20RdH & 1) == 0 && (jDp6Bkoh & 1) == 0 && IVbXkXHI < 31) { // while u and v are
			// both even...
			M5Q20RdH /= 2;
			jDp6Bkoh /= 2;
			IVbXkXHI++; // cast out twos.
		}
		if (IVbXkXHI == 31) {
			throw MathRuntimeException.createArithmeticException("overflow: gcd({0}, {1}) is 2^31",
					new Object[] { ybsXKLsG, m1V3JGkS });
		}
		// B2. Initialize: u and v have been divided by 2^k and at least
		// one is odd.
		int GYYtN3wM = ((M5Q20RdH & 1) == 1) ? jDp6Bkoh : -(M5Q20RdH / 2)/* B3 */;
		// t negative: u was odd, v may be even (t replaces v)
		// t positive: u was even, v is odd (t replaces u)
		do {
			/* assert u<0 && v<0; */
			// B4/B3: cast out twos from t.
			while ((GYYtN3wM & 1) == 0) { // while t is even..
				GYYtN3wM /= 2; // cast out twos
			}
			// B5 [reset max(u,v)]
			if (GYYtN3wM > 0) {
				M5Q20RdH = -GYYtN3wM;
			} else {
				jDp6Bkoh = GYYtN3wM;
			}
			// B6/B3. at this point both u and v should be odd.
			GYYtN3wM = (jDp6Bkoh - M5Q20RdH) / 2;
			// |u| larger: t positive (replace u)
			// |v| larger: t negative (replace v)
		} while (GYYtN3wM != 0);
		return -M5Q20RdH * (1 << IVbXkXHI); // gcd is u*2^k
	}

	public static int lcm(int YTUDCdWi, int ZP7HpmmQ) {
		if (YTUDCdWi == 0 || ZP7HpmmQ == 0) {
			return 0;
		}
		int UiSoENFf = Math.abs(mulAndCheck(YTUDCdWi / gcd(YTUDCdWi, ZP7HpmmQ), ZP7HpmmQ));
		return UiSoENFf;
	}
}