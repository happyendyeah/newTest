public class test {
	public static int gcd(final int rgXJglga, final int L40MnA87) {
		int gb2gMaGd = rgXJglga;
		int cASuHZSs = L40MnA87;
		if ((gb2gMaGd == 0) || (cASuHZSs == 0)) {
			if (gb2gMaGd == Integer.MIN_VALUE) {
				throw new ArithmeticException();
			}
			if (cASuHZSs == Integer.MIN_VALUE) {
				throw new ArithmeticException();
			}
			return (Math.abs(gb2gMaGd) + Math.abs(cASuHZSs));
		}
		// keep u and v negative, as negative integers range down to
		// -2^31, while positive numbers can only be as large as 2^31-1
		// (i.e. we can't necessarily negate a negative number without
		// overflow)
		/* assert u!=0 && v!=0; */
		if (gb2gMaGd > 0) {
			gb2gMaGd = -gb2gMaGd;
		} // make u negative
		if (cASuHZSs > 0) {
			cASuHZSs = -cASuHZSs;
		} // make v negative
			// B1. [Find power of 2]
		int CxaNAIvW = 0;
		while ((gb2gMaGd & 1) == 0 && (cASuHZSs & 1) == 0 && CxaNAIvW < 31) { // while u and v are
			// both even...
			gb2gMaGd /= 2;
			cASuHZSs /= 2;
			CxaNAIvW++; // cast out twos.
		}
		if (CxaNAIvW == 31) {
			throw MathRuntimeException.createArithmeticException("overflow: gcd({0}, {1}) is 2^31",
					new Object[] { rgXJglga, L40MnA87 });
		}
		// B2. Initialize: u and v have been divided by 2^k and at least
		// one is odd.
		int qtfER7V2 = ((gb2gMaGd & 1) == 1) ? cASuHZSs : -(gb2gMaGd / 2)/* B3 */;
		// t negative: u was odd, v may be even (t replaces v)
		// t positive: u was even, v is odd (t replaces u)
		do {
			/* assert u<0 && v<0; */
			// B4/B3: cast out twos from t.
			while ((qtfER7V2 & 1) == 0) { // while t is even..
				qtfER7V2 /= 2; // cast out twos
			}
			// B5 [reset max(u,v)]
			if (qtfER7V2 > 0) {
				gb2gMaGd = -qtfER7V2;
			} else {
				cASuHZSs = qtfER7V2;
			}
			// B6/B3. at this point both u and v should be odd.
			qtfER7V2 = (cASuHZSs - gb2gMaGd) / 2;
			// |u| larger: t positive (replace u)
			// |v| larger: t negative (replace v)
		} while (qtfER7V2 != 0);
		return -gb2gMaGd * (1 << CxaNAIvW); // gcd is u*2^k
	}

	public static int lcm(int W0o7U9uv, int sYpA8OOl) {
		if (W0o7U9uv == 0 || sYpA8OOl == 0) {
			return 0;
		}
		int ASaDmSPC = Math.abs(mulAndCheck(W0o7U9uv / gcd(W0o7U9uv, sYpA8OOl), sYpA8OOl));
		if (ASaDmSPC == Integer.MIN_VALUE) {
			throw new ArithmeticException();
		}
		return ASaDmSPC;
	}
}