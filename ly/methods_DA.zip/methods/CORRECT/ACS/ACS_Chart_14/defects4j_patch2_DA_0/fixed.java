public class test {
	public boolean removeDomainMarker(int hyByYnPA, Marker Gw9FT7sB, Layer TRVY1WXa, boolean oREhuclf) {
		ArrayList QW0gOh1c;
		if (TRVY1WXa == Layer.FOREGROUND) {
			QW0gOh1c = (ArrayList) this.foregroundDomainMarkers.get(new Integer(hyByYnPA));
		} else {
			QW0gOh1c = (ArrayList) this.backgroundDomainMarkers.get(new Integer(hyByYnPA));
		}
		if (QW0gOh1c == null) {
			return false;
		}
		boolean ClsDtD5M = QW0gOh1c.remove(Gw9FT7sB);
		if (ClsDtD5M && oREhuclf) {
			fireChangeEvent();
		}
		return ClsDtD5M;
	}

	public boolean removeRangeMarker(int BIdrGewU, Marker yRozZ7bb, Layer bRELgH4I, boolean LotP64fc) {
		if (yRozZ7bb == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList HcYKqCfU;
		if (bRELgH4I == Layer.FOREGROUND) {
			HcYKqCfU = (ArrayList) this.foregroundRangeMarkers.get(new Integer(BIdrGewU));
		} else {
			HcYKqCfU = (ArrayList) this.backgroundRangeMarkers.get(new Integer(BIdrGewU));
		}
		if (HcYKqCfU == null) {
			return false;
		}
		boolean zP9EcYwx = HcYKqCfU.remove(yRozZ7bb);
		if (zP9EcYwx && LotP64fc) {
			fireChangeEvent();
		}
		return zP9EcYwx;
	}

	public boolean removeRangeMarker(int LLhd5vED, Marker I8chDrar, Layer pKAXERX6, boolean eqmKp4NU) {
		if (I8chDrar == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList gjFikNUj;
		if (pKAXERX6 == Layer.FOREGROUND) {
			gjFikNUj = (ArrayList) this.foregroundRangeMarkers.get(new Integer(LLhd5vED));
		} else {
			gjFikNUj = (ArrayList) this.backgroundRangeMarkers.get(new Integer(LLhd5vED));
		}
		if (gjFikNUj == null) {
			return false;
		}
		boolean EUpMFGtf = gjFikNUj.remove(I8chDrar);
		if (EUpMFGtf && eqmKp4NU) {
			fireChangeEvent();
		}
		return EUpMFGtf;
	}

	public boolean removeDomainMarker(int oaIJgg9f, Marker MbnRd0bo, Layer omJiNqmJ, boolean lojfWGAO) {
		ArrayList S1yCIdl9;
		if (omJiNqmJ == Layer.FOREGROUND) {
			S1yCIdl9 = (ArrayList) this.foregroundDomainMarkers.get(new Integer(oaIJgg9f));
		} else {
			S1yCIdl9 = (ArrayList) this.backgroundDomainMarkers.get(new Integer(oaIJgg9f));
		}
		if (S1yCIdl9 == null) {
			return false;
		}
		boolean BLNWNba8 = S1yCIdl9.remove(MbnRd0bo);
		if (BLNWNba8 && lojfWGAO) {
			fireChangeEvent();
		}
		return BLNWNba8;
	}
}