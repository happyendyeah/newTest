public class test {
	public boolean removeDomainMarker(int adRF4orF, Marker itAyRQXe, Layer KNvNe2wq, boolean LFdWiE1q) {
		ArrayList tQWjD7gM;
		if (KNvNe2wq == Layer.FOREGROUND) {
			tQWjD7gM = (ArrayList) this.foregroundDomainMarkers.get(new Integer(adRF4orF));
		} else {
			tQWjD7gM = (ArrayList) this.backgroundDomainMarkers.get(new Integer(adRF4orF));
		}
		boolean fCXGQdbk = tQWjD7gM.remove(itAyRQXe);
		if (fCXGQdbk && LFdWiE1q) {
			fireChangeEvent();
		}
		return fCXGQdbk;
	}

	public boolean removeRangeMarker(int vHIjMzkx, Marker RhHxl6zy, Layer LIyCgwdB, boolean HrHCGNNh) {
		if (RhHxl6zy == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList WFzTHt3H;
		if (LIyCgwdB == Layer.FOREGROUND) {
			WFzTHt3H = (ArrayList) this.foregroundRangeMarkers.get(new Integer(vHIjMzkx));
		} else {
			WFzTHt3H = (ArrayList) this.backgroundRangeMarkers.get(new Integer(vHIjMzkx));
		}
		boolean F52fMjYc = WFzTHt3H.remove(RhHxl6zy);
		if (F52fMjYc && HrHCGNNh) {
			fireChangeEvent();
		}
		return F52fMjYc;
	}

	public boolean removeRangeMarker(int xpjOMPlG, Marker wq2QYY0B, Layer HAh4czwV, boolean XK4mgX8b) {
		if (wq2QYY0B == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList onY13X0q;
		if (HAh4czwV == Layer.FOREGROUND) {
			onY13X0q = (ArrayList) this.foregroundRangeMarkers.get(new Integer(xpjOMPlG));
		} else {
			onY13X0q = (ArrayList) this.backgroundRangeMarkers.get(new Integer(xpjOMPlG));
		}
		boolean Z3qYUTyf = onY13X0q.remove(wq2QYY0B);
		if (Z3qYUTyf && XK4mgX8b) {
			fireChangeEvent();
		}
		return Z3qYUTyf;
	}

	public boolean removeDomainMarker(int zQhUKZot, Marker yfac9gBv, Layer dCaqryUC, boolean pGl8hYC6) {
		ArrayList badDgj5g;
		if (dCaqryUC == Layer.FOREGROUND) {
			badDgj5g = (ArrayList) this.foregroundDomainMarkers.get(new Integer(zQhUKZot));
		} else {
			badDgj5g = (ArrayList) this.backgroundDomainMarkers.get(new Integer(zQhUKZot));
		}
		boolean EwOqpk4K = badDgj5g.remove(yfac9gBv);
		if (EwOqpk4K && pGl8hYC6) {
			fireChangeEvent();
		}
		return EwOqpk4K;
	}
}