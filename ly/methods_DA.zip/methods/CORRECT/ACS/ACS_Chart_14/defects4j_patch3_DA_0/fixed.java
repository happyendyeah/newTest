public class test {
	public boolean removeDomainMarker(int vDuIBoNb, Marker cWWsHbLE, Layer mbuA4pVM, boolean ZYyFRmEC) {
		ArrayList wIwHE7rU;
		if (mbuA4pVM == Layer.FOREGROUND) {
			wIwHE7rU = (ArrayList) this.foregroundDomainMarkers.get(new Integer(vDuIBoNb));
		} else {
			wIwHE7rU = (ArrayList) this.backgroundDomainMarkers.get(new Integer(vDuIBoNb));
		}
		if (wIwHE7rU == null) {
			return false;
		}
		boolean Owktz4aT = wIwHE7rU.remove(cWWsHbLE);
		if (Owktz4aT && ZYyFRmEC) {
			fireChangeEvent();
		}
		return Owktz4aT;
	}

	public boolean removeRangeMarker(int qWAe1CNU, Marker nho8jq27, Layer hXvyzk5i, boolean UKrAsfss) {
		if (nho8jq27 == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList BrtygTMw;
		if (hXvyzk5i == Layer.FOREGROUND) {
			BrtygTMw = (ArrayList) this.foregroundRangeMarkers.get(new Integer(qWAe1CNU));
		} else {
			BrtygTMw = (ArrayList) this.backgroundRangeMarkers.get(new Integer(qWAe1CNU));
		}
		if (BrtygTMw == null) {
			return false;
		}
		boolean TatZzhAE = BrtygTMw.remove(nho8jq27);
		if (TatZzhAE && UKrAsfss) {
			fireChangeEvent();
		}
		return TatZzhAE;
	}

	public boolean removeDomainMarker(int t8QKOgP7, Marker lvZtQCWn, Layer hsVdPDqp, boolean mxb8WVe5) {
		ArrayList h1d8VFtj;
		if (hsVdPDqp == Layer.FOREGROUND) {
			h1d8VFtj = (ArrayList) this.foregroundDomainMarkers.get(new Integer(t8QKOgP7));
		} else {
			h1d8VFtj = (ArrayList) this.backgroundDomainMarkers.get(new Integer(t8QKOgP7));
		}
		if (h1d8VFtj == null) {
			return false;
		}
		boolean W2a68exI = h1d8VFtj.remove(lvZtQCWn);
		if (W2a68exI && mxb8WVe5) {
			fireChangeEvent();
		}
		return W2a68exI;
	}

	public boolean removeRangeMarker(int SIHywauU, Marker TxmDOH7r, Layer aYNnbtj2, boolean mobmSW2X) {
		if (TxmDOH7r == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList LBm3VYCN;
		if (aYNnbtj2 == Layer.FOREGROUND) {
			LBm3VYCN = (ArrayList) this.foregroundRangeMarkers.get(new Integer(SIHywauU));
		} else {
			LBm3VYCN = (ArrayList) this.backgroundRangeMarkers.get(new Integer(SIHywauU));
		}
		if (LBm3VYCN == null) {
			return false;
		}
		boolean yTZQbNWT = LBm3VYCN.remove(TxmDOH7r);
		if (yTZQbNWT && mobmSW2X) {
			fireChangeEvent();
		}
		return yTZQbNWT;
	}
}