public class test {
	public boolean removeDomainMarker(int efFpkWcB, Marker tN90A9SF, Layer vyJssFXR, boolean VkskH35O) {
		ArrayList lboOT9IU;
		if (vyJssFXR == Layer.FOREGROUND) {
			lboOT9IU = (ArrayList) this.foregroundDomainMarkers.get(new Integer(efFpkWcB));
		} else {
			lboOT9IU = (ArrayList) this.backgroundDomainMarkers.get(new Integer(efFpkWcB));
		}
		boolean SxIfmeEj = lboOT9IU.remove(tN90A9SF);
		if (SxIfmeEj && VkskH35O) {
			fireChangeEvent();
		}
		return SxIfmeEj;
	}

	public boolean removeRangeMarker(int y83dLJ5N, Marker m2UMhu0e, Layer uxuxSACv, boolean pRgDAuUH) {
		if (m2UMhu0e == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList Wc1V8x99;
		if (uxuxSACv == Layer.FOREGROUND) {
			Wc1V8x99 = (ArrayList) this.foregroundRangeMarkers.get(new Integer(y83dLJ5N));
		} else {
			Wc1V8x99 = (ArrayList) this.backgroundRangeMarkers.get(new Integer(y83dLJ5N));
		}
		boolean Tp7QDQQc = Wc1V8x99.remove(m2UMhu0e);
		if (Tp7QDQQc && pRgDAuUH) {
			fireChangeEvent();
		}
		return Tp7QDQQc;
	}

	public boolean removeRangeMarker(int OqGBi8rd, Marker uvjiJoEN, Layer CBZ01kHi, boolean GwCzOAYu) {
		if (uvjiJoEN == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList ANezZUgH;
		if (CBZ01kHi == Layer.FOREGROUND) {
			ANezZUgH = (ArrayList) this.foregroundRangeMarkers.get(new Integer(OqGBi8rd));
		} else {
			ANezZUgH = (ArrayList) this.backgroundRangeMarkers.get(new Integer(OqGBi8rd));
		}
		boolean kSv7RiQU = ANezZUgH.remove(uvjiJoEN);
		if (kSv7RiQU && GwCzOAYu) {
			fireChangeEvent();
		}
		return kSv7RiQU;
	}

	public boolean removeDomainMarker(int ELes9Elc, Marker b29NUjyr, Layer hVugvZ42, boolean hbJBuWjC) {
		ArrayList SAUlMgRu;
		if (hVugvZ42 == Layer.FOREGROUND) {
			SAUlMgRu = (ArrayList) this.foregroundDomainMarkers.get(new Integer(ELes9Elc));
		} else {
			SAUlMgRu = (ArrayList) this.backgroundDomainMarkers.get(new Integer(ELes9Elc));
		}
		boolean tYQBrOTT = SAUlMgRu.remove(b29NUjyr);
		if (tYQBrOTT && hbJBuWjC) {
			fireChangeEvent();
		}
		return tYQBrOTT;
	}
}