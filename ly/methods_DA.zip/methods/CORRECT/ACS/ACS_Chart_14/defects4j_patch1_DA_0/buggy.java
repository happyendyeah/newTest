public class test {
	public boolean removeDomainMarker(int pFJpHKiD, Marker FY3hHLuG, Layer lOEZw8Jc, boolean UDbwC3KC) {
		ArrayList xxM7cdNa;
		if (lOEZw8Jc == Layer.FOREGROUND) {
			xxM7cdNa = (ArrayList) this.foregroundDomainMarkers.get(new Integer(pFJpHKiD));
		} else {
			xxM7cdNa = (ArrayList) this.backgroundDomainMarkers.get(new Integer(pFJpHKiD));
		}
		boolean FsMDXiP1 = xxM7cdNa.remove(FY3hHLuG);
		if (FsMDXiP1 && UDbwC3KC) {
			fireChangeEvent();
		}
		return FsMDXiP1;
	}

	public boolean removeRangeMarker(int Ijf17SGn, Marker cWhUG1lV, Layer Ad5sFBwK, boolean cLcVLvxc) {
		if (cWhUG1lV == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList xvs3qX6n;
		if (Ad5sFBwK == Layer.FOREGROUND) {
			xvs3qX6n = (ArrayList) this.foregroundRangeMarkers.get(new Integer(Ijf17SGn));
		} else {
			xvs3qX6n = (ArrayList) this.backgroundRangeMarkers.get(new Integer(Ijf17SGn));
		}
		boolean L5CC5D69 = xvs3qX6n.remove(cWhUG1lV);
		if (L5CC5D69 && cLcVLvxc) {
			fireChangeEvent();
		}
		return L5CC5D69;
	}

	public boolean removeRangeMarker(int EETBPGjK, Marker QHuQevWX, Layer t9ohC2X6, boolean WfR5Oly3) {
		if (QHuQevWX == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList Rw01paMQ;
		if (t9ohC2X6 == Layer.FOREGROUND) {
			Rw01paMQ = (ArrayList) this.foregroundRangeMarkers.get(new Integer(EETBPGjK));
		} else {
			Rw01paMQ = (ArrayList) this.backgroundRangeMarkers.get(new Integer(EETBPGjK));
		}
		boolean c1x49Ei8 = Rw01paMQ.remove(QHuQevWX);
		if (c1x49Ei8 && WfR5Oly3) {
			fireChangeEvent();
		}
		return c1x49Ei8;
	}

	public boolean removeDomainMarker(int oX6bzcUb, Marker s5ZhSQJe, Layer rnXLmJUB, boolean dw9nMEgo) {
		ArrayList ziAN4ryu;
		if (rnXLmJUB == Layer.FOREGROUND) {
			ziAN4ryu = (ArrayList) this.foregroundDomainMarkers.get(new Integer(oX6bzcUb));
		} else {
			ziAN4ryu = (ArrayList) this.backgroundDomainMarkers.get(new Integer(oX6bzcUb));
		}
		boolean ZJJrVUSO = ziAN4ryu.remove(s5ZhSQJe);
		if (ZJJrVUSO && dw9nMEgo) {
			fireChangeEvent();
		}
		return ZJJrVUSO;
	}
}