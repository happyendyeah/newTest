public class test {
	public boolean removeDomainMarker(int nyWOyatj, Marker voqpI4Wd, Layer f55uLy9W, boolean e3Ucma7n) {
		ArrayList oiHez1FE;
		if (f55uLy9W == Layer.FOREGROUND) {
			oiHez1FE = (ArrayList) this.foregroundDomainMarkers.get(new Integer(nyWOyatj));
		} else {
			oiHez1FE = (ArrayList) this.backgroundDomainMarkers.get(new Integer(nyWOyatj));
		}
		if (oiHez1FE == null) {
			return false;
		}
		boolean koT4zGIH = oiHez1FE.remove(voqpI4Wd);
		if (koT4zGIH && e3Ucma7n) {
			fireChangeEvent();
		}
		return koT4zGIH;
	}

	public boolean removeRangeMarker(int GkSYGTM1, Marker uhFsIqrl, Layer cEtUWNR4, boolean VKoYatG7) {
		if (uhFsIqrl == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList thuO4dBm;
		if (cEtUWNR4 == Layer.FOREGROUND) {
			thuO4dBm = (ArrayList) this.foregroundRangeMarkers.get(new Integer(GkSYGTM1));
		} else {
			thuO4dBm = (ArrayList) this.backgroundRangeMarkers.get(new Integer(GkSYGTM1));
		}
		if (thuO4dBm == null) {
			return false;
		}
		boolean M9MRs1o5 = thuO4dBm.remove(uhFsIqrl);
		if (M9MRs1o5 && VKoYatG7) {
			fireChangeEvent();
		}
		return M9MRs1o5;
	}

	public boolean removeDomainMarker(int a1POsU1Y, Marker hdBYMHi2, Layer zaEAl41w, boolean hb6SaYxw) {
		ArrayList lOaBDYc8;
		if (zaEAl41w == Layer.FOREGROUND) {
			lOaBDYc8 = (ArrayList) this.foregroundDomainMarkers.get(new Integer(a1POsU1Y));
		} else {
			lOaBDYc8 = (ArrayList) this.backgroundDomainMarkers.get(new Integer(a1POsU1Y));
		}
		if (lOaBDYc8 == null) {
			return false;
		}
		boolean dyFg895E = lOaBDYc8.remove(hdBYMHi2);
		if (dyFg895E && hb6SaYxw) {
			fireChangeEvent();
		}
		return dyFg895E;
	}

	public boolean removeRangeMarker(int J7yVHUBR, Marker UNe5eWnG, Layer yrdMYGZ5, boolean u45pb9tF) {
		if (UNe5eWnG == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList yUt3F3Oj;
		if (yrdMYGZ5 == Layer.FOREGROUND) {
			yUt3F3Oj = (ArrayList) this.foregroundRangeMarkers.get(new Integer(J7yVHUBR));
		} else {
			yUt3F3Oj = (ArrayList) this.backgroundRangeMarkers.get(new Integer(J7yVHUBR));
		}
		if (yUt3F3Oj == null) {
			return false;
		}
		boolean PqwmC1oy = yUt3F3Oj.remove(UNe5eWnG);
		if (PqwmC1oy && u45pb9tF) {
			fireChangeEvent();
		}
		return PqwmC1oy;
	}
}