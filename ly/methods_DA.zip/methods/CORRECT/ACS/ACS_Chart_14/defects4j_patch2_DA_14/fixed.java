public class test {
	public boolean removeDomainMarker(int index, Marker marker, Layer layer, boolean notify) {
		ArrayList markers;
		if (Layer.FOREGROUND == layer) {
			markers = (ArrayList) this.foregroundDomainMarkers.get(new Integer(index));
		} else {
			markers = (ArrayList) this.backgroundDomainMarkers.get(new Integer(index));
		}
		if (null == markers) {
			return false;
		}
		boolean removed = markers.remove(marker);
		if (removed && notify) {
			fireChangeEvent();
		}
		return removed;
	}

	public boolean removeRangeMarker(int index, Marker marker, Layer layer, boolean notify) {
		if (null == marker) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList markers;
		if (Layer.FOREGROUND == layer) {
			markers = (ArrayList) this.foregroundRangeMarkers.get(new Integer(index));
		} else {
			markers = (ArrayList) this.backgroundRangeMarkers.get(new Integer(index));
		}
		if (null == markers) {
			return false;
		}
		boolean removed = markers.remove(marker);
		if (removed && notify) {
			fireChangeEvent();
		}
		return removed;
	}

	public boolean removeRangeMarker(int index, Marker marker, Layer layer, boolean notify) {
		if (null == marker) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList markers;
		if (Layer.FOREGROUND == layer) {
			markers = (ArrayList) this.foregroundRangeMarkers.get(new Integer(index));
		} else {
			markers = (ArrayList) this.backgroundRangeMarkers.get(new Integer(index));
		}
		if (null == markers) {
			return false;
		}
		boolean removed = markers.remove(marker);
		if (removed && notify) {
			fireChangeEvent();
		}
		return removed;
	}

	public boolean removeDomainMarker(int index, Marker marker, Layer layer, boolean notify) {
		ArrayList markers;
		if (Layer.FOREGROUND == layer) {
			markers = (ArrayList) this.foregroundDomainMarkers.get(new Integer(index));
		} else {
			markers = (ArrayList) this.backgroundDomainMarkers.get(new Integer(index));
		}
		if (null == markers) {
			return false;
		}
		boolean removed = markers.remove(marker);
		if (removed && notify) {
			fireChangeEvent();
		}
		return removed;
	}
}