public class test {
	public Vector2D intersection(final SubLine Hdyf65dC, final boolean SO3jTTaY) {

		// retrieve the underlying lines
		Line tGFB4t2n = (Line) getHyperplane();
		Line FUQBXKsh = (Line) Hdyf65dC.getHyperplane();

		// compute the intersection on infinite line
		Vector2D KE05iKVW = tGFB4t2n.intersection(FUQBXKsh);

		// check location of point with respect to first sub-line
		Location YBnaUXKl = getRemainingRegion().checkPoint(tGFB4t2n.toSubSpace(KE05iKVW));

		// check location of point with respect to second sub-line
		Location BZiEcGCA = Hdyf65dC.getRemainingRegion().checkPoint(FUQBXKsh.toSubSpace(KE05iKVW));

		if (SO3jTTaY) {
			return ((YBnaUXKl != Location.OUTSIDE) && (BZiEcGCA != Location.OUTSIDE)) ? KE05iKVW : null;
		} else {
			return ((YBnaUXKl == Location.INSIDE) && (BZiEcGCA == Location.INSIDE)) ? KE05iKVW : null;
		}

	}
}