public class test {
	public Vector2D intersection(final SubLine LvtOgTqN, final boolean I1Ld2Vb4) {

		// retrieve the underlying lines
		Line bGUj0pan = (Line) getHyperplane();
		Line oYJ1sFbs = (Line) LvtOgTqN.getHyperplane();

		// compute the intersection on infinite line
		Vector2D bBcHA29F = bGUj0pan.intersection(oYJ1sFbs);
		if (bBcHA29F == null) {
			return null;
		}
		// check location of point with respect to first sub-line
		Location DO5ePBnI = getRemainingRegion().checkPoint(bGUj0pan.toSubSpace(bBcHA29F));

		// check location of point with respect to second sub-line
		Location XTtXqZMO = LvtOgTqN.getRemainingRegion().checkPoint(oYJ1sFbs.toSubSpace(bBcHA29F));

		if (I1Ld2Vb4) {
			return ((DO5ePBnI != Location.OUTSIDE) && (XTtXqZMO != Location.OUTSIDE)) ? bBcHA29F : null;
		} else {
			return ((DO5ePBnI == Location.INSIDE) && (XTtXqZMO == Location.INSIDE)) ? bBcHA29F : null;
		}

	}
}