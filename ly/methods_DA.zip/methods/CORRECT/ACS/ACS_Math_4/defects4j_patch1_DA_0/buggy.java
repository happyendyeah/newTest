public class test {
	public Vector2D intersection(final SubLine Wwo8yDKZ, final boolean JyBfTZrW) {

		// retrieve the underlying lines
		Line AdePKOE1 = (Line) getHyperplane();
		Line VVKZsEz3 = (Line) Wwo8yDKZ.getHyperplane();

		// compute the intersection on infinite line
		Vector2D KPH8ATfY = AdePKOE1.intersection(VVKZsEz3);

		// check location of point with respect to first sub-line
		Location TMiE2bvw = getRemainingRegion().checkPoint(AdePKOE1.toSubSpace(KPH8ATfY));

		// check location of point with respect to second sub-line
		Location ju1qlCcT = Wwo8yDKZ.getRemainingRegion().checkPoint(VVKZsEz3.toSubSpace(KPH8ATfY));

		if (JyBfTZrW) {
			return ((TMiE2bvw != Location.OUTSIDE) && (ju1qlCcT != Location.OUTSIDE)) ? KPH8ATfY : null;
		} else {
			return ((TMiE2bvw == Location.INSIDE) && (ju1qlCcT == Location.INSIDE)) ? KPH8ATfY : null;
		}

	}

	public Vector3D intersection(final SubLine bxaYuk6e, final boolean twC3JnRM) {

		// compute the intersection on infinite line
		Vector3D skhKdWdz = line.intersection(bxaYuk6e.line);

		// check location of point with respect to first sub-line
		Location bJS6wzkU = remainingRegion.checkPoint(line.toSubSpace(skhKdWdz));

		// check location of point with respect to second sub-line
		Location X1S6iRK3 = bxaYuk6e.remainingRegion.checkPoint(bxaYuk6e.line.toSubSpace(skhKdWdz));

		if (twC3JnRM) {
			return ((bJS6wzkU != Location.OUTSIDE) && (X1S6iRK3 != Location.OUTSIDE)) ? skhKdWdz : null;
		} else {
			return ((bJS6wzkU == Location.INSIDE) && (X1S6iRK3 == Location.INSIDE)) ? skhKdWdz : null;
		}

	}
}