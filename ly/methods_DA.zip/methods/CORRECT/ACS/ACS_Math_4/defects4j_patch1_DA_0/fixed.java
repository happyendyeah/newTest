public class test {
	public Vector2D intersection(final SubLine ucspPh8R, final boolean Zm2vUcFG) {

		// retrieve the underlying lines
		Line jSh1aGTJ = (Line) getHyperplane();
		Line dfnhfbXR = (Line) ucspPh8R.getHyperplane();

		// compute the intersection on infinite line
		Vector2D gHldQhKp = jSh1aGTJ.intersection(dfnhfbXR);
		if (gHldQhKp == null) {
			return null;
		}
		// check location of point with respect to first sub-line
		Location AkcypGzZ = getRemainingRegion().checkPoint(jSh1aGTJ.toSubSpace(gHldQhKp));

		// check location of point with respect to second sub-line
		Location vemrmpme = ucspPh8R.getRemainingRegion().checkPoint(dfnhfbXR.toSubSpace(gHldQhKp));

		if (Zm2vUcFG) {
			return ((AkcypGzZ != Location.OUTSIDE) && (vemrmpme != Location.OUTSIDE)) ? gHldQhKp : null;
		} else {
			return ((AkcypGzZ == Location.INSIDE) && (vemrmpme == Location.INSIDE)) ? gHldQhKp : null;
		}

	}

	public Vector3D intersection(final SubLine aujpf2gN, final boolean F0furYTk) {

		// compute the intersection on infinite line
		Vector3D dBLnTPvl = line.intersection(aujpf2gN.line);

		if (dBLnTPvl == null) {
			return null;
		}
		// check location of point with respect to first sub-line
		Location mxxUVcBw = remainingRegion.checkPoint(line.toSubSpace(dBLnTPvl));

		// check location of point with respect to second sub-line
		Location RohwWUtb = aujpf2gN.remainingRegion.checkPoint(aujpf2gN.line.toSubSpace(dBLnTPvl));

		if (F0furYTk) {
			return ((mxxUVcBw != Location.OUTSIDE) && (RohwWUtb != Location.OUTSIDE)) ? dBLnTPvl : null;
		} else {
			return ((mxxUVcBw == Location.INSIDE) && (RohwWUtb == Location.INSIDE)) ? dBLnTPvl : null;
		}

	}
}