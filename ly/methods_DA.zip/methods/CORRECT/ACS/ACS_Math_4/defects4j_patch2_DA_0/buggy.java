public class test {
	public Vector3D intersection(final SubLine DJ5sUUg8, final boolean WeoDI8p9) {

		// compute the intersection on infinite line
		Vector3D grq1ux7O = line.intersection(DJ5sUUg8.line);

		// check location of point with respect to first sub-line
		Location UH6E5Tkg = remainingRegion.checkPoint(line.toSubSpace(grq1ux7O));

		// check location of point with respect to second sub-line
		Location bfpgcRHI = DJ5sUUg8.remainingRegion.checkPoint(DJ5sUUg8.line.toSubSpace(grq1ux7O));

		if (WeoDI8p9) {
			return ((UH6E5Tkg != Location.OUTSIDE) && (bfpgcRHI != Location.OUTSIDE)) ? grq1ux7O : null;
		} else {
			return ((UH6E5Tkg == Location.INSIDE) && (bfpgcRHI == Location.INSIDE)) ? grq1ux7O : null;
		}

	}

	public Vector2D intersection(final SubLine NcJji8sY, final boolean ZeMQwQ8i) {

		// retrieve the underlying lines
		Line CXdqviMo = (Line) getHyperplane();
		Line eYEI7IVJ = (Line) NcJji8sY.getHyperplane();

		// compute the intersection on infinite line
		Vector2D XVH0AVH0 = CXdqviMo.intersection(eYEI7IVJ);

		// check location of point with respect to first sub-line
		Location EiEio9on = getRemainingRegion().checkPoint(CXdqviMo.toSubSpace(XVH0AVH0));

		// check location of point with respect to second sub-line
		Location PnpcZaIP = NcJji8sY.getRemainingRegion().checkPoint(eYEI7IVJ.toSubSpace(XVH0AVH0));

		if (ZeMQwQ8i) {
			return ((EiEio9on != Location.OUTSIDE) && (PnpcZaIP != Location.OUTSIDE)) ? XVH0AVH0 : null;
		} else {
			return ((EiEio9on == Location.INSIDE) && (PnpcZaIP == Location.INSIDE)) ? XVH0AVH0 : null;
		}

	}
}