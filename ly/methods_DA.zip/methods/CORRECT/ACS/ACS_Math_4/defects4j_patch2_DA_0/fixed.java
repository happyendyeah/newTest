public class test {
	public Vector3D intersection(final SubLine bNHtPW8l, final boolean uuy5Q26z) {

		// compute the intersection on infinite line
		Vector3D Qqijqhxq = line.intersection(bNHtPW8l.line);

		if (Qqijqhxq == null) {
			return null;
		}
		// check location of point with respect to first sub-line
		Location ltI3Do5D = remainingRegion.checkPoint(line.toSubSpace(Qqijqhxq));

		// check location of point with respect to second sub-line
		Location SQ0MzWzr = bNHtPW8l.remainingRegion.checkPoint(bNHtPW8l.line.toSubSpace(Qqijqhxq));

		if (uuy5Q26z) {
			return ((ltI3Do5D != Location.OUTSIDE) && (SQ0MzWzr != Location.OUTSIDE)) ? Qqijqhxq : null;
		} else {
			return ((ltI3Do5D == Location.INSIDE) && (SQ0MzWzr == Location.INSIDE)) ? Qqijqhxq : null;
		}

	}

	public Vector2D intersection(final SubLine OwGZ7piO, final boolean Wn9ZoqPQ) {

		// retrieve the underlying lines
		Line axotH7Uk = (Line) getHyperplane();
		Line N7sDBuoE = (Line) OwGZ7piO.getHyperplane();

		// compute the intersection on infinite line
		Vector2D Eql2FdbP = axotH7Uk.intersection(N7sDBuoE);
		if (Eql2FdbP == null) {
			return null;
		}
		// check location of point with respect to first sub-line
		Location tFmUyy5X = getRemainingRegion().checkPoint(axotH7Uk.toSubSpace(Eql2FdbP));

		// check location of point with respect to second sub-line
		Location zUIGJWSm = OwGZ7piO.getRemainingRegion().checkPoint(N7sDBuoE.toSubSpace(Eql2FdbP));

		if (Wn9ZoqPQ) {
			return ((tFmUyy5X != Location.OUTSIDE) && (zUIGJWSm != Location.OUTSIDE)) ? Eql2FdbP : null;
		} else {
			return ((tFmUyy5X == Location.INSIDE) && (zUIGJWSm == Location.INSIDE)) ? Eql2FdbP : null;
		}

	}
}