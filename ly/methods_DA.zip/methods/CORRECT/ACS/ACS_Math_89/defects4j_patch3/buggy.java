public class test {
    public void addValue(Object v) {
            addValue((Comparable<?>) v);            
    }
}