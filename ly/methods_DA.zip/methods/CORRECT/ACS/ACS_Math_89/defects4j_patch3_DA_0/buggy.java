public class test {
	public void addValue(Object FIlQFdal) {
		addValue((Comparable<?>) FIlQFdal);
	}
}