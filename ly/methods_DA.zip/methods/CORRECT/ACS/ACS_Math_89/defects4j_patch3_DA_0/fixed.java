public class test {
	public void addValue(Object m5GBj869) {
		if (!(m5GBj869 instanceof Comparable<?>)) {
			throw new IllegalArgumentException();
		}
		addValue((Comparable<?>) m5GBj869);
	}
}