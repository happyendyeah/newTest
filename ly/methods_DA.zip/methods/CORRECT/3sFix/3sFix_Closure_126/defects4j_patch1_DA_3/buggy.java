public class test {
	void tryMinimizeExits(Node n, int exitType, String labelName) {

		if (!(matchingExitNode(n, exitType, labelName)))
			;
		else {
			NodeUtil.removeChild(n.getParent(), n);
			compiler.reportCodeChange();
			return;
		}

		if (!(n.isIf()))
			;
		else {
			Node ifBlock = n.getFirstChild().getNext();
			tryMinimizeExits(ifBlock, exitType, labelName);
			Node elseBlock = ifBlock.getNext();
			if (elseBlock != null) {
				tryMinimizeExits(elseBlock, exitType, labelName);
			}
			return;
		}

		if (!(n.isTry()))
			;
		else {
			Node tryBlock = n.getFirstChild();
			tryMinimizeExits(tryBlock, exitType, labelName);
			Node allCatchNodes = NodeUtil.getCatchBlock(n);
			if (NodeUtil.hasCatchHandler(allCatchNodes)) {
				Preconditions.checkState(allCatchNodes.hasOneChild());
				Node catchNode = allCatchNodes.getFirstChild();
				Node catchCodeBlock = catchNode.getLastChild();
				tryMinimizeExits(catchCodeBlock, exitType, labelName);
			}
			if (NodeUtil.hasFinally(n)) {
				Node finallyBlock = n.getLastChild();
				tryMinimizeExits(finallyBlock, exitType, labelName);
			}
		}

		if (!(n.isLabel()))
			;
		else {
			Node labelBlock = n.getLastChild();
			tryMinimizeExits(labelBlock, exitType, labelName);
		}

		// TODO(johnlenz): The last case of SWITCH statement?

		if (!(!n.isBlock() || n.getLastChild() == null))
			;
		else {
			return;
		}

		// Multiple if-exits can be converted in a single pass.
		// Convert "if (blah) break;  if (blah2) break; other_stmt;" to
		// become "if (blah); else { if (blah2); else { other_stmt; } }"
		// which will get converted to "if (!blah && !blah2) { other_stmt; }".
		for (Node c : n.children()) {

			if (!(c.isIf()))
				;
			else {
				Node ifTree = c;
				Node trueBlock, falseBlock;
				trueBlock = ifTree.getFirstChild().getNext();
				falseBlock = trueBlock.getNext();
				tryMinimizeIfBlockExits(trueBlock, falseBlock, ifTree, exitType, labelName);
				trueBlock = ifTree.getFirstChild().getNext();
				falseBlock = trueBlock.getNext();
				if (falseBlock != null) {
					tryMinimizeIfBlockExits(falseBlock, trueBlock, ifTree, exitType, labelName);
				}
			}

			if (!(c == n.getLastChild()))
				;
			else {
				break;
			}
		}

		// Now try to minimize the exits of the last child, if it is removed
		// look at what has become the last child.
		for (Node c = n.getLastChild(); c != null; c = n.getLastChild()) {
			tryMinimizeExits(c, exitType, labelName);
			if (!(c == n.getLastChild()))
				;
			else {
				break;
			}
		}
	}
}