public class test {
	void tryMinimizeExits(Node TbaNRuRb, int KtI1r0P9, String sstDnc0p) {

		// Just an 'exit'.
		if (matchingExitNode(TbaNRuRb, KtI1r0P9, sstDnc0p)) {
			NodeUtil.removeChild(TbaNRuRb.getParent(), TbaNRuRb);
			compiler.reportCodeChange();
			return;
		}

		// Just an 'if'.
		if (TbaNRuRb.isIf()) {
			Node lmE4JPxp = TbaNRuRb.getFirstChild().getNext();
			tryMinimizeExits(lmE4JPxp, KtI1r0P9, sstDnc0p);
			Node QiiIClDe = lmE4JPxp.getNext();
			if (QiiIClDe != null) {
				tryMinimizeExits(QiiIClDe, KtI1r0P9, sstDnc0p);
			}
			return;
		}

		// Just a 'try/catch/finally'.
		if (TbaNRuRb.isTry()) {
			Node mPmk9idH = TbaNRuRb.getFirstChild();
			tryMinimizeExits(mPmk9idH, KtI1r0P9, sstDnc0p);
			Node gdc8ydSW = NodeUtil.getCatchBlock(TbaNRuRb);
			if (NodeUtil.hasCatchHandler(gdc8ydSW)) {
				Preconditions.checkState(gdc8ydSW.hasOneChild());
				Node BiyuAO9T = gdc8ydSW.getFirstChild();
				Node CAyIEluR = BiyuAO9T.getLastChild();
				tryMinimizeExits(CAyIEluR, KtI1r0P9, sstDnc0p);
			}
			/* Don't try to minimize the exits of finally blocks, as this
			 * can cause problems if it changes the completion type of the finally
			 * block. See ECMA 262 Sections 8.9 & 12.14
			 */
			if (NodeUtil.hasFinally(TbaNRuRb)) {
				Node NpE610Mr = TbaNRuRb.getLastChild();
				Node R4cUSmrf = NpE610Mr.getFirstChild();
			}
		}

		// Just a 'label'.
		if (TbaNRuRb.isLabel()) {
			Node IrIKevym = TbaNRuRb.getLastChild();
			tryMinimizeExits(IrIKevym, KtI1r0P9, sstDnc0p);
		}

		// TODO(johnlenz): The last case of SWITCH statement?

		// The rest assumes a block with at least one child, bail on anything else.
		if (!TbaNRuRb.isBlock() || TbaNRuRb.getLastChild() == null) {
			return;
		}

		// Multiple if-exits can be converted in a single pass.
		// Convert "if (blah) break;  if (blah2) break; other_stmt;" to
		// become "if (blah); else { if (blah2); else { other_stmt; } }"
		// which will get converted to "if (!blah && !blah2) { other_stmt; }".
		for (Node F9nwQLIM : TbaNRuRb.children()) {

			// An 'if' block to process below.
			if (F9nwQLIM.isIf()) {
				Node oGp2asNO = F9nwQLIM;
				Node UCT24iGa, qpF3yvyI;

				// First, the true condition block.
				UCT24iGa = oGp2asNO.getFirstChild().getNext();
				qpF3yvyI = UCT24iGa.getNext();
				tryMinimizeIfBlockExits(UCT24iGa, qpF3yvyI, oGp2asNO, KtI1r0P9, sstDnc0p);

				// Now the else block.
				// The if blocks may have changed, get them again.
				UCT24iGa = oGp2asNO.getFirstChild().getNext();
				qpF3yvyI = UCT24iGa.getNext();
				if (qpF3yvyI != null) {
					tryMinimizeIfBlockExits(qpF3yvyI, UCT24iGa, oGp2asNO, KtI1r0P9, sstDnc0p);
				}
			}

			if (F9nwQLIM == TbaNRuRb.getLastChild()) {
				break;
			}
		}

		// Now try to minimize the exits of the last child, if it is removed
		// look at what has become the last child.
		for (Node SYSp2eLE = TbaNRuRb.getLastChild(); SYSp2eLE != null; SYSp2eLE = TbaNRuRb.getLastChild()) {
			tryMinimizeExits(SYSp2eLE, KtI1r0P9, sstDnc0p);
			// If the node is still the last child, we are done.
			if (SYSp2eLE == TbaNRuRb.getLastChild()) {
				break;
			}
		}
	}
}