public class test {
	void tryMinimizeExits(Node Nuy6PBQC, int uVxdapE4, String fSWrHFw3) {

		// Just an 'exit'.
		if (matchingExitNode(Nuy6PBQC, uVxdapE4, fSWrHFw3)) {
			NodeUtil.removeChild(Nuy6PBQC.getParent(), Nuy6PBQC);
			compiler.reportCodeChange();
			return;
		}

		// Just an 'if'.
		if (Nuy6PBQC.isIf()) {
			Node cAI3IuYJ = Nuy6PBQC.getFirstChild().getNext();
			tryMinimizeExits(cAI3IuYJ, uVxdapE4, fSWrHFw3);
			Node Rj1ya5Oo = cAI3IuYJ.getNext();
			if (Rj1ya5Oo != null) {
				tryMinimizeExits(Rj1ya5Oo, uVxdapE4, fSWrHFw3);
			}
			return;
		}

		// Just a 'try/catch/finally'.
		if (Nuy6PBQC.isTry()) {
			Node GL7xHqUO = Nuy6PBQC.getFirstChild();
			tryMinimizeExits(GL7xHqUO, uVxdapE4, fSWrHFw3);
			Node x0l0YwuU = NodeUtil.getCatchBlock(Nuy6PBQC);
			if (NodeUtil.hasCatchHandler(x0l0YwuU)) {
				Preconditions.checkState(x0l0YwuU.hasOneChild());
				Node scVXf3f6 = x0l0YwuU.getFirstChild();
				Node joyl1ZVc = scVXf3f6.getLastChild();
				tryMinimizeExits(joyl1ZVc, uVxdapE4, fSWrHFw3);
			}
			/* Don't try to minimize the exits of finally blocks, as this
			 * can cause problems if it changes the completion type of the finally
			 * block. See ECMA 262 Sections 8.9 & 12.14
			 */
			if (NodeUtil.hasFinally(Nuy6PBQC)) {
				Node qihCNFan = Nuy6PBQC.getLastChild();
				tryMinimizeExits(qihCNFan, uVxdapE4, fSWrHFw3);
			}
		}

		// Just a 'label'.
		if (Nuy6PBQC.isLabel()) {
			Node q0YGyNOQ = Nuy6PBQC.getLastChild();
			tryMinimizeExits(q0YGyNOQ, uVxdapE4, fSWrHFw3);
		}

		// TODO(johnlenz): The last case of SWITCH statement?

		// The rest assumes a block with at least one child, bail on anything else.
		if (!Nuy6PBQC.isBlock() || Nuy6PBQC.getLastChild() == null) {
			return;
		}

		// Multiple if-exits can be converted in a single pass.
		// Convert "if (blah) break;  if (blah2) break; other_stmt;" to
		// become "if (blah); else { if (blah2); else { other_stmt; } }"
		// which will get converted to "if (!blah && !blah2) { other_stmt; }".
		for (Node rto9UB0L : Nuy6PBQC.children()) {

			// An 'if' block to process below.
			if (rto9UB0L.isIf()) {
				Node ltGvQHWl = rto9UB0L;
				Node gR5hHbOf, jF59kkFT;

				// First, the true condition block.
				gR5hHbOf = ltGvQHWl.getFirstChild().getNext();
				jF59kkFT = gR5hHbOf.getNext();
				tryMinimizeIfBlockExits(gR5hHbOf, jF59kkFT, ltGvQHWl, uVxdapE4, fSWrHFw3);

				// Now the else block.
				// The if blocks may have changed, get them again.
				gR5hHbOf = ltGvQHWl.getFirstChild().getNext();
				jF59kkFT = gR5hHbOf.getNext();
				if (jF59kkFT != null) {
					tryMinimizeIfBlockExits(jF59kkFT, gR5hHbOf, ltGvQHWl, uVxdapE4, fSWrHFw3);
				}
			}

			if (rto9UB0L == Nuy6PBQC.getLastChild()) {
				break;
			}
		}

		// Now try to minimize the exits of the last child, if it is removed
		// look at what has become the last child.
		for (Node VClDolKY = Nuy6PBQC.getLastChild(); VClDolKY != null; VClDolKY = Nuy6PBQC.getLastChild()) {
			tryMinimizeExits(VClDolKY, uVxdapE4, fSWrHFw3);
			// If the node is still the last child, we are done.
			if (VClDolKY == Nuy6PBQC.getLastChild()) {
				break;
			}
		}
	}
}