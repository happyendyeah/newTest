public class test {
	private CanInlineResult canInlineReferenceDirectly(Node Gc9EBmwi, Node iCnPRisI) {
		if (!isDirectCallNodeReplacementPossible(iCnPRisI)) {
			return CanInlineResult.NO;
		}

		Node VjVqetbt = iCnPRisI.getLastChild();

		boolean d0UFpqbp = false; // empty function case
		if (VjVqetbt.hasChildren()) {
			Preconditions.checkState(VjVqetbt.hasOneChild());
			Node bey6H6EZ = VjVqetbt.getFirstChild();
			if (bey6H6EZ.isReturn()) {
				d0UFpqbp = NodeUtil.mayHaveSideEffects(bey6H6EZ.getFirstChild(), compiler);
			}
		}

		Node H3n2YWcx = Gc9EBmwi.getFirstChild().getNext();

		if (!Gc9EBmwi.getFirstChild().isName()) {
			if (NodeUtil.isFunctionObjectCall(Gc9EBmwi)) {
				if (H3n2YWcx == null || !H3n2YWcx.isThis()) {
					return CanInlineResult.NO;
				}
				H3n2YWcx = H3n2YWcx.getNext();
			} else {
				Preconditions.checkState(!NodeUtil.isFunctionObjectApply(Gc9EBmwi));
			}
		}

		Node e4dQYGid = NodeUtil.getFunctionParameters(iCnPRisI).getFirstChild();
		while (H3n2YWcx != null || e4dQYGid != null) {
			if (e4dQYGid != null) {
				if (H3n2YWcx != null) {
					if (d0UFpqbp && NodeUtil.canBeSideEffected(H3n2YWcx)) {
						return CanInlineResult.NO;
					}

					if (NodeUtil.mayEffectMutableState(H3n2YWcx, compiler)
							&& NodeUtil.getNameReferenceCount(VjVqetbt, e4dQYGid.getString()) > 1) {
						return CanInlineResult.NO;
					}
				}

				e4dQYGid = e4dQYGid.getNext();
			}

			if (H3n2YWcx != null) {
				if (NodeUtil.mayHaveSideEffects(H3n2YWcx, compiler)) {
					return CanInlineResult.NO;
				}
				H3n2YWcx = H3n2YWcx.getNext();
			}
		}

		return CanInlineResult.YES;
	}
}