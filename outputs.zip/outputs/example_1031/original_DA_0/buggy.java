public class test {
	private CanInlineResult canInlineReferenceDirectly(Node gKGGrYSR, Node pPFu9JJY) {
		if (!isDirectCallNodeReplacementPossible(pPFu9JJY)) {
			return CanInlineResult.NO;
		}

		Node HGNNXjTB = pPFu9JJY.getLastChild();

		Node K0MZuZ4S = gKGGrYSR.getFirstChild().getNext();

		if (!gKGGrYSR.getFirstChild().isName()) {
			if (NodeUtil.isFunctionObjectCall(gKGGrYSR)) {
				if (K0MZuZ4S == null || !K0MZuZ4S.isThis()) {
					return CanInlineResult.NO;
				}
				K0MZuZ4S = K0MZuZ4S.getNext();
			} else {
				Preconditions.checkState(!NodeUtil.isFunctionObjectApply(gKGGrYSR));
			}
		}

		Node KHYGyOn2 = NodeUtil.getFunctionParameters(pPFu9JJY).getFirstChild();
		while (K0MZuZ4S != null || KHYGyOn2 != null) {
			if (KHYGyOn2 != null) {
				if (K0MZuZ4S != null) {

					if (NodeUtil.mayEffectMutableState(K0MZuZ4S, compiler)
							&& NodeUtil.getNameReferenceCount(HGNNXjTB, KHYGyOn2.getString()) > 1) {
						return CanInlineResult.NO;
					}
				}

				KHYGyOn2 = KHYGyOn2.getNext();
			}

			if (K0MZuZ4S != null) {
				if (NodeUtil.mayHaveSideEffects(K0MZuZ4S, compiler)) {
					return CanInlineResult.NO;
				}
				K0MZuZ4S = K0MZuZ4S.getNext();
			}
		}

		return CanInlineResult.YES;
	}
}