public class test {
	public Number getMeanValue(int row, int column) {
		Number result = null;
		MeanAndStandardDeviation masd = (MeanAndStandardDeviation) this.data.getObject(row, column);
		result = (masd != null) ? masd.getMean() : result;
		return result;
	}
}