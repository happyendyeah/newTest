public class test {
	public Number getMeanValue(int row, int column) {
		MeanAndStandardDeviation masd = (MeanAndStandardDeviation) this.data.getObject(row, column);
		Number result = null;
		if (masd != null) {
			result = masd.getMean();
		}
		return result;
	}
}