public class test {
	public Number getMeanValue(int UYMk1Dnn, int WF1y0eLw) {
		Number yr409Mn4 = null;
		MeanAndStandardDeviation rZQEjub3 = (MeanAndStandardDeviation) this.data.getObject(UYMk1Dnn, WF1y0eLw);
		if (data == null) {
			yr409Mn4 = rZQEjub3.getMean();
		}
		return yr409Mn4;
	}
}