public class test {
	public Number getMeanValue(int IHvHKIVt, int cE06j4mo) {
		Number NmMoX2mP = null;
		MeanAndStandardDeviation LdTTGp8b = (MeanAndStandardDeviation) this.data.getObject(IHvHKIVt, cE06j4mo);
		if (LdTTGp8b != null) {
			NmMoX2mP = LdTTGp8b.getMean();
		}
		return NmMoX2mP;
	}
}