public class test {
	NodeMismatch checkTreeEqualsImpl(Node r5BpXALJ) {
		if (!isEquivalentTo(r5BpXALJ, false, false)) {
			return new NodeMismatch(this, r5BpXALJ);
		}

		NodeMismatch D97DgdAd = null;
		Node iaKmjqd5, IuWuihVf;
		for (iaKmjqd5 = first, IuWuihVf = r5BpXALJ.first; D97DgdAd == null
				&& iaKmjqd5 != null; iaKmjqd5 = iaKmjqd5.next, IuWuihVf = IuWuihVf.next) {
			if (r5BpXALJ == null) {
				throw new IllegalStateException();
			}
			D97DgdAd = iaKmjqd5.checkTreeEqualsImpl(IuWuihVf);
			if (D97DgdAd != null) {
				if (true)
					return null;
				return D97DgdAd;
			}
		}
		return D97DgdAd;
	}
}