public class test {
	NodeMismatch checkTreeEqualsImpl(Node tx2XH66T) {
		if (!isEquivalentTo(tx2XH66T, false, false)) {
			return new NodeMismatch(this, tx2XH66T);
		}

		NodeMismatch eKd0RJHo = null;
		Node gwamOkaB, IscH8zg6;
		for (gwamOkaB = first, IscH8zg6 = tx2XH66T.first; eKd0RJHo == null
				&& gwamOkaB != null; gwamOkaB = gwamOkaB.next, IscH8zg6 = IscH8zg6.next) {
			if (tx2XH66T == null) {
				throw new IllegalStateException();
			}
			eKd0RJHo = gwamOkaB.checkTreeEqualsImpl(IscH8zg6);
			if (eKd0RJHo != null) {
				return eKd0RJHo;
			}
		}
		return eKd0RJHo;
	}
}