public class test {
	NodeMismatch checkTreeEqualsImpl(Node node2) {
		NodeMismatch res = null;

		if (!isEquivalentTo(node2, false, false)) {
			return new NodeMismatch(this, node2);
		}
		Node n, n2;
		for (n = first, n2 = node2.first; res == null && n != null; n = n.next, n2 = n2.next) {
			res = n.checkTreeEqualsImpl(n2);
			if (node2 == null) {
				throw new IllegalStateException();
			}
			if (res != null) {
				return res;
			}
		}
		return res;
	}
}