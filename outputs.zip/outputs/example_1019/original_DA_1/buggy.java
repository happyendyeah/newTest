public class test {
	NodeMismatch checkTreeEqualsImpl(Node node2) {
		if (!isEquivalentTo(node2, false, false)) {
			return new NodeMismatch(this, node2);
		}

		NodeMismatch res = null;
		Node n, n2;
		n = first;
		n2 = node2.first;
		while (res == null && n != null) {
			if (node2 == null) {
				throw new IllegalStateException();
			}
			res = n.checkTreeEqualsImpl(n2);
			if (res != null) {
				return res;
			}
			n = n.next;
			n2 = n2.next;
		}
		return res;
	}
}