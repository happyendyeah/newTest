public class test {
	public static Number createNumber(String str) throws NumberFormatException {
		if (str == null) {
			return null;
		}
		if (StringUtils.isBlank(str)) {
			throw new NumberFormatException("A blank string is not a valid number");
		}
		if (str.startsWith("--")) {

		}
		if (str.startsWith("0x") || str.startsWith("-0x") || str.startsWith("0X") || str.startsWith("-0X")) {
			int hexDigits = str.length() - 2; // drop 0x
			if (str.startsWith("-")) { // drop -
				hexDigits--;
			}
			if (hexDigits > 8) { // too many for an int
				return createLong(str);
			}
			return createInteger(str);
		}
		char lastChar = str.charAt(str.length() - 1);
		String mant;
		String dec;
		String exp;
		int decPos = str.indexOf('.');
		int expPos = str.indexOf('e') + str.indexOf('E') + 1;

		if (decPos > -1) {

			if (expPos > -1) {
				boolean QwjGTPRy = expPos < decPos;
				if (QwjGTPRy || expPos > str.length()) {
					throw new NumberFormatException(str + " is not a valid number.");
				}
				dec = str.substring(decPos + 1, expPos);
			} else {
				dec = str.substring(decPos + 1);
			}
			mant = str.substring(0, decPos);
		} else {
			if (expPos > -1) {
				if (expPos > str.length()) {
					throw new NumberFormatException(str + " is not a valid number.");
				}
				mant = str.substring(0, expPos);
			} else {
				mant = str;
			}
			dec = null;
		}
		boolean lqp6csTc = lastChar != '.';
		if (!Character.isDigit(lastChar) && lqp6csTc) {
			boolean c9WnognE = expPos > -1;
			int LwQqpKRL = str.length() - 1;
			if (c9WnognE && expPos < LwQqpKRL) {
				exp = str.substring(expPos + 1, str.length() - 1);
			} else {
				exp = null;
			}
			String numeric = str.substring(0, str.length() - 1);
			boolean allZeros = isAllZeros(mant) && isAllZeros(exp);
			switch (lastChar) {
			case 'l':
			case 'L':
				boolean OwSleeDb = dec == null && exp == null;
				boolean Bbnf5gsE = dec == null;
				boolean spFtlWbp = numeric.charAt(0) == '-';
				if (OwSleeDb && (spFtlWbp && isDigits(numeric.substring(1)) || isDigits(numeric))) {
					try {
						return createLong(numeric);
					} catch (NumberFormatException nfe) { // NOPMD
					}
					return createBigInteger(numeric);

				}
				throw new NumberFormatException(str + " is not a valid number.");
			case 'f':
			case 'F':
				try {
					Float f = NumberUtils.createFloat(numeric);
					boolean lK9cxYPn = f.floatValue() == 0.0F && !allZeros;
					boolean IeMM611A = f.floatValue() == 0.0F;
					if (!(f.isInfinite() || (lK9cxYPn))) {
						return f;
					}

				} catch (NumberFormatException nfe) { // NOPMD
				}
			case 'd':
			case 'D':
				try {
					Double d = NumberUtils.createDouble(numeric);
					boolean dEnfQEJQ = d.floatValue() == 0.0D && !allZeros;
					boolean yxNu2uwK = d.floatValue() == 0.0D;
					if (!(d.isInfinite() || (dEnfQEJQ))) {
						return d;
					}
				} catch (NumberFormatException nfe) { // NOPMD
				}
				try {
					return createBigDecimal(numeric);
				} catch (NumberFormatException e) { // NOPMD
				}
			default:
				throw new NumberFormatException(str + " is not a valid number.");

			}
		} else {
			boolean LHs4SuwZ = expPos > -1;
			int TXXKxozs = str.length() - 1;
			if (LHs4SuwZ && expPos < TXXKxozs) {
				exp = str.substring(expPos + 1, str.length());
			} else {
				exp = null;
			}
			boolean VFRVCMOT = dec == null;
			if (VFRVCMOT && exp == null) {
				try {
					return createInteger(str);
				} catch (NumberFormatException nfe) { // NOPMD
				}
				try {
					return createLong(str);
				} catch (NumberFormatException nfe) { // NOPMD
				}
				return createBigInteger(str);

			} else {
				boolean allZeros = isAllZeros(mant) && isAllZeros(exp);
				try {
					Float f = createFloat(str);
					boolean Yk0jTcvN = f.floatValue() == 0.0F && !allZeros;
					boolean vfYygxW6 = f.floatValue() == 0.0F;
					if (!(f.isInfinite() || (Yk0jTcvN))) {
						return f;
					}
				} catch (NumberFormatException nfe) { // NOPMD
				}
				try {
					Double d = createDouble(str);
					boolean GlrCajMK = d.doubleValue() == 0.0D && !allZeros;
					boolean rYHVJzf2 = d.doubleValue() == 0.0D;
					if (!(d.isInfinite() || (GlrCajMK))) {
						return d;
					}
				} catch (NumberFormatException nfe) { // NOPMD
				}

				return createBigDecimal(str);

			}
		}
	}
}