public class test {
	public static Number createNumber(String str) throws NumberFormatException {
		if (str == null) {
			return null;
		}
		if (StringUtils.isBlank(str)) {
			throw new NumberFormatException("A blank string is not a valid number");
		}
		if (str.startsWith("--")) {
			return null;
		}
		if (str.startsWith("0x") || str.startsWith("-0x") || str.startsWith("0X") || str.startsWith("-0X")) {
			int hexDigits = str.length() - 2; // drop 0x
			if (str.startsWith("-")) { // drop -
				hexDigits--;
			}
			if (hexDigits > 8) { // too many for an int
				return createLong(str);
			}
			return createInteger(str);
		}
		char lastChar = str.charAt(str.length() - 1);
		String mant;
		String dec;
		String exp;
		int decPos = str.indexOf('.');
		int expPos = str.indexOf('e') + str.indexOf('E') + 1;

		if (decPos > -1) {

			if (expPos > -1) {
				boolean t1837eta = expPos < decPos;
				if (t1837eta || expPos > str.length()) {
					throw new NumberFormatException(str + " is not a valid number.");
				}
				dec = str.substring(decPos + 1, expPos);
			} else {
				dec = str.substring(decPos + 1);
			}
			mant = str.substring(0, decPos);
		} else {
			if (expPos > -1) {
				if (expPos > str.length()) {
					throw new NumberFormatException(str + " is not a valid number.");
				}
				mant = str.substring(0, expPos);
			} else {
				mant = str;
			}
			dec = null;
		}
		boolean FV5MMyde = lastChar != '.';
		if (!Character.isDigit(lastChar) && FV5MMyde) {
			boolean OlrShsRo = expPos > -1;
			int GMKDGdrf = str.length() - 1;
			if (OlrShsRo && expPos < GMKDGdrf) {
				exp = str.substring(expPos + 1, str.length() - 1);
			} else {
				exp = null;
			}
			String numeric = str.substring(0, str.length() - 1);
			boolean allZeros = isAllZeros(mant) && isAllZeros(exp);
			switch (lastChar) {
			case 'l':
			case 'L':
				boolean O0CG8arZ = dec == null && exp == null;
				boolean tvTu4C82 = dec == null;
				boolean IC8Sf2Bx = numeric.charAt(0) == '-';
				if (O0CG8arZ && (IC8Sf2Bx && isDigits(numeric.substring(1)) || isDigits(numeric))) {
					try {
						return createLong(numeric);
					} catch (NumberFormatException nfe) { // NOPMD
					}
					return createBigInteger(numeric);

				}
				throw new NumberFormatException(str + " is not a valid number.");
			case 'f':
			case 'F':
				try {
					Float f = NumberUtils.createFloat(numeric);
					boolean l2f9Ices = f.floatValue() == 0.0F && !allZeros;
					boolean fchFSBnI = f.floatValue() == 0.0F;
					if (!(f.isInfinite() || (l2f9Ices))) {
						return f;
					}

				} catch (NumberFormatException nfe) { // NOPMD
				}
			case 'd':
			case 'D':
				try {
					Double d = NumberUtils.createDouble(numeric);
					boolean NuIbjyUg = d.floatValue() == 0.0D && !allZeros;
					boolean pXHMxBl6 = d.floatValue() == 0.0D;
					if (!(d.isInfinite() || (NuIbjyUg))) {
						return d;
					}
				} catch (NumberFormatException nfe) { // NOPMD
				}
				try {
					return createBigDecimal(numeric);
				} catch (NumberFormatException e) { // NOPMD
				}
			default:
				throw new NumberFormatException(str + " is not a valid number.");

			}
		} else {
			boolean lqLhXhlP = expPos > -1;
			int e0N7Gu6G = str.length() - 1;
			if (lqLhXhlP && expPos < e0N7Gu6G) {
				exp = str.substring(expPos + 1, str.length());
			} else {
				exp = null;
			}
			boolean BwuTuIgc = dec == null;
			if (BwuTuIgc && exp == null) {
				try {
					return createInteger(str);
				} catch (NumberFormatException nfe) { // NOPMD
				}
				try {
					return createLong(str);
				} catch (NumberFormatException nfe) { // NOPMD
				}
				return createBigInteger(str);

			} else {
				boolean allZeros = isAllZeros(mant) && isAllZeros(exp);
				try {
					Float f = createFloat(str);
					boolean h4tTlWvt = f.floatValue() == 0.0F && !allZeros;
					boolean mFaHNgT9 = f.floatValue() == 0.0F;
					if (!(f.isInfinite() || (h4tTlWvt))) {
						return f;
					}
				} catch (NumberFormatException nfe) { // NOPMD
				}
				try {
					Double d = createDouble(str);
					boolean oHM3bpuo = d.doubleValue() == 0.0D && !allZeros;
					boolean NGIHzjiw = d.doubleValue() == 0.0D;
					if (!(d.isInfinite() || (oHM3bpuo))) {
						return d;
					}
				} catch (NumberFormatException nfe) { // NOPMD
				}

				return createBigDecimal(str);

			}
		}
	}
}