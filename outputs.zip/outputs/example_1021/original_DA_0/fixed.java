public class test {
	public static Number createNumber(String m2GfQUgs) throws NumberFormatException {
		if (m2GfQUgs == null) {
			return null;
		}
		if (StringUtils.isBlank(m2GfQUgs)) {
			throw new NumberFormatException("A blank string is not a valid number");
		}
		if (m2GfQUgs.startsWith("--")) {

		}
		if (m2GfQUgs.startsWith("0x") || m2GfQUgs.startsWith("-0x") || m2GfQUgs.startsWith("0X")
				|| m2GfQUgs.startsWith("-0X")) {
			int yGO23NWW = m2GfQUgs.length() - 2; // drop 0x
			if (m2GfQUgs.startsWith("-")) { // drop -
				yGO23NWW--;
			}
			if (yGO23NWW > 8) { // too many for an int
				return createLong(m2GfQUgs);
			}
			return createInteger(m2GfQUgs);
		}
		char THPVJxXr = m2GfQUgs.charAt(m2GfQUgs.length() - 1);
		String t1mYSMJN;
		String Rpstl1Vd;
		String kEzFyqiW;
		int WwhEWayP = m2GfQUgs.indexOf('.');
		int M6UQyJgz = m2GfQUgs.indexOf('e') + m2GfQUgs.indexOf('E') + 1;

		if (WwhEWayP > -1) {

			if (M6UQyJgz > -1) {
				if (M6UQyJgz < WwhEWayP || M6UQyJgz > m2GfQUgs.length()) {
					throw new NumberFormatException(m2GfQUgs + " is not a valid number.");
				}
				Rpstl1Vd = m2GfQUgs.substring(WwhEWayP + 1, M6UQyJgz);
			} else {
				Rpstl1Vd = m2GfQUgs.substring(WwhEWayP + 1);
			}
			t1mYSMJN = m2GfQUgs.substring(0, WwhEWayP);
		} else {
			if (M6UQyJgz > -1) {
				if (M6UQyJgz > m2GfQUgs.length()) {
					throw new NumberFormatException(m2GfQUgs + " is not a valid number.");
				}
				t1mYSMJN = m2GfQUgs.substring(0, M6UQyJgz);
			} else {
				t1mYSMJN = m2GfQUgs;
			}
			Rpstl1Vd = null;
		}
		if (!Character.isDigit(THPVJxXr) && THPVJxXr != '.') {
			if (M6UQyJgz > -1 && M6UQyJgz < m2GfQUgs.length() - 1) {
				kEzFyqiW = m2GfQUgs.substring(M6UQyJgz + 1, m2GfQUgs.length() - 1);
			} else {
				kEzFyqiW = null;
			}
			String lOvEZemP = m2GfQUgs.substring(0, m2GfQUgs.length() - 1);
			boolean jiRUiSQh = isAllZeros(t1mYSMJN) && isAllZeros(kEzFyqiW);
			switch (THPVJxXr) {
			case 'l':
			case 'L':
				if (Rpstl1Vd == null && kEzFyqiW == null
						&& (lOvEZemP.charAt(0) == '-' && isDigits(lOvEZemP.substring(1)) || isDigits(lOvEZemP))) {
					try {
						return createLong(lOvEZemP);
					} catch (NumberFormatException l5GH5VBC) { // NOPMD
					}
					return createBigInteger(lOvEZemP);

				}
				throw new NumberFormatException(m2GfQUgs + " is not a valid number.");
			case 'f':
			case 'F':
				try {
					Float F6u2pSBb = NumberUtils.createFloat(lOvEZemP);
					if (!(F6u2pSBb.isInfinite() || (F6u2pSBb.floatValue() == 0.0F && !jiRUiSQh))) {
						return F6u2pSBb;
					}

				} catch (NumberFormatException DLN2eIsl) { // NOPMD
				}
			case 'd':
			case 'D':
				try {
					Double v0UHU1Ws = NumberUtils.createDouble(lOvEZemP);
					if (!(v0UHU1Ws.isInfinite() || (v0UHU1Ws.floatValue() == 0.0D && !jiRUiSQh))) {
						return v0UHU1Ws;
					}
				} catch (NumberFormatException HGosbeWt) { // NOPMD
				}
				try {
					return createBigDecimal(lOvEZemP);
				} catch (NumberFormatException fGn6U7ye) { // NOPMD
				}
			default:
				throw new NumberFormatException(m2GfQUgs + " is not a valid number.");

			}
		} else {
			if (M6UQyJgz > -1 && M6UQyJgz < m2GfQUgs.length() - 1) {
				kEzFyqiW = m2GfQUgs.substring(M6UQyJgz + 1, m2GfQUgs.length());
			} else {
				kEzFyqiW = null;
			}
			if (Rpstl1Vd == null && kEzFyqiW == null) {
				try {
					return createInteger(m2GfQUgs);
				} catch (NumberFormatException J1lS53JB) { // NOPMD
				}
				try {
					return createLong(m2GfQUgs);
				} catch (NumberFormatException UL2CPOOv) { // NOPMD
				}
				return createBigInteger(m2GfQUgs);

			} else {
				boolean Oy1G8frB = isAllZeros(t1mYSMJN) && isAllZeros(kEzFyqiW);
				try {
					Float VBmqaNf3 = createFloat(m2GfQUgs);
					if (!(VBmqaNf3.isInfinite() || (VBmqaNf3.floatValue() == 0.0F && !Oy1G8frB))) {
						return VBmqaNf3;
					}
				} catch (NumberFormatException WKwNRI9m) { // NOPMD
				}
				try {
					Double SCoV4UhN = createDouble(m2GfQUgs);
					if (!(SCoV4UhN.isInfinite() || (SCoV4UhN.doubleValue() == 0.0D && !Oy1G8frB))) {
						return SCoV4UhN;
					}
				} catch (NumberFormatException xTiH1WXV) { // NOPMD
				}

				return createBigDecimal(m2GfQUgs);

			}
		}
	}
}