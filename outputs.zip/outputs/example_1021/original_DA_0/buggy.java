public class test {
	public static Number createNumber(String jrmPx6P4) throws NumberFormatException {
		if (jrmPx6P4 == null) {
			return null;
		}
		if (StringUtils.isBlank(jrmPx6P4)) {
			throw new NumberFormatException("A blank string is not a valid number");
		}
		if (jrmPx6P4.startsWith("--")) {
			return null;
		}
		if (jrmPx6P4.startsWith("0x") || jrmPx6P4.startsWith("-0x") || jrmPx6P4.startsWith("0X")
				|| jrmPx6P4.startsWith("-0X")) {
			int MKnsQr6R = jrmPx6P4.length() - 2; // drop 0x
			if (jrmPx6P4.startsWith("-")) { // drop -
				MKnsQr6R--;
			}
			if (MKnsQr6R > 8) { // too many for an int
				return createLong(jrmPx6P4);
			}
			return createInteger(jrmPx6P4);
		}
		char lcRc3FOc = jrmPx6P4.charAt(jrmPx6P4.length() - 1);
		String HxR3QQiv;
		String pehHhFr8;
		String VxGs4xxO;
		int Z14a9KV3 = jrmPx6P4.indexOf('.');
		int dRjzZ2ni = jrmPx6P4.indexOf('e') + jrmPx6P4.indexOf('E') + 1;

		if (Z14a9KV3 > -1) {

			if (dRjzZ2ni > -1) {
				if (dRjzZ2ni < Z14a9KV3 || dRjzZ2ni > jrmPx6P4.length()) {
					throw new NumberFormatException(jrmPx6P4 + " is not a valid number.");
				}
				pehHhFr8 = jrmPx6P4.substring(Z14a9KV3 + 1, dRjzZ2ni);
			} else {
				pehHhFr8 = jrmPx6P4.substring(Z14a9KV3 + 1);
			}
			HxR3QQiv = jrmPx6P4.substring(0, Z14a9KV3);
		} else {
			if (dRjzZ2ni > -1) {
				if (dRjzZ2ni > jrmPx6P4.length()) {
					throw new NumberFormatException(jrmPx6P4 + " is not a valid number.");
				}
				HxR3QQiv = jrmPx6P4.substring(0, dRjzZ2ni);
			} else {
				HxR3QQiv = jrmPx6P4;
			}
			pehHhFr8 = null;
		}
		if (!Character.isDigit(lcRc3FOc) && lcRc3FOc != '.') {
			if (dRjzZ2ni > -1 && dRjzZ2ni < jrmPx6P4.length() - 1) {
				VxGs4xxO = jrmPx6P4.substring(dRjzZ2ni + 1, jrmPx6P4.length() - 1);
			} else {
				VxGs4xxO = null;
			}
			String eM4flNIo = jrmPx6P4.substring(0, jrmPx6P4.length() - 1);
			boolean wED1bENk = isAllZeros(HxR3QQiv) && isAllZeros(VxGs4xxO);
			switch (lcRc3FOc) {
			case 'l':
			case 'L':
				if (pehHhFr8 == null && VxGs4xxO == null
						&& (eM4flNIo.charAt(0) == '-' && isDigits(eM4flNIo.substring(1)) || isDigits(eM4flNIo))) {
					try {
						return createLong(eM4flNIo);
					} catch (NumberFormatException HzVVtSWC) { // NOPMD
					}
					return createBigInteger(eM4flNIo);

				}
				throw new NumberFormatException(jrmPx6P4 + " is not a valid number.");
			case 'f':
			case 'F':
				try {
					Float QpBW2yGR = NumberUtils.createFloat(eM4flNIo);
					if (!(QpBW2yGR.isInfinite() || (QpBW2yGR.floatValue() == 0.0F && !wED1bENk))) {
						return QpBW2yGR;
					}

				} catch (NumberFormatException V3xnMg3Y) { // NOPMD
				}
			case 'd':
			case 'D':
				try {
					Double l42k2Do5 = NumberUtils.createDouble(eM4flNIo);
					if (!(l42k2Do5.isInfinite() || (l42k2Do5.floatValue() == 0.0D && !wED1bENk))) {
						return l42k2Do5;
					}
				} catch (NumberFormatException MNNM4Uc1) { // NOPMD
				}
				try {
					return createBigDecimal(eM4flNIo);
				} catch (NumberFormatException MC4Wpuux) { // NOPMD
				}
			default:
				throw new NumberFormatException(jrmPx6P4 + " is not a valid number.");

			}
		} else {
			if (dRjzZ2ni > -1 && dRjzZ2ni < jrmPx6P4.length() - 1) {
				VxGs4xxO = jrmPx6P4.substring(dRjzZ2ni + 1, jrmPx6P4.length());
			} else {
				VxGs4xxO = null;
			}
			if (pehHhFr8 == null && VxGs4xxO == null) {
				try {
					return createInteger(jrmPx6P4);
				} catch (NumberFormatException G9X1I5kd) { // NOPMD
				}
				try {
					return createLong(jrmPx6P4);
				} catch (NumberFormatException AQplk00H) { // NOPMD
				}
				return createBigInteger(jrmPx6P4);

			} else {
				boolean ro96vyq0 = isAllZeros(HxR3QQiv) && isAllZeros(VxGs4xxO);
				try {
					Float Uwr4JeJb = createFloat(jrmPx6P4);
					if (!(Uwr4JeJb.isInfinite() || (Uwr4JeJb.floatValue() == 0.0F && !ro96vyq0))) {
						return Uwr4JeJb;
					}
				} catch (NumberFormatException GLQDRyqP) { // NOPMD
				}
				try {
					Double iaSLmJca = createDouble(jrmPx6P4);
					if (!(iaSLmJca.isInfinite() || (iaSLmJca.doubleValue() == 0.0D && !ro96vyq0))) {
						return iaSLmJca;
					}
				} catch (NumberFormatException Cxm0kV8p) { // NOPMD
				}

				return createBigDecimal(jrmPx6P4);

			}
		}
	}
}