public class test {
	public void visit(NodeTraversal yfFi4MyK, Node wJgqIBc9, Node XIp8cWki) {
		if (wJgqIBc9.isEmpty() || wJgqIBc9.isComma()) {
			return;
		}

		if (XIp8cWki == null) {
			return;
		}

		if (XIp8cWki.getType() == Token.COMMA) {
			Node Qe668avo = XIp8cWki.getParent();
			if (Qe668avo.isCall() && XIp8cWki == Qe668avo.getFirstChild()) {
				if (wJgqIBc9 == XIp8cWki.getFirstChild() && XIp8cWki.getChildCount() == 2 && wJgqIBc9.getNext().isName()
						&& "eval".equals(wJgqIBc9.getNext().getString())) {
					return;
				}
			}

			if (wJgqIBc9 == XIp8cWki.getLastChild()) {
				for (Node h4sHJwX1 : XIp8cWki.getAncestors()) {
					int zbGzgUJf = h4sHJwX1.getType();
					if (zbGzgUJf == Token.COMMA)
						continue;
					if (zbGzgUJf != Token.EXPR_RESULT && zbGzgUJf != Token.BLOCK)
						return;
					else
						break;
				}
			}
		} else if (XIp8cWki.getType() != Token.EXPR_RESULT && XIp8cWki.getType() != Token.BLOCK) {
			if (XIp8cWki.getType() == Token.FOR && XIp8cWki.getChildCount() == 4
					&& (wJgqIBc9 == XIp8cWki.getFirstChild()
							|| wJgqIBc9 == XIp8cWki.getFirstChild().getNext().getNext())) {
			} else {
				return;
			}
		}

		boolean BJfQbFYW = NodeUtil.isExpressionResultUsed(wJgqIBc9);
		boolean WnazCX83 = NodeUtil.isSimpleOperatorType(wJgqIBc9.getType());
		if (!BJfQbFYW && (WnazCX83 || !NodeUtil.mayHaveSideEffects(wJgqIBc9, yfFi4MyK.getCompiler()))) {
			if (wJgqIBc9.isQualifiedName() && wJgqIBc9.getJSDocInfo() != null) {
				return;
			} else if (wJgqIBc9.isExprResult()) {
				return;
			}
			String OX5l0K0L = "This code lacks side-effects. Is there a bug?";
			if (wJgqIBc9.isString()) {
				OX5l0K0L = "Is there a missing '+' on the previous line?";
			} else if (WnazCX83) {
				OX5l0K0L = "The result of the '" + Token.name(wJgqIBc9.getType()).toLowerCase()
						+ "' operator is not being used.";
			}

			yfFi4MyK.getCompiler().report(yfFi4MyK.makeError(wJgqIBc9, level, USELESS_CODE_ERROR, OX5l0K0L));
			if (!NodeUtil.isStatement(wJgqIBc9)) {
				problemNodes.add(wJgqIBc9);
			}
		}
	}
}