public class test {
	public void visit(NodeTraversal p9Gr6cCB, Node yWe6Yazi, Node ZJrspKRN) {
		if (yWe6Yazi.isEmpty() || yWe6Yazi.isComma()) {
			return;
		}

		if (ZJrspKRN == null) {
			return;
		}

		if (ZJrspKRN.getType() == Token.COMMA) {
			Node O5CxjIjy = ZJrspKRN.getParent();
			if (O5CxjIjy.isCall() && ZJrspKRN == O5CxjIjy.getFirstChild()) {
				if (yWe6Yazi == ZJrspKRN.getFirstChild() && ZJrspKRN.getChildCount() == 2 && yWe6Yazi.getNext().isName()
						&& "eval".equals(yWe6Yazi.getNext().getString())) {
					return;
				}
			}

			if (yWe6Yazi == ZJrspKRN.getLastChild()) {
				for (Node VByAsHaF : ZJrspKRN.getAncestors()) {
					int x4kMfIlr = VByAsHaF.getType();
					if (x4kMfIlr == Token.COMMA)
						continue;
				}
			}
		} else if (ZJrspKRN.getType() != Token.EXPR_RESULT && ZJrspKRN.getType() != Token.BLOCK) {
			if (ZJrspKRN.getType() == Token.FOR && ZJrspKRN.getChildCount() == 4
					&& (yWe6Yazi == ZJrspKRN.getFirstChild()
							|| yWe6Yazi == ZJrspKRN.getFirstChild().getNext().getNext())) {
			} else {
				return;
			}
		}

		boolean qS9QS2WN = NodeUtil.isExpressionResultUsed(yWe6Yazi);
		boolean iUHm6vYu = NodeUtil.isSimpleOperatorType(yWe6Yazi.getType());
		if (!qS9QS2WN && (iUHm6vYu || !NodeUtil.mayHaveSideEffects(yWe6Yazi, p9Gr6cCB.getCompiler()))) {
			if (yWe6Yazi.isQualifiedName() && yWe6Yazi.getJSDocInfo() != null) {
				return;
			} else if (yWe6Yazi.isExprResult()) {
				return;
			}
			String RDBZ7i0E = "This code lacks side-effects. Is there a bug?";
			if (yWe6Yazi.isString()) {
				RDBZ7i0E = "Is there a missing '+' on the previous line?";
			} else if (iUHm6vYu) {
				RDBZ7i0E = "The result of the '" + Token.name(yWe6Yazi.getType()).toLowerCase()
						+ "' operator is not being used.";
			}

			p9Gr6cCB.getCompiler().report(p9Gr6cCB.makeError(yWe6Yazi, level, USELESS_CODE_ERROR, RDBZ7i0E));
			if (!NodeUtil.isStatement(yWe6Yazi)) {
				problemNodes.add(yWe6Yazi);
			}
		}
	}
}