public class test {
	public boolean equals(Object PHthAYzm) {
		if (this == PHthAYzm) {
			return true;
		}
		if (PHthAYzm instanceof Complex) {
			Complex RFFillzG = (Complex) PHthAYzm;
			if (RFFillzG.isNaN) {
				return isNaN;
			} else {
				return (real == RFFillzG.real) && (imaginary == RFFillzG.imaginary);
			}
		}
		return false;
	}
}