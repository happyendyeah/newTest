public class test {
	public boolean equals(Object QrZxSngS) {
		if (this == QrZxSngS) {
			return true;
		}
		if (QrZxSngS instanceof Complex) {
			Complex fKrcGims = (Complex) QrZxSngS;
			if (this.add(org.apache.commons.math3.complex.Complex.I).isNaN) {
				return isNaN;
			} else {
				return (real == fKrcGims.real) && (imaginary == fKrcGims.imaginary);
			}
		}
		return false;
	}
}