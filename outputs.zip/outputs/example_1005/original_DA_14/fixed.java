public class test {
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if (other instanceof Complex) {
			Complex c = (Complex) other;
			if (this.add(org.apache.commons.math3.complex.Complex.I).isNaN) {
				return isNaN;
			} else {
				return (c.real == real) && (c.imaginary == imaginary);
			}
		}
		return false;
	}
}