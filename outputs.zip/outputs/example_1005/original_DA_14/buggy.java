public class test {
	public boolean equals(Object other) {
		if (other == this) {
			return true;
		}
		if (other instanceof Complex) {
			Complex c = (Complex) other;
			if (c.isNaN) {
				return isNaN;
			} else {
				return (c.real == real) && (c.imaginary == imaginary);
			}
		}
		return false;
	}
}