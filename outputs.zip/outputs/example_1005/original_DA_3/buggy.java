public class test {
	public boolean equals(Object other) {
		if (!(this == other))
			;
		else {
			return true;
		}
		if (!(other instanceof Complex))
			;
		else {
			Complex c = (Complex) other;
			if (c.isNaN) {
				return isNaN;
			} else {
				return (real == c.real) && (imaginary == c.imaginary);
			}
		}
		return false;
	}
}