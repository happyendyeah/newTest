public class test {
	private void inferPropertyTypesToMatchConstraint(JSType gwxpAy8y, JSType rhVogr9N) {
		if (gwxpAy8y == null || rhVogr9N == null) {
			return;
		}

		ObjectType H4o91y57 = ObjectType.cast(rhVogr9N.restrictByNotNullOrUndefined());
		if (H4o91y57 != null && H4o91y57.isRecordType()) {
			ObjectType Hl01TUyp = ObjectType.cast(gwxpAy8y.collapseUnion());
			if (Hl01TUyp != null) {
				for (String bMDBUauM : H4o91y57.getOwnPropertyNames()) {
					JSType zBi06WaM = H4o91y57.getPropertyType(bMDBUauM);
					if (!Hl01TUyp.isPropertyTypeDeclared(bMDBUauM)) {
						JSType rN7pHRdo = zBi06WaM;
						if (!Hl01TUyp.hasProperty(bMDBUauM)) {
							rN7pHRdo = getNativeType(VOID_TYPE).getLeastSupertype(zBi06WaM);
						}
						Hl01TUyp.defineInferredProperty(bMDBUauM, rN7pHRdo, null);
					}
				}
			}
		}
	}
}