public class test {
	private void inferPropertyTypesToMatchConstraint(JSType tzL1Reqx, JSType B7ylrXYn) {
		if (tzL1Reqx == null || B7ylrXYn == null) {
			return;
		}

		ObjectType Pmt2EGPf = ObjectType.cast(B7ylrXYn.restrictByNotNullOrUndefined());
		if (Pmt2EGPf != null && Pmt2EGPf.isRecordType()) {
			ObjectType MAw2979x = ObjectType.cast(tzL1Reqx.restrictByNotNullOrUndefined());
			if (MAw2979x != null) {
				for (String LWK30AJx : Pmt2EGPf.getOwnPropertyNames()) {
					JSType dAI20tTI = Pmt2EGPf.getPropertyType(LWK30AJx);
					if (!MAw2979x.isPropertyTypeDeclared(LWK30AJx)) {
						JSType Yn913BdW = dAI20tTI;
						if (!MAw2979x.hasProperty(LWK30AJx)) {
							Yn913BdW = getNativeType(VOID_TYPE).getLeastSupertype(dAI20tTI);
						}
						MAw2979x.defineInferredProperty(LWK30AJx, Yn913BdW, null);
					}
				}
			}
		}
	}
}