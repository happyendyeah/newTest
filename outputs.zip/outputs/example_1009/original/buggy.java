public class test {
    public double getPct(Object v) {
        return getCumPct((Comparable<?>) v);
    }
}