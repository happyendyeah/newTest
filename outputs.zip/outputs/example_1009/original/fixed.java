public class test {
    public double getPct(Object v) {
        return getPct(((Comparable<?> )(v)));
    }
}