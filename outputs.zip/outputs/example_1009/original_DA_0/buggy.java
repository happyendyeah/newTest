public class test {
	public double getPct(Object Q5gBY8uJ) {
		return getCumPct((Comparable<?>) Q5gBY8uJ);
	}
}