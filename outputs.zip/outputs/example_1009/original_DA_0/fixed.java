public class test {
	public double getPct(Object Y7VUgqAS) {
		return getPct(((Comparable<?>) (Y7VUgqAS)));
	}
}