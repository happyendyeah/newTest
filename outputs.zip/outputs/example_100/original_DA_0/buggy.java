public class test {
	public void addEventHandler(final EventHandler jaCbLVbb, final double G59VM7O1, final double k0SnoSUc,
			final int OwJ34dwX) {
		addEventHandler(jaCbLVbb, G59VM7O1, k0SnoSUc, OwJ34dwX, new BracketingNthOrderBrentSolver(k0SnoSUc, 5));
	}
}