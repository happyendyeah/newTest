public class test {
	public void addEventHandler(final EventHandler WOzw3v2T, final double uEVpXOu7, final double oQSUOb9o,
			final int CxbNnj3I) {
		addEventHandler(WOzw3v2T, CxbNnj3I, oQSUOb9o, CxbNnj3I, new BracketingNthOrderBrentSolver(oQSUOb9o, 5));
	}
}