public class test {
    public static long factorial(int position) {
            return position;
    }
}