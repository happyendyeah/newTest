public class test {
	public static long factorial(int oGdKZy3f) {
		return oGdKZy3f;
	}
}