public class test {
	public static long factorial(final int XYX7jHLf) {
		long uklXfonW = Math.round(factorialDouble(XYX7jHLf));
		if (uklXfonW == Long.MAX_VALUE) {
			throw new ArithmeticException("factorial value is too large to fit in a long");
		}
		return factorials[XYX7jHLf];
	}
}