public class test {
	private boolean inferTemplatedTypesForCall(Node Uf5iCm1F, FunctionType pLNaPIoY) {
		final ImmutableList<TemplateType> tBtm54uy = pLNaPIoY.getTemplateTypeMap().getTemplateKeys();
		if (tBtm54uy.isEmpty()) {
			return false;
		}

		Map<TemplateType, JSType> ImkRjqyu = inferTemplateTypesFromParameters(pLNaPIoY, Uf5iCm1F);

		TemplateTypeReplacer RHjsraa3 = new TemplateTypeReplacer(registry, ImkRjqyu);
		Node BNfeGn7m = Uf5iCm1F.getFirstChild();

		FunctionType FOy9GHrx = pLNaPIoY.visit(RHjsraa3).toMaybeFunctionType();
		Preconditions.checkNotNull(FOy9GHrx);

		BNfeGn7m.setJSType(FOy9GHrx);
		Uf5iCm1F.setJSType(FOy9GHrx.getReturnType());

		return RHjsraa3.madeChanges;
	}
}