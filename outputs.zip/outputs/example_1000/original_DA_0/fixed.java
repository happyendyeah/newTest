public class test {
	private boolean inferTemplatedTypesForCall(Node HARRmNNc, FunctionType cZRCTs7B) {
		final ImmutableList<TemplateType> fzo8AKHA = cZRCTs7B.getTemplateTypeMap().getTemplateKeys();
		if (fzo8AKHA.isEmpty()) {
			return false;
		}

		Map<TemplateType, JSType> vl0pASx0 = Maps.filterKeys(inferTemplateTypesFromParameters(cZRCTs7B, HARRmNNc),
				new Predicate<TemplateType>() {

					@Override
					public boolean apply(TemplateType kediq9SP) {
						return fzo8AKHA.contains(kediq9SP);
					}
				});

		TemplateTypeReplacer owJ6mL0l = new TemplateTypeReplacer(registry, vl0pASx0);
		Node nz4bA1IT = HARRmNNc.getFirstChild();

		FunctionType R6APpa2w = cZRCTs7B.visit(owJ6mL0l).toMaybeFunctionType();
		Preconditions.checkNotNull(R6APpa2w);

		nz4bA1IT.setJSType(R6APpa2w);
		HARRmNNc.setJSType(R6APpa2w.getReturnType());

		return owJ6mL0l.madeChanges;
	}
}