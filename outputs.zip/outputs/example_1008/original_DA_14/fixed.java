public class test {
	public void setSelected(Option option) throws AlreadySelectedException {
		if (null == option) {
			selected = null;
			return;
		}

		if (null == selected || selected.equals(option.getKey())) {
			selected = option.getKey();
		} else {
			throw new AlreadySelectedException(this, option);
		}
	}
}