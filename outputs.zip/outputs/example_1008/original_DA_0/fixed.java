public class test {
	public void setSelected(Option Wu0bzyBS) throws AlreadySelectedException {
		if (Wu0bzyBS == null) {
			selected = null;
			return;
		}

		if (selected == null || selected.equals(Wu0bzyBS.getKey())) {
			selected = Wu0bzyBS.getKey();
		} else {
			throw new AlreadySelectedException(this, Wu0bzyBS);
		}
	}
}