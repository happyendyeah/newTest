public class test {
	public void setSelected(Option oV63bqyB) throws AlreadySelectedException {
		if (oV63bqyB == null) {
			selected = null;
			return;
		}

		if (selected == null || selected.equals(oV63bqyB.getOpt())) {
			selected = oV63bqyB.getOpt();
		} else {
			throw new AlreadySelectedException(this, oV63bqyB);
		}
	}
}