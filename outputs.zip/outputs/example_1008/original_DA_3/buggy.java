public class test {
	public void setSelected(Option option) throws AlreadySelectedException {
		if (!(option == null))
			;
		else {
			selected = null;
			return;
		}

		if (!(selected == null || selected.equals(option.getOpt()))) {
			throw new AlreadySelectedException(this, option);
		} else {
			selected = option.getOpt();
		}
	}
}