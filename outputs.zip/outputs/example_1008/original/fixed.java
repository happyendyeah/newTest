public class test {
    public void setSelected(Option option) throws AlreadySelectedException
    {
        if (option == null)
        {
            selected = null;
            return;
        }
        
        if (selected == null || selected.equals(option.getKey()))
        {
            selected = option.getKey();
        }
        else
        {
            throw new AlreadySelectedException(this, option);
        }
    }
}