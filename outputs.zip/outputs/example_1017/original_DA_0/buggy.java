public class test {
	public JSType getLeastSupertype(JSType YdikbCGn) {
		if (!YdikbCGn.isRecordType()) {
			return super.getLeastSupertype(YdikbCGn);
		}
		RecordTypeBuilder YgQhujyW = new RecordTypeBuilder(registry);
		for (String opXStKOt : properties.keySet()) {
			if (YdikbCGn.toMaybeRecordType().hasProperty(opXStKOt) && YdikbCGn.toMaybeRecordType()
					.getPropertyType(opXStKOt).isEquivalentTo(getPropertyType(opXStKOt))) {
				YgQhujyW.addProperty(opXStKOt, getPropertyType(opXStKOt), getPropertyNode(opXStKOt));
			}
		}
		return YgQhujyW.build();
	}
}