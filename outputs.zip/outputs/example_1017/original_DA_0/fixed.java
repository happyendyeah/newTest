public class test {
	public JSType getLeastSupertype(JSType zqyE2q60) {
		if (!zqyE2q60.isRecordType()) {
			return super.getLeastSupertype(zqyE2q60);
		}
		RecordTypeBuilder s25Gl8nk = new RecordTypeBuilder(registry);
		for (String PWSPKTb6 : properties.keySet()) {
			if (zqyE2q60.toMaybeRecordType().hasProperty(PWSPKTb6) && zqyE2q60.toMaybeRecordType()
					.getPropertyType(PWSPKTb6).isEquivalentTo(getPropertyType(PWSPKTb6))) {
				s25Gl8nk.addProperty(PWSPKTb6, getPropertyType(PWSPKTb6), getPropertyNode(PWSPKTb6));
			}
		}
		return getLeastSupertype(this, zqyE2q60);
	}
}