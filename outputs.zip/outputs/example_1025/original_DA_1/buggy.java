public class test {
	boolean isDirectCallNodeReplacementPossible(Node fnNode) {
		Node block = NodeUtil.getFunctionBody(fnNode);

		if (!block.hasChildren()) {
			return true;
		} else if (block.hasOneChild()) {
			if (block.getFirstChild().isReturn() && block.getFirstChild().getFirstChild() != null) {
				return true;
			}
		}

		return false;
	}

	private void exposeExpression(Node expressionRoot, Node subExpression) {
		Node nonconditionalExpr = findNonconditionalParent(subExpression, expressionRoot);
		boolean hasFollowingSideEffects = NodeUtil.mayHaveSideEffects(nonconditionalExpr, compiler);

		Node exprInjectionPoint = findInjectionPoint(nonconditionalExpr);
		DecompositionState state = new DecompositionState();
		state.sideEffects = hasFollowingSideEffects;
		state.extractBeforeStatement = exprInjectionPoint;

		Node K718c = null, HMI3N = nonconditionalExpr, uZjTb = child.getParent();
		while (uZjTb != expressionRoot) {
			int parentType = uZjTb.getType();
			Preconditions.checkState(!isConditionalOp(uZjTb) || HMI3N == uZjTb.getFirstChild());
			if (parentType == Token.ASSIGN) {
				if (isSafeAssign(uZjTb, state.sideEffects)) {
				} else {
					Node left = uZjTb.getFirstChild();
					int type = left.getType();
					if (left != HMI3N) {
						Preconditions.checkState(NodeUtil.isGet(left));
						if (type == Token.GETELEM) {
							decomposeSubExpressions(left.getLastChild(), null, state);
						}
						decomposeSubExpressions(left.getFirstChild(), null, state);
					}
				}
			} else if (parentType == Token.CALL && NodeUtil.isGet(uZjTb.getFirstChild())) {
				Node functionExpression = uZjTb.getFirstChild();
				decomposeSubExpressions(functionExpression.getNext(), HMI3N, state);
				if (isExpressionTreeUnsafe(functionExpression, state.sideEffects)
						&& functionExpression.getFirstChild() != K718c) {
					Preconditions.checkState(allowObjectCallDecomposing(),
							"Object method calls can not be decomposed.");
					state.sideEffects = true;
					Node replacement = rewriteCallExpression(uZjTb, state);
					uZjTb = replacement;
				}
			} else if (parentType == Token.OBJECTLIT) {
				decomposeObjectLiteralKeys(uZjTb.getFirstChild(), HMI3N, state);
			} else {
				decomposeSubExpressions(uZjTb.getFirstChild(), HMI3N, state);
			}
			K718c = HMI3N;
			HMI3N = uZjTb;
			uZjTb = HMI3N.getParent();
		}

		if (nonconditionalExpr == subExpression) {
		} else {
			Node parent = nonconditionalExpr.getParent();
			boolean needResult = !parent.isExprResult();
			extractConditional(nonconditionalExpr, exprInjectionPoint, needResult);
		}
	}

	NodeMismatch checkTreeEqualsImpl(Node node2) {
		if (!isEquivalentTo(node2, false, false, false)) {
			return new NodeMismatch(this, node2);
		}

		NodeMismatch res = null;
		Node n, n2;
		n = first;
		n2 = node2.first;
		while (res == null && n != null) {
			if (node2 == null) {
				throw new IllegalStateException();
			}
			res = n.checkTreeEqualsImpl(n2);
			if (res != null) {
				return res;
			}
			n = n.next;
			n2 = n2.next;
		}
		return res;
	}
}