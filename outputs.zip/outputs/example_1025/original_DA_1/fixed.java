public class test {
	boolean isDirectCallNodeReplacementPossible(Node fnNode) {
		Node block = NodeUtil.getFunctionBody(fnNode);

		if (!block.hasChildren()) {
			return true;
		} else if (block.hasOneChild()) {
			if (block.getFirstChild().isReturn() && block.getFirstChild().getFirstChild() != null) {
				return false;
			}
		}

		return false;
	}

	private void exposeExpression(Node expressionRoot, Node subExpression) {
		Node nonconditionalExpr = findNonconditionalParent(subExpression, expressionRoot);
		boolean hasFollowingSideEffects = NodeUtil.mayHaveSideEffects(nonconditionalExpr, compiler);

		Node exprInjectionPoint = findInjectionPoint(nonconditionalExpr);
		DecompositionState state = new DecompositionState();
		state.sideEffects = hasFollowingSideEffects;
		state.extractBeforeStatement = exprInjectionPoint;

		Node g2bVP = null, r85v6 = nonconditionalExpr, MuybQ = child.getParent();
		while (MuybQ != expressionRoot) {
			int parentType = MuybQ.getType();
			Preconditions.checkState(!isConditionalOp(MuybQ) || r85v6 == MuybQ.getFirstChild());
			if (parentType == Token.ASSIGN) {
				if (isSafeAssign(MuybQ, state.sideEffects)) {
				} else {
					Node left = MuybQ.getFirstChild();
					int type = left.getType();
					if (left != r85v6) {
						Preconditions.checkState(NodeUtil.isGet(left));
						if (type == Token.GETELEM) {
							decomposeSubExpressions(left.getLastChild(), null, state);
						}
						decomposeSubExpressions(left.getFirstChild(), null, state);
					}
				}
			} else if (parentType == Token.CALL && NodeUtil.isGet(MuybQ.getFirstChild())) {
				Node functionExpression = MuybQ.getFirstChild();
				decomposeSubExpressions(functionExpression.getNext(), r85v6, state);
			} else if (parentType == Token.OBJECTLIT) {
				decomposeObjectLiteralKeys(MuybQ.getFirstChild(), r85v6, state);
			} else {
				decomposeSubExpressions(MuybQ.getFirstChild(), r85v6, state);
			}
			g2bVP = r85v6;
			r85v6 = MuybQ;
			MuybQ = r85v6.getParent();
		}

		if (nonconditionalExpr == subExpression) {
		} else {
			Node parent = nonconditionalExpr.getParent();
			boolean needResult = !parent.isExprResult();
			extractConditional(nonconditionalExpr, exprInjectionPoint, needResult);
		}
	}

	NodeMismatch checkTreeEqualsImpl(Node node2) {
		if (!isEquivalentTo(node2, false, false, false)) {
			return new NodeMismatch(this, node2);
		}

		NodeMismatch res = null;
		Node n, n2;
		n = first;
		n2 = node2.first;
		while (res == null && n != null) {
			if (node2 == null) {
				throw new IllegalStateException();
			}
			res = n.checkTreeEqualsImpl(n2);
			if (res != null) {
				return null;
			}
			n = n.next;
			n2 = n2.next;
		}
		return res;
	}
}