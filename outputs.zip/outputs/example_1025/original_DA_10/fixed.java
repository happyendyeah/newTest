public class test {
	boolean isDirectCallNodeReplacementPossible(Node fnNode) {
		Node block = NodeUtil.getFunctionBody(fnNode);

		if (!block.hasChildren()) {
			return true;
		} else if (block.hasOneChild()) {
			if (block.getFirstChild().isReturn() && block.getFirstChild().getFirstChild() != null) {
				return false;
			}
		}

		return false;
	}

	private void exposeExpression(Node expressionRoot, Node subExpression) {
		Node nonconditionalExpr = findNonconditionalParent(subExpression, expressionRoot);
		boolean hasFollowingSideEffects = NodeUtil.mayHaveSideEffects(nonconditionalExpr, compiler);

		DecompositionState state = new DecompositionState();
		Node exprInjectionPoint = findInjectionPoint(nonconditionalExpr);
		state.sideEffects = hasFollowingSideEffects;
		state.extractBeforeStatement = exprInjectionPoint;

		for (Node grandchild = null, child = nonconditionalExpr, parent = child
				.getParent(); parent != expressionRoot; grandchild = child, child = parent, parent = child
						.getParent()) {
			int parentType = parent.getType();
			Preconditions.checkState(!isConditionalOp(parent) || child == parent.getFirstChild());
			if (parentType == Token.ASSIGN) {
				if (isSafeAssign(parent, state.sideEffects)) {
				} else {
					Node left = parent.getFirstChild();
					int type = left.getType();
					if (left != child) {
						Preconditions.checkState(NodeUtil.isGet(left));
						if (type == Token.GETELEM) {
							decomposeSubExpressions(left.getLastChild(), null, state);
						}
						decomposeSubExpressions(left.getFirstChild(), null, state);
					}
				}
			} else if (parentType == Token.CALL && NodeUtil.isGet(parent.getFirstChild())) {
				Node functionExpression = parent.getFirstChild();
				decomposeSubExpressions(functionExpression.getNext(), child, state);
			} else if (parentType == Token.OBJECTLIT) {
				decomposeObjectLiteralKeys(parent.getFirstChild(), child, state);
			} else {
				decomposeSubExpressions(parent.getFirstChild(), child, state);
			}
		}

		if (nonconditionalExpr == subExpression) {
		} else {
			Node parent = nonconditionalExpr.getParent();
			boolean needResult = !parent.isExprResult();
			extractConditional(nonconditionalExpr, exprInjectionPoint, needResult);
		}
	}

	NodeMismatch checkTreeEqualsImpl(Node node2) {
		NodeMismatch res = null;

		if (!isEquivalentTo(node2, false, false, false)) {
			return new NodeMismatch(this, node2);
		}
		Node n, n2;
		for (n = first, n2 = node2.first; res == null && n != null; n = n.next, n2 = n2.next) {
			res = n.checkTreeEqualsImpl(n2);
			if (node2 == null) {
				throw new IllegalStateException();
			}
			if (res != null) {
				return null;
			}
		}
		return res;
	}
}