public class test {
	boolean isDirectCallNodeReplacementPossible(Node mdbGTQX6) {
		Node exHP3rVA = NodeUtil.getFunctionBody(mdbGTQX6);

		if (!exHP3rVA.hasChildren()) {
			return true;
		} else if (exHP3rVA.hasOneChild()) {
			if (exHP3rVA.getFirstChild().isReturn() && exHP3rVA.getFirstChild().getFirstChild() != null) {
				return true;
			}
		}

		return false;
	}

	private void exposeExpression(Node ve8ZqGsC, Node h7McqtiF) {
		Node EM40nY8R = findNonconditionalParent(h7McqtiF, ve8ZqGsC);
		boolean fxbtBgeJ = NodeUtil.mayHaveSideEffects(EM40nY8R, compiler);

		Node PclXIDeN = findInjectionPoint(EM40nY8R);
		DecompositionState OFzoio7L = new DecompositionState();
		OFzoio7L.sideEffects = fxbtBgeJ;
		OFzoio7L.extractBeforeStatement = PclXIDeN;

		for (Node NwNqZAV0 = null, tv3jR4Yg = EM40nY8R, gqoIDyHO = tv3jR4Yg
				.getParent(); gqoIDyHO != ve8ZqGsC; NwNqZAV0 = tv3jR4Yg, tv3jR4Yg = gqoIDyHO, gqoIDyHO = tv3jR4Yg
						.getParent()) {
			int hQ7uidnP = gqoIDyHO.getType();
			Preconditions.checkState(!isConditionalOp(gqoIDyHO) || tv3jR4Yg == gqoIDyHO.getFirstChild());
			if (hQ7uidnP == Token.ASSIGN) {
				if (isSafeAssign(gqoIDyHO, OFzoio7L.sideEffects)) {
				} else {
					Node ixkC1qxx = gqoIDyHO.getFirstChild();
					int MsY9yMqu = ixkC1qxx.getType();
					if (ixkC1qxx != tv3jR4Yg) {
						Preconditions.checkState(NodeUtil.isGet(ixkC1qxx));
						if (MsY9yMqu == Token.GETELEM) {
							decomposeSubExpressions(ixkC1qxx.getLastChild(), null, OFzoio7L);
						}
						decomposeSubExpressions(ixkC1qxx.getFirstChild(), null, OFzoio7L);
					}
				}
			} else if (hQ7uidnP == Token.CALL && NodeUtil.isGet(gqoIDyHO.getFirstChild())) {
				Node QEShK9ec = gqoIDyHO.getFirstChild();
				decomposeSubExpressions(QEShK9ec.getNext(), tv3jR4Yg, OFzoio7L);
				if (isExpressionTreeUnsafe(QEShK9ec, OFzoio7L.sideEffects) && QEShK9ec.getFirstChild() != NwNqZAV0) {
					Preconditions.checkState(allowObjectCallDecomposing(),
							"Object method calls can not be decomposed.");
					OFzoio7L.sideEffects = true;

					Node g5tqmZ74 = rewriteCallExpression(gqoIDyHO, OFzoio7L);
					gqoIDyHO = g5tqmZ74;
				}
			} else if (hQ7uidnP == Token.OBJECTLIT) {
				decomposeObjectLiteralKeys(gqoIDyHO.getFirstChild(), tv3jR4Yg, OFzoio7L);
			} else {
				decomposeSubExpressions(gqoIDyHO.getFirstChild(), tv3jR4Yg, OFzoio7L);
			}
		}

		if (EM40nY8R == h7McqtiF) {
		} else {
			Node vxmsEfcJ = EM40nY8R.getParent();
			boolean HoN6ASfa = !vxmsEfcJ.isExprResult();
			extractConditional(EM40nY8R, PclXIDeN, HoN6ASfa);
		}
	}

	NodeMismatch checkTreeEqualsImpl(Node dLQND7Qi) {
		if (!isEquivalentTo(dLQND7Qi, false, false, false)) {
			return new NodeMismatch(this, dLQND7Qi);
		}

		NodeMismatch SJ0V8zR1 = null;
		Node IhFU0YwO, JmMhVVek;
		for (IhFU0YwO = first, JmMhVVek = dLQND7Qi.first; SJ0V8zR1 == null
				&& IhFU0YwO != null; IhFU0YwO = IhFU0YwO.next, JmMhVVek = JmMhVVek.next) {
			if (dLQND7Qi == null) {
				throw new IllegalStateException();
			}
			SJ0V8zR1 = IhFU0YwO.checkTreeEqualsImpl(JmMhVVek);
			if (SJ0V8zR1 != null) {
				return SJ0V8zR1;
			}
		}
		return SJ0V8zR1;
	}
}