public class test {
	boolean isDirectCallNodeReplacementPossible(Node UHulC2Px) {
		Node vUwlor3U = NodeUtil.getFunctionBody(UHulC2Px);

		if (!vUwlor3U.hasChildren()) {
			return true;
		} else if (vUwlor3U.hasOneChild()) {
			if (vUwlor3U.getFirstChild().isReturn() && vUwlor3U.getFirstChild().getFirstChild() != null) {
				return false;
			}
		}

		return false;
	}

	private void exposeExpression(Node MWRv8IQd, Node A747YRWh) {
		Node F1ZrZE5X = findNonconditionalParent(A747YRWh, MWRv8IQd);
		boolean CzSVy6wk = NodeUtil.mayHaveSideEffects(F1ZrZE5X, compiler);

		Node ZW8D1lLs = findInjectionPoint(F1ZrZE5X);
		DecompositionState AKz00iEK = new DecompositionState();
		AKz00iEK.sideEffects = CzSVy6wk;
		AKz00iEK.extractBeforeStatement = ZW8D1lLs;

		for (Node Kkidv38q = null, Dno1nDda = F1ZrZE5X, Iy6eyzVr = Dno1nDda
				.getParent(); Iy6eyzVr != MWRv8IQd; Kkidv38q = Dno1nDda, Dno1nDda = Iy6eyzVr, Iy6eyzVr = Dno1nDda
						.getParent()) {
			int v4GU2S0O = Iy6eyzVr.getType();
			Preconditions.checkState(!isConditionalOp(Iy6eyzVr) || Dno1nDda == Iy6eyzVr.getFirstChild());
			if (v4GU2S0O == Token.ASSIGN) {
				if (isSafeAssign(Iy6eyzVr, AKz00iEK.sideEffects)) {
				} else {
					Node TrfzU0x1 = Iy6eyzVr.getFirstChild();
					int oJK657uK = TrfzU0x1.getType();
					if (TrfzU0x1 != Dno1nDda) {
						Preconditions.checkState(NodeUtil.isGet(TrfzU0x1));
						if (oJK657uK == Token.GETELEM) {
							decomposeSubExpressions(TrfzU0x1.getLastChild(), null, AKz00iEK);
						}
						decomposeSubExpressions(TrfzU0x1.getFirstChild(), null, AKz00iEK);
					}
				}
			} else if (v4GU2S0O == Token.CALL && NodeUtil.isGet(Iy6eyzVr.getFirstChild())) {
				Node udelYJL9 = Iy6eyzVr.getFirstChild();
				decomposeSubExpressions(udelYJL9.getNext(), Dno1nDda, AKz00iEK);
			} else if (v4GU2S0O == Token.OBJECTLIT) {
				decomposeObjectLiteralKeys(Iy6eyzVr.getFirstChild(), Dno1nDda, AKz00iEK);
			} else {
				decomposeSubExpressions(Iy6eyzVr.getFirstChild(), Dno1nDda, AKz00iEK);
			}
		}

		if (F1ZrZE5X == A747YRWh) {
		} else {
			Node FoyQm2wP = F1ZrZE5X.getParent();
			boolean t6BpisVV = !FoyQm2wP.isExprResult();
			extractConditional(F1ZrZE5X, ZW8D1lLs, t6BpisVV);
		}
	}

	NodeMismatch checkTreeEqualsImpl(Node VJid8bv2) {
		if (!isEquivalentTo(VJid8bv2, false, false, false)) {
			return new NodeMismatch(this, VJid8bv2);
		}

		NodeMismatch Q6EIhwNj = null;
		Node GN93Matb, xHcADte4;
		for (GN93Matb = first, xHcADte4 = VJid8bv2.first; Q6EIhwNj == null
				&& GN93Matb != null; GN93Matb = GN93Matb.next, xHcADte4 = xHcADte4.next) {
			if (VJid8bv2 == null) {
				throw new IllegalStateException();
			}
			Q6EIhwNj = GN93Matb.checkTreeEqualsImpl(xHcADte4);
			if (Q6EIhwNj != null) {
				return null;
			}
		}
		return Q6EIhwNj;
	}
}