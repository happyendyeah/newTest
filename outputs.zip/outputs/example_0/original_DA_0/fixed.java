public class test {
	protected Size2D arrangeFN(BlockContainer qOJQuE3X, Graphics2D oK8iuGmg, double pft2n0V9) {
		double[] NWlPNeel = new double[5];
		double[] lnY9URFy = new double[5];
		RectangleConstraint OxO6lt9A = new RectangleConstraint(pft2n0V9, null, LengthConstraintType.FIXED, 0.0, null,
				LengthConstraintType.NONE);
		if (this.topBlock != null) {
			Size2D lmwjlzAP = this.topBlock.arrange(oK8iuGmg, OxO6lt9A);
			NWlPNeel[0] = lmwjlzAP.width;
			lnY9URFy[0] = lmwjlzAP.height;
		}
		if (this.bottomBlock != null) {
			Size2D WVvTWDIN = this.bottomBlock.arrange(oK8iuGmg, OxO6lt9A);
			NWlPNeel[1] = WVvTWDIN.width;
			lnY9URFy[1] = WVvTWDIN.height;
		}
		RectangleConstraint CEoPzDs3 = new RectangleConstraint(0.0, new Range(0.0, pft2n0V9),
				LengthConstraintType.RANGE, 0.0, null, LengthConstraintType.NONE);
		if (this.leftBlock != null) {
			Size2D I2jghda5 = this.leftBlock.arrange(oK8iuGmg, CEoPzDs3);
			NWlPNeel[2] = I2jghda5.width;
			lnY9URFy[2] = I2jghda5.height;
		}
		if (this.rightBlock != null) {
			double v5xDDHPM = Math.max(pft2n0V9 - NWlPNeel[2], 0.0);
			RectangleConstraint QOVsJccq = new RectangleConstraint(0.0,
					new Range(Math.min(NWlPNeel[2], v5xDDHPM), v5xDDHPM), LengthConstraintType.RANGE, 0.0, null,
					LengthConstraintType.NONE);
			Size2D kMulWq0P = this.rightBlock.arrange(oK8iuGmg, QOVsJccq);
			NWlPNeel[3] = kMulWq0P.width;
			lnY9URFy[3] = kMulWq0P.height;
		}

		lnY9URFy[2] = Math.max(lnY9URFy[2], lnY9URFy[3]);
		lnY9URFy[3] = lnY9URFy[2];

		if (this.centerBlock != null) {
			RectangleConstraint oSclONQe = new RectangleConstraint(pft2n0V9 - NWlPNeel[2] - NWlPNeel[3], null,
					LengthConstraintType.FIXED, 0.0, null, LengthConstraintType.NONE);
			Size2D WNtRkAYn = this.centerBlock.arrange(oK8iuGmg, oSclONQe);
			NWlPNeel[4] = WNtRkAYn.width;
			lnY9URFy[4] = WNtRkAYn.height;
		}
		this.rightBlock = null;
		double vYssokPi = lnY9URFy[0] + lnY9URFy[1] + Math.max(lnY9URFy[2], Math.max(lnY9URFy[3], lnY9URFy[4]));
		return arrange(qOJQuE3X, oK8iuGmg, new RectangleConstraint(pft2n0V9, vYssokPi));
	}
}