public class test {
	protected Size2D arrangeFN(BlockContainer fNkGiTZ0, Graphics2D ClQhV6aH, double QNcd5wIY) {
		double[] S1Xm4oKn = new double[5];
		double[] cCPQMOxN = new double[5];
		RectangleConstraint ztqTYWKF = new RectangleConstraint(QNcd5wIY, null, LengthConstraintType.FIXED, 0.0, null,
				LengthConstraintType.NONE);
		if (this.topBlock != null) {
			Size2D l947FHDO = this.topBlock.arrange(ClQhV6aH, ztqTYWKF);
			S1Xm4oKn[0] = l947FHDO.width;
			cCPQMOxN[0] = l947FHDO.height;
		}
		if (this.bottomBlock != null) {
			Size2D pbvhfFUv = this.bottomBlock.arrange(ClQhV6aH, ztqTYWKF);
			S1Xm4oKn[1] = pbvhfFUv.width;
			cCPQMOxN[1] = pbvhfFUv.height;
		}
		RectangleConstraint s0EarJ7w = new RectangleConstraint(0.0, new Range(0.0, QNcd5wIY),
				LengthConstraintType.RANGE, 0.0, null, LengthConstraintType.NONE);
		if (this.leftBlock != null) {
			Size2D KThSKgIO = this.leftBlock.arrange(ClQhV6aH, s0EarJ7w);
			S1Xm4oKn[2] = KThSKgIO.width;
			cCPQMOxN[2] = KThSKgIO.height;
		}
		if (this.rightBlock != null) {
			double qJp4lnKP = Math.max(QNcd5wIY - S1Xm4oKn[2], 0.0);
			RectangleConstraint YcJz8nCO = new RectangleConstraint(0.0,
					new Range(Math.min(S1Xm4oKn[2], qJp4lnKP), qJp4lnKP), LengthConstraintType.RANGE, 0.0, null,
					LengthConstraintType.NONE);
			Size2D QcyHhZ46 = this.rightBlock.arrange(ClQhV6aH, YcJz8nCO);
			S1Xm4oKn[3] = QcyHhZ46.width;
			cCPQMOxN[3] = QcyHhZ46.height;
		}

		cCPQMOxN[2] = Math.max(cCPQMOxN[2], cCPQMOxN[3]);
		cCPQMOxN[3] = cCPQMOxN[2];

		if (this.centerBlock != null) {
			RectangleConstraint aC9OjWTR = new RectangleConstraint(QNcd5wIY - S1Xm4oKn[2] - S1Xm4oKn[3], null,
					LengthConstraintType.FIXED, 0.0, null, LengthConstraintType.NONE);
			Size2D dAeyQuf6 = this.centerBlock.arrange(ClQhV6aH, aC9OjWTR);
			S1Xm4oKn[4] = dAeyQuf6.width;
			cCPQMOxN[4] = dAeyQuf6.height;
		}
		double Uxc9AtjB = cCPQMOxN[0] + cCPQMOxN[1] + Math.max(cCPQMOxN[2], Math.max(cCPQMOxN[3], cCPQMOxN[4]));
		return arrange(fNkGiTZ0, ClQhV6aH, new RectangleConstraint(QNcd5wIY, Uxc9AtjB));
	}
}