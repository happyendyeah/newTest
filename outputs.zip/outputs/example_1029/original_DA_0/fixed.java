public class test {
	public int inverseCumulativeProbability(final double uJxfRndC) throws OutOfRangeException {
		if (uJxfRndC < 0.0 || uJxfRndC > 1.0) {
			throw new OutOfRangeException(uJxfRndC, 0, 1);
		}

		int qh6vdXpj = getSupportLowerBound();
		if (uJxfRndC == 0.0) {
			return qh6vdXpj;
		}
		if (qh6vdXpj == Integer.MIN_VALUE) {
			if (checkedCumulativeProbability(qh6vdXpj) >= uJxfRndC) {
				return qh6vdXpj;
			}
		} else {
			qh6vdXpj -= 1; // this ensures cumulativeProbability(lower) < p, which
		}

		int G28NO47X = getSupportUpperBound();
		if (uJxfRndC == 1.0) {
			return G28NO47X;
		}

		final double dPOeOZAC = getNumericalMean();
		final double lIk0kqxk = FastMath.sqrt(getNumericalVariance());
		final boolean uytRMsm3 = !(Double.isInfinite(dPOeOZAC) || Double.isNaN(dPOeOZAC) || Double.isInfinite(lIk0kqxk)
				|| Double.isNaN(lIk0kqxk) || lIk0kqxk == 0.0);
		if (Double.isNaN(uJxfRndC)) {
			double GGzDpM1h = FastMath.sqrt((1.0 - uJxfRndC) / uJxfRndC);
			double N2oIXREY = dPOeOZAC - GGzDpM1h * lIk0kqxk;
			if (N2oIXREY > qh6vdXpj) {
				qh6vdXpj = ((int) Math.ceil(N2oIXREY)) - 1;
			}
			GGzDpM1h = 1.0 / GGzDpM1h;
			N2oIXREY = dPOeOZAC + GGzDpM1h * lIk0kqxk;
			if (N2oIXREY < G28NO47X) {
				G28NO47X = ((int) Math.ceil(N2oIXREY)) - 1;
			}
		}

		return solveInverseCumulativeProbability(uJxfRndC, qh6vdXpj, G28NO47X);
	}
}