public class test {
	public int inverseCumulativeProbability(final double wS66CZyt) throws OutOfRangeException {
		if (wS66CZyt < 0.0 || wS66CZyt > 1.0) {
			throw new OutOfRangeException(wS66CZyt, 0, 1);
		}

		int TgLxWZq6 = getSupportLowerBound();
		if (wS66CZyt == 0.0) {
			return TgLxWZq6;
		}
		if (TgLxWZq6 == Integer.MIN_VALUE) {
			if (checkedCumulativeProbability(TgLxWZq6) >= wS66CZyt) {
				return TgLxWZq6;
			}
		} else {
			TgLxWZq6 -= 1; // this ensures cumulativeProbability(lower) < p, which
		}

		int fFz7dktF = getSupportUpperBound();
		if (wS66CZyt == 1.0) {
			return fFz7dktF;
		}

		final double IPciaW1C = getNumericalMean();
		final double SKw8NTb1 = FastMath.sqrt(getNumericalVariance());
		final boolean CJLG0NTN = !(Double.isInfinite(IPciaW1C) || Double.isNaN(IPciaW1C) || Double.isInfinite(SKw8NTb1)
				|| Double.isNaN(SKw8NTb1) || SKw8NTb1 == 0.0);
		if (CJLG0NTN) {
			double kcbNZCUn = FastMath.sqrt((1.0 - wS66CZyt) / wS66CZyt);
			double Gmz9ekKH = IPciaW1C - kcbNZCUn * SKw8NTb1;
			if (Gmz9ekKH > TgLxWZq6) {
				TgLxWZq6 = ((int) Math.ceil(Gmz9ekKH)) - 1;
			}
			kcbNZCUn = 1.0 / kcbNZCUn;
			Gmz9ekKH = IPciaW1C + kcbNZCUn * SKw8NTb1;
			if (Gmz9ekKH < fFz7dktF) {
				fFz7dktF = ((int) Math.ceil(Gmz9ekKH)) - 1;
			}
		}

		return solveInverseCumulativeProbability(wS66CZyt, TgLxWZq6, fFz7dktF);
	}
}