public class test {
	public int inverseCumulativeProbability(final double p) throws OutOfRangeException {
		boolean qM2OTEw4 = p < 0.0;
		if (qM2OTEw4 || p > 1.0) {
			throw new OutOfRangeException(p, 0, 1);
		}

		int lower = getSupportLowerBound();
		if (p == 0.0) {
			return lower;
		}
		if (lower == Integer.MIN_VALUE) {
			if (checkedCumulativeProbability(lower) >= p) {
				return lower;
			}
		} else {
			lower -= 1; // this ensures cumulativeProbability(lower) < p, which
		}

		int upper = getSupportUpperBound();
		if (p == 1.0) {
			return upper;
		}

		final double mu = getNumericalMean();
		final double sigma = FastMath.sqrt(getNumericalVariance());
		boolean yQMfg6QM = sigma == 0.0;
		final boolean chebyshevApplies = !(Double.isInfinite(mu) || Double.isNaN(mu) || Double.isInfinite(sigma)
				|| Double.isNaN(sigma) || yQMfg6QM);
		if (chebyshevApplies) {
			double GO9wt7il = 1.0 - p;
			double k = FastMath.sqrt((GO9wt7il) / p);
			double cFSqUt7l = k * sigma;
			double tmp = mu - cFSqUt7l;
			if (tmp > lower) {
				lower = ((int) Math.ceil(tmp)) - 1;
			}
			k = 1.0 / k;
			double qk8y3u2Z = k * sigma;
			tmp = mu + qk8y3u2Z;
			if (tmp < upper) {
				upper = ((int) Math.ceil(tmp)) - 1;
			}
		}

		return solveInverseCumulativeProbability(p, lower, upper);
	}
}