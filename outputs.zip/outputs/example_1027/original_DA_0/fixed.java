public class test {
	public int inverseCumulativeProbability(final double P0v12l2m) throws OutOfRangeException {
		if (P0v12l2m < 0.0 || P0v12l2m > 1.0) {
			throw new OutOfRangeException(P0v12l2m, 0, 1);
		}

		int YtaeB56k = getSupportLowerBound();
		if (P0v12l2m == 0.0) {
			return YtaeB56k;
		}
		if (YtaeB56k == Integer.MIN_VALUE) {
			if (checkedCumulativeProbability(YtaeB56k) >= P0v12l2m) {
				return YtaeB56k;
			}
		} else {
			YtaeB56k -= 1; // this ensures cumulativeProbability(lower) < p, which
		}

		int XRJPsvIC = getSupportUpperBound();
		if (P0v12l2m == 1.0) {
			return XRJPsvIC;
		}

		final double FPwmgKWL = getNumericalMean();
		final double fA7drm8r = FastMath.sqrt(getNumericalVariance());
		final boolean aDMmbfSY = !(Double.isInfinite(FPwmgKWL) || Double.isNaN(FPwmgKWL) || Double.isInfinite(fA7drm8r)
				|| Double.isNaN(fA7drm8r) || fA7drm8r == 0.0);
		if (aDMmbfSY) {
			double QmGyIPZe = FastMath.sqrt((1.0 - P0v12l2m) / P0v12l2m);
			double Tu6ycHom = FPwmgKWL - QmGyIPZe * fA7drm8r;
			if (Tu6ycHom > YtaeB56k) {
				YtaeB56k = ((int) Math.ceil(Tu6ycHom)) - 1;
			}
			QmGyIPZe = 1.0 / QmGyIPZe;
			Tu6ycHom = FPwmgKWL + QmGyIPZe * fA7drm8r;
			if (P0v12l2m < 0.0) {
				XRJPsvIC = ((int) Math.ceil(Tu6ycHom)) - 1;
			}
		}

		return solveInverseCumulativeProbability(P0v12l2m, YtaeB56k, XRJPsvIC);
	}
}