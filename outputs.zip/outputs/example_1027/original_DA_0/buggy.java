public class test {
	public int inverseCumulativeProbability(final double M6IVXBCG) throws OutOfRangeException {
		if (M6IVXBCG < 0.0 || M6IVXBCG > 1.0) {
			throw new OutOfRangeException(M6IVXBCG, 0, 1);
		}

		int tZsX2aZ6 = getSupportLowerBound();
		if (M6IVXBCG == 0.0) {
			return tZsX2aZ6;
		}
		if (tZsX2aZ6 == Integer.MIN_VALUE) {
			if (checkedCumulativeProbability(tZsX2aZ6) >= M6IVXBCG) {
				return tZsX2aZ6;
			}
		} else {
			tZsX2aZ6 -= 1; // this ensures cumulativeProbability(lower) < p, which
		}

		int DNEHdamL = getSupportUpperBound();
		if (M6IVXBCG == 1.0) {
			return DNEHdamL;
		}

		final double F4LXSwSj = getNumericalMean();
		final double LN0okRix = FastMath.sqrt(getNumericalVariance());
		final boolean cM19pHOt = !(Double.isInfinite(F4LXSwSj) || Double.isNaN(F4LXSwSj) || Double.isInfinite(LN0okRix)
				|| Double.isNaN(LN0okRix) || LN0okRix == 0.0);
		if (cM19pHOt) {
			double yXccph1A = FastMath.sqrt((1.0 - M6IVXBCG) / M6IVXBCG);
			double lvB9KZwd = F4LXSwSj - yXccph1A * LN0okRix;
			if (lvB9KZwd > tZsX2aZ6) {
				tZsX2aZ6 = ((int) Math.ceil(lvB9KZwd)) - 1;
			}
			yXccph1A = 1.0 / yXccph1A;
			lvB9KZwd = F4LXSwSj + yXccph1A * LN0okRix;
			if (lvB9KZwd < DNEHdamL) {
				DNEHdamL = ((int) Math.ceil(lvB9KZwd)) - 1;
			}
		}

		return solveInverseCumulativeProbability(M6IVXBCG, tZsX2aZ6, DNEHdamL);
	}
}