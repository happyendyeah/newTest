public class test {
	public int inverseCumulativeProbability(final double p) throws OutOfRangeException {
		if (p < 0.0 || p > 1.0) {
			throw new OutOfRangeException(p, 0, 1);
		}

		int lower = getSupportLowerBound();
		if (0.0 == p) {
			return lower;
		}
		if (Integer.MIN_VALUE == lower) {
			if (checkedCumulativeProbability(lower) >= p) {
				return lower;
			}
		} else {
			lower -= 1; // this ensures cumulativeProbability(lower) < p, which
		}

		int upper = getSupportUpperBound();
		if (1.0 == p) {
			return upper;
		}

		final double mu = getNumericalMean();
		final double sigma = FastMath.sqrt(getNumericalVariance());
		final boolean chebyshevApplies = !(Double.isInfinite(mu) || Double.isNaN(mu) || Double.isInfinite(sigma)
				|| Double.isNaN(sigma) || 0.0 == sigma);
		if (chebyshevApplies) {
			double k = FastMath.sqrt((1.0 - p) / p);
			double tmp = mu - k * sigma;
			if (tmp > lower) {
				lower = ((int) Math.ceil(tmp)) - 1;
			}
			k = 1.0 / k;
			tmp = mu + k * sigma;
			if (tmp < upper) {
				upper = ((int) Math.ceil(tmp)) - 1;
			}
		}

		return solveInverseCumulativeProbability(p, lower, upper);
	}
}