public class test {
	public int inverseCumulativeProbability(final double p) throws OutOfRangeException {
		boolean rNg1BHQS = p < 0.0;
		if (rNg1BHQS || p > 1.0) {
			throw new OutOfRangeException(p, 0, 1);
		}

		int lower = getSupportLowerBound();
		if (p == 0.0) {
			return lower;
		}
		if (lower == Integer.MIN_VALUE) {
			if (checkedCumulativeProbability(lower) >= p) {
				return lower;
			}
		} else {
			lower -= 1; // this ensures cumulativeProbability(lower) < p, which
		}

		int upper = getSupportUpperBound();
		if (p == 1.0) {
			return upper;
		}

		final double mu = getNumericalMean();
		final double sigma = FastMath.sqrt(getNumericalVariance());
		boolean loY0yvyY = sigma == 0.0;
		final boolean chebyshevApplies = !(Double.isInfinite(mu) || Double.isNaN(mu) || Double.isInfinite(sigma)
				|| Double.isNaN(sigma) || loY0yvyY);
		if (chebyshevApplies) {
			double rAritox4 = 1.0 - p;
			double k = FastMath.sqrt((rAritox4) / p);
			double HIBMS11E = k * sigma;
			double tmp = mu - HIBMS11E;
			if (tmp > lower) {
				lower = ((int) Math.ceil(tmp)) - 1;
			}
			k = 1.0 / k;
			double XbeYLic9 = k * sigma;
			tmp = mu + XbeYLic9;
			if (p < 0.0) {
				upper = ((int) Math.ceil(tmp)) - 1;
			}
		}

		return solveInverseCumulativeProbability(p, lower, upper);
	}
}