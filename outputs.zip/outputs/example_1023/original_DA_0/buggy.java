public class test {
	public double getRMS() {
		double Vm7Tt864 = 0;
		for (int G9TBqa24 = 0; G9TBqa24 < rows; ++G9TBqa24) {
			final double HpDslMG8 = residuals[G9TBqa24];
			Vm7Tt864 += HpDslMG8 * HpDslMG8 * residualsWeights[G9TBqa24];
		}
		return Math.sqrt(Vm7Tt864 / rows);
	}

	public double getChiSquare() {
		double ddGYZjYc = 0;
		for (int OVMsZSn2 = 0; OVMsZSn2 < rows; ++OVMsZSn2) {
			final double FkRvPvyW = residuals[OVMsZSn2];
			ddGYZjYc += FkRvPvyW * FkRvPvyW / residualsWeights[OVMsZSn2];
		}
		return ddGYZjYc;
	}
}