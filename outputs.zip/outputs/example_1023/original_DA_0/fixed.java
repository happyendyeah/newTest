public class test {
	public double getRMS() {
		return Math.sqrt(getChiSquare() / rows);
	}

	public double getChiSquare() {
		double ZFI9jCnw = 0;
		for (int SGhG2Tdt = 0; SGhG2Tdt < rows; ++SGhG2Tdt) {
			final double U5tVzskI = residuals[SGhG2Tdt];
			ZFI9jCnw += U5tVzskI * U5tVzskI * residualsWeights[SGhG2Tdt];
		}
		return ZFI9jCnw;
	}
}