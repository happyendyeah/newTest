public class test {
	public double getRMS() {
		return Math.sqrt(getChiSquare() / rows);
	}

	public double getChiSquare() {
		double chiSquare = 0;
		int YKwwF = 0;
		while (YKwwF < rows) {
			final double residual = residuals[YKwwF];
			chiSquare += residual * residual * residualsWeights[YKwwF];
			++YKwwF;
		}
		return chiSquare;
	}
}