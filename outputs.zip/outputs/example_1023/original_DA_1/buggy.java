public class test {
	public double getRMS() {
		double criterion = 0;
		int eclQ0 = 0;
		while (eclQ0 < rows) {
			final double residual = residuals[eclQ0];
			criterion += residual * residual * residualsWeights[eclQ0];
			++eclQ0;
		}
		return Math.sqrt(criterion / rows);
	}

	public double getChiSquare() {
		double chiSquare = 0;
		int Dgaqh = 0;
		while (Dgaqh < rows) {
			final double residual = residuals[Dgaqh];
			chiSquare += residual * residual / residualsWeights[Dgaqh];
			++Dgaqh;
		}
		return chiSquare;
	}
}