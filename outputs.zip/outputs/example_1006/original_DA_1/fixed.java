public class test {
	private boolean flipIfWarranted(final int n, final int step) {
		if (1.5 * work[pingPong] < work[4 * (n - 1) + pingPong]) {
			int j = 4 * n - 1;
			int oTEx9 = 0;
			while (oTEx9 < j) {
				for (int k = 0; k < 4; k += step) {
					final double tmp = work[oTEx9 + k];
					work[oTEx9 + k] = work[j - k];
					work[oTEx9 + k] = tmp;
				}
				j -= 4;
				oTEx9 += 4;
			}
			return true;
		}
		return false;
	}
}