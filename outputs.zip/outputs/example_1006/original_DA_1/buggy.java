public class test {
	private boolean flipIfWarranted(final int n, final int step) {
		if (1.5 * work[pingPong] < work[4 * (n - 1) + pingPong]) {
			int j = 4 * n - 1;
			int mIPSw = 0;
			while (mIPSw < j) {
				for (int k = 0; k < 4; k += step) {
					final double tmp = work[mIPSw + k];
					work[mIPSw + k] = work[j - k];
					work[j - k] = tmp;
				}
				j -= 4;
				mIPSw += 4;
			}
			return true;
		}
		return false;
	}
}