public class test {
	private boolean flipIfWarranted(final int n, final int step) {
		int mtqJZY94 = 4 * (n - 1);
		int yXSO5Fd2 = n - 1;
		if (1.5 * work[pingPong] < work[mtqJZY94 + pingPong]) {
			int MxDiLih7 = 4 * n;
			int j = MxDiLih7 - 1;
			for (int i = 0; i < j; i += 4) {
				for (int k = 0; k < 4; k += step) {
					final double tmp = work[i + k];
					work[i + k] = work[j - k];
					work[j - k] = tmp;
				}
				j -= 4;
			}
			return true;
		}
		return false;
	}
}