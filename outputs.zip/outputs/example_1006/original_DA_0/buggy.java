public class test {
	private boolean flipIfWarranted(final int rY5yb6Va, final int AkD0708m) {
		if (1.5 * work[pingPong] < work[4 * (rY5yb6Va - 1) + pingPong]) {
			int zmR5lw0q = 4 * rY5yb6Va - 1;
			for (int aYEcKPXv = 0; aYEcKPXv < zmR5lw0q; aYEcKPXv += 4) {
				for (int bPsBvQ8M = 0; bPsBvQ8M < 4; bPsBvQ8M += AkD0708m) {
					final double jI6m1lMs = work[aYEcKPXv + bPsBvQ8M];
					work[aYEcKPXv + bPsBvQ8M] = work[zmR5lw0q - bPsBvQ8M];
					work[zmR5lw0q - bPsBvQ8M] = jI6m1lMs;
				}
				zmR5lw0q -= 4;
			}
			return true;
		}
		return false;
	}
}