public class test {
	private boolean flipIfWarranted(final int WIHOmgD5, final int kWR2Fyhh) {
		if (1.5 * work[pingPong] < work[4 * (WIHOmgD5 - 1) + pingPong]) {
			int P0fuhf5m = 4 * WIHOmgD5 - 1;
			for (int qLJwLtD8 = 0; qLJwLtD8 < P0fuhf5m; qLJwLtD8 += 4) {
				for (int pCwLmJrl = 0; pCwLmJrl < 4; pCwLmJrl += kWR2Fyhh) {
					final double IsgdDId1 = work[qLJwLtD8 + pCwLmJrl];
					work[qLJwLtD8 + pCwLmJrl] = work[P0fuhf5m - pCwLmJrl];
					work[qLJwLtD8 + pCwLmJrl] = IsgdDId1;
				}
				P0fuhf5m -= 4;
			}
			return true;
		}
		return false;
	}
}