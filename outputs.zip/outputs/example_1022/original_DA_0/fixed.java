public class test {
	public void draw(Graphics2D UbEL4918, Rectangle2D G4HGl5IG, Point2D quoQe87m, PlotState AnoN9o5r,
			PlotRenderingInfo GvQtlScp) {

		RectangleInsets HUXD4vvq = getInsets();
		HUXD4vvq.trim(G4HGl5IG);

		Rectangle2D eRyc66T4 = (Rectangle2D) G4HGl5IG.clone();
		if (GvQtlScp != null) {
			GvQtlScp.setPlotArea(G4HGl5IG);
			GvQtlScp.setDataArea(G4HGl5IG);
		}

		drawBackground(UbEL4918, G4HGl5IG);

		Shape J823fc9H = UbEL4918.getClip();
		UbEL4918.clip(G4HGl5IG);

		double doEyqkTs = getInteriorGap();

		if (DatasetUtilities.isEmptyOrNull(getDataset())) {
			drawNoDataMessage(UbEL4918, G4HGl5IG);
			UbEL4918.setClip(J823fc9H);
			drawOutline(UbEL4918, G4HGl5IG);
			return;
		}

		double iOzbcGwL = 0.0;
		if (getLabelGenerator() != null) {
			iOzbcGwL = getLabelGap() + getMaximumLabelWidth();
		}
		double H8C2PFZC = G4HGl5IG.getWidth() * (doEyqkTs + iOzbcGwL) * 2.0;
		double Ub2wb6B5 = G4HGl5IG.getHeight() * doEyqkTs * 2.0;

		if (DEBUG_DRAW_INTERIOR) {
			double hsHRgNAy = G4HGl5IG.getWidth() * getInteriorGap();
			double FDS8XYIT = G4HGl5IG.getHeight() * getInteriorGap();
			double aTruvbaa = G4HGl5IG.getX() + hsHRgNAy;
			double i5TZ9Lq6 = G4HGl5IG.getMaxX() - hsHRgNAy;
			double fL782wUf = G4HGl5IG.getY() + FDS8XYIT;
			double JcnzL9E0 = G4HGl5IG.getMaxY() - FDS8XYIT;
			UbEL4918.setPaint(Color.lightGray);
			UbEL4918.draw(new Rectangle2D.Double(aTruvbaa, fL782wUf, i5TZ9Lq6 - aTruvbaa, JcnzL9E0 - fL782wUf));
		}

		double LrBOvuWT = G4HGl5IG.getX() + H8C2PFZC / 2;
		double VLMb0Ebg = G4HGl5IG.getY() + Ub2wb6B5 / 2;
		double n2i2K2WV = G4HGl5IG.getWidth() - H8C2PFZC;
		double UYam6Edz = G4HGl5IG.getHeight() - Ub2wb6B5;

		if (isCircular()) { // is circular?
			double LEGgev5t = Math.min(n2i2K2WV, UYam6Edz) / 2;
			LrBOvuWT = (LrBOvuWT + LrBOvuWT + n2i2K2WV) / 2 - LEGgev5t;
			VLMb0Ebg = (VLMb0Ebg + VLMb0Ebg + UYam6Edz) / 2 - LEGgev5t;
			n2i2K2WV = 2 * LEGgev5t;
			UYam6Edz = 2 * LEGgev5t;
		}

		PiePlotState hXjT4mYT = initialise(UbEL4918, G4HGl5IG, this, null, GvQtlScp);

		Rectangle2D vE35AQWQ = new Rectangle2D.Double(LrBOvuWT, VLMb0Ebg, n2i2K2WV, UYam6Edz * (1 - this.depthFactor));
		hXjT4mYT.setLinkArea(vE35AQWQ);

		if (DEBUG_DRAW_LINK_AREA) {
			UbEL4918.setPaint(Color.blue);
			UbEL4918.draw(vE35AQWQ);
			UbEL4918.setPaint(Color.yellow);
			UbEL4918.draw(
					new Ellipse2D.Double(vE35AQWQ.getX(), vE35AQWQ.getY(), vE35AQWQ.getWidth(), vE35AQWQ.getHeight()));
		}

		double FkBApcd0 = n2i2K2WV * getLabelLinkMargin();
		double dOJV088a = UYam6Edz * getLabelLinkMargin();
		Rectangle2D xd7uNYnU = new Rectangle2D.Double(LrBOvuWT + FkBApcd0 / 2.0, VLMb0Ebg + dOJV088a / 2.0,
				n2i2K2WV - FkBApcd0, UYam6Edz - dOJV088a);

		hXjT4mYT.setExplodedPieArea(xd7uNYnU);

		double Y1r2UC4D = getMaximumExplodePercent();
		double IYdqB3Fw = Y1r2UC4D / (1.0 + Y1r2UC4D);

		double rL0uon84 = xd7uNYnU.getWidth() * IYdqB3Fw;
		double NWxYLbJr = xd7uNYnU.getHeight() * IYdqB3Fw;
		Rectangle2D WLYRaA9D = new Rectangle2D.Double(xd7uNYnU.getX() + rL0uon84 / 2.0,
				xd7uNYnU.getY() + NWxYLbJr / 2.0, xd7uNYnU.getWidth() - rL0uon84, xd7uNYnU.getHeight() - NWxYLbJr);

		int Y6aZOfGY = (int) (WLYRaA9D.getHeight() * this.depthFactor);
		Rectangle2D U9KbIbgv = new Rectangle2D.Double(LrBOvuWT, VLMb0Ebg, n2i2K2WV, UYam6Edz - Y6aZOfGY);
		hXjT4mYT.setLinkArea(U9KbIbgv);

		hXjT4mYT.setPieArea(WLYRaA9D);
		hXjT4mYT.setPieCenterX(WLYRaA9D.getCenterX());
		hXjT4mYT.setPieCenterY(WLYRaA9D.getCenterY() - Y6aZOfGY / 2.0);
		hXjT4mYT.setPieWRadius(WLYRaA9D.getWidth() / 2.0);
		hXjT4mYT.setPieHRadius((WLYRaA9D.getHeight() - Y6aZOfGY) / 2.0);

		PieDataset lmD83Es0 = getDataset();
		if (DatasetUtilities.isEmptyOrNull(getDataset())) {
			drawNoDataMessage(UbEL4918, G4HGl5IG);
			UbEL4918.setClip(J823fc9H);
			drawOutline(UbEL4918, G4HGl5IG);
			return;
		}

		if (lmD83Es0.getKeys().size() > G4HGl5IG.getWidth()) {
			String fJk9bnLH = "Too many elements";
			Font ALL0n9Nh = new Font("dialog", Font.BOLD, 10);
			UbEL4918.setFont(ALL0n9Nh);
			FontMetrics XKtPqsVV = UbEL4918.getFontMetrics(ALL0n9Nh);
			int obhxbcdi = XKtPqsVV.stringWidth(fJk9bnLH);

			UbEL4918.drawString(fJk9bnLH, (int) (G4HGl5IG.getX() + (G4HGl5IG.getWidth() - obhxbcdi) / 2),
					(int) (G4HGl5IG.getY() + (G4HGl5IG.getHeight() / 2)));
			return;
		}
		if (isCircular()) {
			double cu6Ly0Pf = Math.min(G4HGl5IG.getWidth(), G4HGl5IG.getHeight()) / 2;
			G4HGl5IG = new Rectangle2D.Double(G4HGl5IG.getCenterX() - cu6Ly0Pf, G4HGl5IG.getCenterY() - cu6Ly0Pf,
					2 * cu6Ly0Pf, 2 * cu6Ly0Pf);
		}
		List cBs75BtG = lmD83Es0.getKeys();

		if (cBs75BtG.size() == 0) {
			return;
		}

		double k4QIPuIc = WLYRaA9D.getX();
		double i3NPoBav = WLYRaA9D.getY();

		Composite WeYG3t43 = UbEL4918.getComposite();
		UbEL4918.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, getForegroundAlpha()));

		double R6z2ts38 = DatasetUtilities.calculatePieDatasetTotal(lmD83Es0);
		double o7vC5isG = 0;
		if (Y6aZOfGY < 0) {
			return; // if depth is negative don't draw anything
		}

		ArrayList ni7WF9s2 = new ArrayList();
		Arc2D.Double wJw9rEjp;
		Paint q89V3cMf;
		Paint JSvc1i3y;
		Stroke pdXxGN0Y;

		Iterator ZcQBgZqY = cBs75BtG.iterator();
		while (ZcQBgZqY.hasNext()) {

			Comparable L5bI3l9X = (Comparable) ZcQBgZqY.next();
			Number LhbhMgCi = lmD83Es0.getValue(L5bI3l9X);
			if (LhbhMgCi == null) {
				ni7WF9s2.add(null);
				continue;
			}
			double XIxTnprt = LhbhMgCi.doubleValue();
			if (XIxTnprt <= 0) {
				ni7WF9s2.add(null);
				continue;
			}
			double l6hfWRRD = getStartAngle();
			double qFt4Dpj5 = getDirection().getFactor();
			double UwnilUL6 = l6hfWRRD + (qFt4Dpj5 * (o7vC5isG * 360)) / R6z2ts38;
			double H9GWa8dQ = l6hfWRRD + (qFt4Dpj5 * (o7vC5isG + XIxTnprt) * 360) / R6z2ts38;
			if (Math.abs(H9GWa8dQ - UwnilUL6) > getMinimumArcAngleToDraw()) {
				ni7WF9s2.add(new Arc2D.Double(k4QIPuIc, i3NPoBav + Y6aZOfGY, WLYRaA9D.getWidth(),
						WLYRaA9D.getHeight() - Y6aZOfGY, UwnilUL6, H9GWa8dQ - UwnilUL6, Arc2D.PIE));
			} else {
				ni7WF9s2.add(null);
			}
			o7vC5isG += XIxTnprt;
		}

		Shape zDWbM7Jh = UbEL4918.getClip();

		Ellipse2D GhPry49T = new Ellipse2D.Double(WLYRaA9D.getX(), WLYRaA9D.getY(), WLYRaA9D.getWidth(),
				WLYRaA9D.getHeight() - Y6aZOfGY);

		Ellipse2D Eh5w0ybc = new Ellipse2D.Double(WLYRaA9D.getX(), WLYRaA9D.getY() + Y6aZOfGY, WLYRaA9D.getWidth(),
				WLYRaA9D.getHeight() - Y6aZOfGY);

		Rectangle2D kNa7XGID = new Rectangle2D.Double(GhPry49T.getX(), GhPry49T.getCenterY(), WLYRaA9D.getWidth(),
				Eh5w0ybc.getMaxY() - GhPry49T.getCenterY());

		Rectangle2D pzh6nPWG = new Rectangle2D.Double(WLYRaA9D.getX(), GhPry49T.getY(), WLYRaA9D.getWidth(),
				Eh5w0ybc.getCenterY() - GhPry49T.getY());

		Area gQcKw4nv = new Area(GhPry49T);
		gQcKw4nv.add(new Area(kNa7XGID));
		Area gJTWgu4J = new Area(Eh5w0ybc);
		gJTWgu4J.add(new Area(pzh6nPWG));
		Area Ome6pdOR = new Area(gQcKw4nv);
		Ome6pdOR.intersect(gJTWgu4J);

		Area dbsVmzDd = new Area(Ome6pdOR);
		dbsVmzDd.subtract(new Area(GhPry49T));

		Area J3SnZCPA = new Area(Ome6pdOR);
		J3SnZCPA.subtract(new Area(Eh5w0ybc));

		int[] Iys9y0Ts;
		int[] zqyCNDur;
		wJw9rEjp = new Arc2D.Double(k4QIPuIc, i3NPoBav + Y6aZOfGY, WLYRaA9D.getWidth(), WLYRaA9D.getHeight() - Y6aZOfGY,
				0, 360, Arc2D.PIE);

		int GAemtJ9X = ni7WF9s2.size();
		for (int bVt1ZE9R = 0; bVt1ZE9R < GAemtJ9X; bVt1ZE9R++) {
			wJw9rEjp = (Arc2D.Double) ni7WF9s2.get(bVt1ZE9R);
			if (wJw9rEjp == null) {
				continue;
			}
			Comparable cyBY8vU8 = getSectionKey(bVt1ZE9R);
			q89V3cMf = lookupSectionPaint(cyBY8vU8, true);
			JSvc1i3y = lookupSectionOutlinePaint(cyBY8vU8);
			pdXxGN0Y = lookupSectionOutlineStroke(cyBY8vU8);
			UbEL4918.setPaint(q89V3cMf);
			UbEL4918.fill(wJw9rEjp);
			UbEL4918.setPaint(JSvc1i3y);
			UbEL4918.setStroke(pdXxGN0Y);
			UbEL4918.draw(wJw9rEjp);
			UbEL4918.setPaint(q89V3cMf);

			Point2D B9yFWnIH = wJw9rEjp.getStartPoint();

			Iys9y0Ts = new int[] { (int) wJw9rEjp.getCenterX(), (int) wJw9rEjp.getCenterX(), (int) B9yFWnIH.getX(),
					(int) B9yFWnIH.getX() };
			zqyCNDur = new int[] { (int) wJw9rEjp.getCenterY(), (int) wJw9rEjp.getCenterY() - Y6aZOfGY,
					(int) B9yFWnIH.getY() - Y6aZOfGY, (int) B9yFWnIH.getY() };
			Polygon bjYBLaeQ = new Polygon(Iys9y0Ts, zqyCNDur, 4);
			UbEL4918.setPaint(java.awt.Color.lightGray);
			UbEL4918.fill(bjYBLaeQ);
			UbEL4918.setPaint(JSvc1i3y);
			UbEL4918.setStroke(pdXxGN0Y);
			UbEL4918.draw(bjYBLaeQ);
			UbEL4918.setPaint(q89V3cMf);

		}

		UbEL4918.setPaint(Color.gray);
		UbEL4918.fill(J3SnZCPA);
		UbEL4918.fill(dbsVmzDd);

		int Yfr3vPvc = 0;
		ZcQBgZqY = ni7WF9s2.iterator();
		while (ZcQBgZqY.hasNext()) {
			Arc2D yEpEVEfk = (Arc2D) ZcQBgZqY.next();
			if (yEpEVEfk != null) {
				Comparable LLiv6GR9 = getSectionKey(Yfr3vPvc);
				q89V3cMf = lookupSectionPaint(LLiv6GR9, true);
				JSvc1i3y = lookupSectionOutlinePaint(LLiv6GR9);
				pdXxGN0Y = lookupSectionOutlineStroke(LLiv6GR9);
				drawSide(UbEL4918, WLYRaA9D, yEpEVEfk, dbsVmzDd, J3SnZCPA, q89V3cMf, JSvc1i3y, pdXxGN0Y, false, true);
			}
			Yfr3vPvc++;
		}

		Yfr3vPvc = 0;
		ZcQBgZqY = ni7WF9s2.iterator();
		while (ZcQBgZqY.hasNext()) {
			Arc2D JBF2YaFM = (Arc2D) ZcQBgZqY.next();
			if (JBF2YaFM != null) {
				Comparable iJnpS1SU = getSectionKey(Yfr3vPvc);
				q89V3cMf = lookupSectionPaint(iJnpS1SU);
				JSvc1i3y = lookupSectionOutlinePaint(iJnpS1SU);
				pdXxGN0Y = lookupSectionOutlineStroke(iJnpS1SU);
				drawSide(UbEL4918, WLYRaA9D, JBF2YaFM, dbsVmzDd, J3SnZCPA, q89V3cMf, JSvc1i3y, pdXxGN0Y, true, false);
			}
			Yfr3vPvc++;
		}

		UbEL4918.setClip(zDWbM7Jh);

		Arc2D kRf4K66N;
		for (int UZgnFCJi = 0; UZgnFCJi < GAemtJ9X; UZgnFCJi++) {
			wJw9rEjp = (Arc2D.Double) ni7WF9s2.get(UZgnFCJi);
			if (wJw9rEjp == null) {
				continue;
			}
			kRf4K66N = new Arc2D.Double(k4QIPuIc, i3NPoBav, WLYRaA9D.getWidth(), WLYRaA9D.getHeight() - Y6aZOfGY,
					wJw9rEjp.getAngleStart(), wJw9rEjp.getAngleExtent(), Arc2D.PIE);

			Comparable M0fLSZ7O = (Comparable) cBs75BtG.get(UZgnFCJi);
			q89V3cMf = lookupSectionPaint(M0fLSZ7O, true);
			JSvc1i3y = lookupSectionOutlinePaint(M0fLSZ7O);
			pdXxGN0Y = lookupSectionOutlineStroke(M0fLSZ7O);
			UbEL4918.setPaint(q89V3cMf);
			UbEL4918.fill(kRf4K66N);
			UbEL4918.setStroke(pdXxGN0Y);
			UbEL4918.setPaint(JSvc1i3y);
			UbEL4918.draw(kRf4K66N);

			if (GvQtlScp != null) {
				EntityCollection dqigP63N = GvQtlScp.getOwner().getEntityCollection();
				if (dqigP63N != null) {
					String z2ZpMlIo = null;
					PieToolTipGenerator ZywBLQzr = getToolTipGenerator();
					if (ZywBLQzr != null) {
						z2ZpMlIo = ZywBLQzr.generateToolTip(lmD83Es0, M0fLSZ7O);
					}
					String i5uBD1Lp = null;
					if (getURLGenerator() != null) {
						i5uBD1Lp = getURLGenerator().generateURL(lmD83Es0, M0fLSZ7O, getPieIndex());
					}
					PieSectionEntity JT9Km3NO = new PieSectionEntity(kRf4K66N, lmD83Es0, getPieIndex(), UZgnFCJi,
							M0fLSZ7O, z2ZpMlIo, i5uBD1Lp);
					dqigP63N.add(JT9Km3NO);
				}
			}
			List cf99bGN5 = lmD83Es0.getKeys();
			Rectangle2D qFCAfxTx = new Rectangle2D.Double(eRyc66T4.getX(), eRyc66T4.getY(), eRyc66T4.getWidth(),
					eRyc66T4.getHeight() - Y6aZOfGY);
			if (getSimpleLabels()) {
				drawSimpleLabels(UbEL4918, cf99bGN5, R6z2ts38, qFCAfxTx, U9KbIbgv, hXjT4mYT);
			} else {
				drawLabels(UbEL4918, cf99bGN5, R6z2ts38, qFCAfxTx, U9KbIbgv, hXjT4mYT);
			}
		}

		UbEL4918.setClip(J823fc9H);
		UbEL4918.setComposite(WeYG3t43);
		drawOutline(UbEL4918, eRyc66T4);

	}
}