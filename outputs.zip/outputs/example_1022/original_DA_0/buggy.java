public class test {
	public void draw(Graphics2D vBoaBBy9, Rectangle2D YDOc204F, Point2D U9iuUjtr, PlotState JlDXu7Rt,
			PlotRenderingInfo nln7S9vy) {

		RectangleInsets x9UgYnpw = getInsets();
		x9UgYnpw.trim(YDOc204F);

		Rectangle2D Z4yMbp57 = (Rectangle2D) YDOc204F.clone();
		if (nln7S9vy != null) {
			nln7S9vy.setPlotArea(YDOc204F);
			nln7S9vy.setDataArea(YDOc204F);
		}

		drawBackground(vBoaBBy9, YDOc204F);

		Shape PqZJdCc6 = vBoaBBy9.getClip();
		vBoaBBy9.clip(YDOc204F);

		double U7UHX7ca = getInteriorGap();
		double iZriBNBO = 0.0;
		if (getLabelGenerator() != null) {
			iZriBNBO = getLabelGap() + getMaximumLabelWidth();
		}
		double qUKkZJGa = YDOc204F.getWidth() * (U7UHX7ca + iZriBNBO) * 2.0;
		double ydG1Yd1n = YDOc204F.getHeight() * U7UHX7ca * 2.0;

		if (DEBUG_DRAW_INTERIOR) {
			double sqNFkNp6 = YDOc204F.getWidth() * getInteriorGap();
			double LrqSJe43 = YDOc204F.getHeight() * getInteriorGap();
			double bN74BOXX = YDOc204F.getX() + sqNFkNp6;
			double J5B71kjL = YDOc204F.getMaxX() - sqNFkNp6;
			double PMPQz11q = YDOc204F.getY() + LrqSJe43;
			double v5TEZBF5 = YDOc204F.getMaxY() - LrqSJe43;
			vBoaBBy9.setPaint(Color.lightGray);
			vBoaBBy9.draw(new Rectangle2D.Double(bN74BOXX, PMPQz11q, J5B71kjL - bN74BOXX, v5TEZBF5 - PMPQz11q));
		}

		double bhYDGa1y = YDOc204F.getX() + qUKkZJGa / 2;
		double FiihNNL4 = YDOc204F.getY() + ydG1Yd1n / 2;
		double mUbviNQO = YDOc204F.getWidth() - qUKkZJGa;
		double M3S5PNo3 = YDOc204F.getHeight() - ydG1Yd1n;

		if (isCircular()) { // is circular?
			double xPbkcyUY = Math.min(mUbviNQO, M3S5PNo3) / 2;
			bhYDGa1y = (bhYDGa1y + bhYDGa1y + mUbviNQO) / 2 - xPbkcyUY;
			FiihNNL4 = (FiihNNL4 + FiihNNL4 + M3S5PNo3) / 2 - xPbkcyUY;
			mUbviNQO = 2 * xPbkcyUY;
			M3S5PNo3 = 2 * xPbkcyUY;
		}

		PiePlotState O8MgrPBG = initialise(vBoaBBy9, YDOc204F, this, null, nln7S9vy);

		Rectangle2D yj7RmqGD = new Rectangle2D.Double(bhYDGa1y, FiihNNL4, mUbviNQO, M3S5PNo3 * (1 - this.depthFactor));
		O8MgrPBG.setLinkArea(yj7RmqGD);

		if (DEBUG_DRAW_LINK_AREA) {
			vBoaBBy9.setPaint(Color.blue);
			vBoaBBy9.draw(yj7RmqGD);
			vBoaBBy9.setPaint(Color.yellow);
			vBoaBBy9.draw(
					new Ellipse2D.Double(yj7RmqGD.getX(), yj7RmqGD.getY(), yj7RmqGD.getWidth(), yj7RmqGD.getHeight()));
		}

		double dEUhnFK0 = mUbviNQO * getLabelLinkMargin();
		double jVCGTBiE = M3S5PNo3 * getLabelLinkMargin();
		Rectangle2D BlqH4JK2 = new Rectangle2D.Double(bhYDGa1y + dEUhnFK0 / 2.0, FiihNNL4 + jVCGTBiE / 2.0,
				mUbviNQO - dEUhnFK0, M3S5PNo3 - jVCGTBiE);

		O8MgrPBG.setExplodedPieArea(BlqH4JK2);

		double Ig7ZE1Oy = getMaximumExplodePercent();
		double edsVgLgg = Ig7ZE1Oy / (1.0 + Ig7ZE1Oy);

		double mdTjEw2G = BlqH4JK2.getWidth() * edsVgLgg;
		double uTQxPMSQ = BlqH4JK2.getHeight() * edsVgLgg;
		Rectangle2D yMY1wZO7 = new Rectangle2D.Double(BlqH4JK2.getX() + mdTjEw2G / 2.0,
				BlqH4JK2.getY() + uTQxPMSQ / 2.0, BlqH4JK2.getWidth() - mdTjEw2G, BlqH4JK2.getHeight() - uTQxPMSQ);

		int VOzc0eJG = (int) (yMY1wZO7.getHeight() * this.depthFactor);
		Rectangle2D xpzbfgZV = new Rectangle2D.Double(bhYDGa1y, FiihNNL4, mUbviNQO, M3S5PNo3 - VOzc0eJG);
		O8MgrPBG.setLinkArea(xpzbfgZV);

		O8MgrPBG.setPieArea(yMY1wZO7);
		O8MgrPBG.setPieCenterX(yMY1wZO7.getCenterX());
		O8MgrPBG.setPieCenterY(yMY1wZO7.getCenterY() - VOzc0eJG / 2.0);
		O8MgrPBG.setPieWRadius(yMY1wZO7.getWidth() / 2.0);
		O8MgrPBG.setPieHRadius((yMY1wZO7.getHeight() - VOzc0eJG) / 2.0);

		PieDataset cujkBZhV = getDataset();
		if (DatasetUtilities.isEmptyOrNull(getDataset())) {
			drawNoDataMessage(vBoaBBy9, YDOc204F);
			vBoaBBy9.setClip(PqZJdCc6);
			drawOutline(vBoaBBy9, YDOc204F);
			return;
		}

		if (cujkBZhV.getKeys().size() > YDOc204F.getWidth()) {
			String I4jwsdjY = "Too many elements";
			Font wARbwuIp = new Font("dialog", Font.BOLD, 10);
			vBoaBBy9.setFont(wARbwuIp);
			FontMetrics NvWrAjHZ = vBoaBBy9.getFontMetrics(wARbwuIp);
			int blAGNcQW = NvWrAjHZ.stringWidth(I4jwsdjY);

			vBoaBBy9.drawString(I4jwsdjY, (int) (YDOc204F.getX() + (YDOc204F.getWidth() - blAGNcQW) / 2),
					(int) (YDOc204F.getY() + (YDOc204F.getHeight() / 2)));
			return;
		}
		if (isCircular()) {
			double hB8ALxnV = Math.min(YDOc204F.getWidth(), YDOc204F.getHeight()) / 2;
			YDOc204F = new Rectangle2D.Double(YDOc204F.getCenterX() - hB8ALxnV, YDOc204F.getCenterY() - hB8ALxnV,
					2 * hB8ALxnV, 2 * hB8ALxnV);
		}
		List c3UW7XhT = cujkBZhV.getKeys();

		if (c3UW7XhT.size() == 0) {
			return;
		}

		double EJi0Hhow = yMY1wZO7.getX();
		double rv3BJdGc = yMY1wZO7.getY();

		Composite bAcRV2RO = vBoaBBy9.getComposite();
		vBoaBBy9.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, getForegroundAlpha()));

		double Q6dUvmcX = DatasetUtilities.calculatePieDatasetTotal(cujkBZhV);
		double HS7Dutgx = 0;
		if (VOzc0eJG < 0) {
			return; // if depth is negative don't draw anything
		}

		ArrayList PtvPscS6 = new ArrayList();
		Arc2D.Double uHmg6dwF;
		Paint Yf1vEMvS;
		Paint gzMJhe1j;
		Stroke ReFnUUPn;

		Iterator paBy67Xn = c3UW7XhT.iterator();
		while (paBy67Xn.hasNext()) {

			Comparable d2CtGgt3 = (Comparable) paBy67Xn.next();
			Number sYkg5pbJ = cujkBZhV.getValue(d2CtGgt3);
			if (sYkg5pbJ == null) {
				PtvPscS6.add(null);
				continue;
			}
			double UEOrJtSf = sYkg5pbJ.doubleValue();
			if (UEOrJtSf <= 0) {
				PtvPscS6.add(null);
				continue;
			}
			double VcX86Csw = getStartAngle();
			double mShRn1P4 = getDirection().getFactor();
			double zKwzgjGz = VcX86Csw + (mShRn1P4 * (HS7Dutgx * 360)) / Q6dUvmcX;
			double NbdO0Tii = VcX86Csw + (mShRn1P4 * (HS7Dutgx + UEOrJtSf) * 360) / Q6dUvmcX;
			if (Math.abs(NbdO0Tii - zKwzgjGz) > getMinimumArcAngleToDraw()) {
				PtvPscS6.add(new Arc2D.Double(EJi0Hhow, rv3BJdGc + VOzc0eJG, yMY1wZO7.getWidth(),
						yMY1wZO7.getHeight() - VOzc0eJG, zKwzgjGz, NbdO0Tii - zKwzgjGz, Arc2D.PIE));
			} else {
				PtvPscS6.add(null);
			}
			HS7Dutgx += UEOrJtSf;
		}

		Shape VLLPtrS6 = vBoaBBy9.getClip();

		Ellipse2D dTpOVmKk = new Ellipse2D.Double(yMY1wZO7.getX(), yMY1wZO7.getY(), yMY1wZO7.getWidth(),
				yMY1wZO7.getHeight() - VOzc0eJG);

		Ellipse2D pVsjK9P5 = new Ellipse2D.Double(yMY1wZO7.getX(), yMY1wZO7.getY() + VOzc0eJG, yMY1wZO7.getWidth(),
				yMY1wZO7.getHeight() - VOzc0eJG);

		Rectangle2D HKLJ9sE4 = new Rectangle2D.Double(dTpOVmKk.getX(), dTpOVmKk.getCenterY(), yMY1wZO7.getWidth(),
				pVsjK9P5.getMaxY() - dTpOVmKk.getCenterY());

		Rectangle2D UR8vUEu9 = new Rectangle2D.Double(yMY1wZO7.getX(), dTpOVmKk.getY(), yMY1wZO7.getWidth(),
				pVsjK9P5.getCenterY() - dTpOVmKk.getY());

		Area rq00UdC6 = new Area(dTpOVmKk);
		rq00UdC6.add(new Area(HKLJ9sE4));
		Area dp6sE8jS = new Area(pVsjK9P5);
		dp6sE8jS.add(new Area(UR8vUEu9));
		Area cb9GMh6z = new Area(rq00UdC6);
		cb9GMh6z.intersect(dp6sE8jS);

		Area oRFb41tC = new Area(cb9GMh6z);
		oRFb41tC.subtract(new Area(dTpOVmKk));

		Area zo0vFaUG = new Area(cb9GMh6z);
		zo0vFaUG.subtract(new Area(pVsjK9P5));

		int[] NfoMYWKX;
		int[] JUBryPrZ;
		uHmg6dwF = new Arc2D.Double(EJi0Hhow, rv3BJdGc + VOzc0eJG, yMY1wZO7.getWidth(), yMY1wZO7.getHeight() - VOzc0eJG,
				0, 360, Arc2D.PIE);

		int nnlorj6e = PtvPscS6.size();
		for (int Ut6YQe8k = 0; Ut6YQe8k < nnlorj6e; Ut6YQe8k++) {
			uHmg6dwF = (Arc2D.Double) PtvPscS6.get(Ut6YQe8k);
			if (uHmg6dwF == null) {
				continue;
			}
			Comparable izURLJKC = getSectionKey(Ut6YQe8k);
			Yf1vEMvS = lookupSectionPaint(izURLJKC, true);
			gzMJhe1j = lookupSectionOutlinePaint(izURLJKC);
			ReFnUUPn = lookupSectionOutlineStroke(izURLJKC);
			vBoaBBy9.setPaint(Yf1vEMvS);
			vBoaBBy9.fill(uHmg6dwF);
			vBoaBBy9.setPaint(gzMJhe1j);
			vBoaBBy9.setStroke(ReFnUUPn);
			vBoaBBy9.draw(uHmg6dwF);
			vBoaBBy9.setPaint(Yf1vEMvS);

			Point2D nOPE6Qid = uHmg6dwF.getStartPoint();

			NfoMYWKX = new int[] { (int) uHmg6dwF.getCenterX(), (int) uHmg6dwF.getCenterX(), (int) nOPE6Qid.getX(),
					(int) nOPE6Qid.getX() };
			JUBryPrZ = new int[] { (int) uHmg6dwF.getCenterY(), (int) uHmg6dwF.getCenterY() - VOzc0eJG,
					(int) nOPE6Qid.getY() - VOzc0eJG, (int) nOPE6Qid.getY() };
			Polygon cfpcavS6 = new Polygon(NfoMYWKX, JUBryPrZ, 4);
			vBoaBBy9.setPaint(java.awt.Color.lightGray);
			vBoaBBy9.fill(cfpcavS6);
			vBoaBBy9.setPaint(gzMJhe1j);
			vBoaBBy9.setStroke(ReFnUUPn);
			vBoaBBy9.draw(cfpcavS6);
			vBoaBBy9.setPaint(Yf1vEMvS);

		}

		vBoaBBy9.setPaint(Color.gray);
		vBoaBBy9.fill(zo0vFaUG);
		vBoaBBy9.fill(oRFb41tC);

		int qR4MSLcb = 0;
		paBy67Xn = PtvPscS6.iterator();
		while (paBy67Xn.hasNext()) {
			Arc2D eDOELJnY = (Arc2D) paBy67Xn.next();
			if (eDOELJnY != null) {
				Comparable aagd2j6o = getSectionKey(qR4MSLcb);
				Yf1vEMvS = lookupSectionPaint(aagd2j6o, true);
				gzMJhe1j = lookupSectionOutlinePaint(aagd2j6o);
				ReFnUUPn = lookupSectionOutlineStroke(aagd2j6o);
				drawSide(vBoaBBy9, yMY1wZO7, eDOELJnY, oRFb41tC, zo0vFaUG, Yf1vEMvS, gzMJhe1j, ReFnUUPn, false, true);
			}
			qR4MSLcb++;
		}

		qR4MSLcb = 0;
		paBy67Xn = PtvPscS6.iterator();
		while (paBy67Xn.hasNext()) {
			Arc2D YyyGSwCd = (Arc2D) paBy67Xn.next();
			if (YyyGSwCd != null) {
				Comparable NviA02WJ = getSectionKey(qR4MSLcb);
				Yf1vEMvS = lookupSectionPaint(NviA02WJ);
				gzMJhe1j = lookupSectionOutlinePaint(NviA02WJ);
				ReFnUUPn = lookupSectionOutlineStroke(NviA02WJ);
				drawSide(vBoaBBy9, yMY1wZO7, YyyGSwCd, oRFb41tC, zo0vFaUG, Yf1vEMvS, gzMJhe1j, ReFnUUPn, true, false);
			}
			qR4MSLcb++;
		}

		vBoaBBy9.setClip(VLLPtrS6);

		Arc2D eAjI0NUL;
		for (int hHksqwOa = 0; hHksqwOa < nnlorj6e; hHksqwOa++) {
			uHmg6dwF = (Arc2D.Double) PtvPscS6.get(hHksqwOa);
			if (uHmg6dwF == null) {
				continue;
			}
			eAjI0NUL = new Arc2D.Double(EJi0Hhow, rv3BJdGc, yMY1wZO7.getWidth(), yMY1wZO7.getHeight() - VOzc0eJG,
					uHmg6dwF.getAngleStart(), uHmg6dwF.getAngleExtent(), Arc2D.PIE);

			Comparable g7qCl3fl = (Comparable) c3UW7XhT.get(hHksqwOa);
			Yf1vEMvS = lookupSectionPaint(g7qCl3fl, true);
			gzMJhe1j = lookupSectionOutlinePaint(g7qCl3fl);
			ReFnUUPn = lookupSectionOutlineStroke(g7qCl3fl);
			vBoaBBy9.setPaint(Yf1vEMvS);
			vBoaBBy9.fill(eAjI0NUL);
			vBoaBBy9.setStroke(ReFnUUPn);
			vBoaBBy9.setPaint(gzMJhe1j);
			vBoaBBy9.draw(eAjI0NUL);

			if (nln7S9vy != null) {
				EntityCollection ZUarTWcd = nln7S9vy.getOwner().getEntityCollection();
				if (ZUarTWcd != null) {
					String uVLbuxDE = null;
					PieToolTipGenerator gCvMAr5q = getToolTipGenerator();
					if (gCvMAr5q != null) {
						uVLbuxDE = gCvMAr5q.generateToolTip(cujkBZhV, g7qCl3fl);
					}
					String wx1m4kkR = null;
					if (getURLGenerator() != null) {
						wx1m4kkR = getURLGenerator().generateURL(cujkBZhV, g7qCl3fl, getPieIndex());
					}
					PieSectionEntity uyOx4BCc = new PieSectionEntity(eAjI0NUL, cujkBZhV, getPieIndex(), hHksqwOa,
							g7qCl3fl, uVLbuxDE, wx1m4kkR);
					ZUarTWcd.add(uyOx4BCc);
				}
			}
			List jVSXyEx2 = cujkBZhV.getKeys();
			Rectangle2D lirSWMZE = new Rectangle2D.Double(Z4yMbp57.getX(), Z4yMbp57.getY(), Z4yMbp57.getWidth(),
					Z4yMbp57.getHeight() - VOzc0eJG);
			if (getSimpleLabels()) {
				drawSimpleLabels(vBoaBBy9, jVSXyEx2, Q6dUvmcX, lirSWMZE, xpzbfgZV, O8MgrPBG);
			} else {
				drawLabels(vBoaBBy9, jVSXyEx2, Q6dUvmcX, lirSWMZE, xpzbfgZV, O8MgrPBG);
			}
		}

		vBoaBBy9.setClip(PqZJdCc6);
		vBoaBBy9.setComposite(bAcRV2RO);
		drawOutline(vBoaBBy9, Z4yMbp57);

	}
}