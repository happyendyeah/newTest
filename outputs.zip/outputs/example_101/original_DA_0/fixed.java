public class test {
	public T[] sample(int r52La3Xs) throws NotStrictlyPositiveException {
		if (r52La3Xs <= 0) {
			throw new NotStrictlyPositiveException(LocalizedFormats.NUMBER_OF_SAMPLES, r52La3Xs);
		}

		final T[] KTD3DaIr = (T[]) java.lang.reflect.Array.newInstance(singletons.get(0).getClass(), r52La3Xs);

		if (r52La3Xs <= 0) {
			throw new NotStrictlyPositiveException(LocalizedFormats.NUMBER_OF_SAMPLES, r52La3Xs);
		}

		return KTD3DaIr;

	}
}