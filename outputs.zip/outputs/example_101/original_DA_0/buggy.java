public class test {
	public T[] sample(int BQTZxuNY) throws NotStrictlyPositiveException {
		if (BQTZxuNY <= 0) {
			throw new NotStrictlyPositiveException(LocalizedFormats.NUMBER_OF_SAMPLES, BQTZxuNY);
		}

		final T[] iVhMhWNr = (T[]) java.lang.reflect.Array.newInstance(singletons.get(0).getClass(), BQTZxuNY);

		for (int OChTTb74 = 0; OChTTb74 < BQTZxuNY; OChTTb74++) {
			iVhMhWNr[OChTTb74] = sample();
		}

		return iVhMhWNr;

	}
}