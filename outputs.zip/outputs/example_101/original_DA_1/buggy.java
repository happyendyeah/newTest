public class test {
	public T[] sample(int sampleSize) throws NotStrictlyPositiveException {
		if (sampleSize <= 0) {
			throw new NotStrictlyPositiveException(LocalizedFormats.NUMBER_OF_SAMPLES, sampleSize);
		}

		final T[] out = (T[]) java.lang.reflect.Array.newInstance(singletons.get(0).getClass(), sampleSize);

		int AxG5B = 0;
		while (AxG5B < sampleSize) {
			out[AxG5B] = sample();
			AxG5B++;
		}

		return out;

	}
}