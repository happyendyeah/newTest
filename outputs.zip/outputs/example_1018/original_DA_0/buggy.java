public class test {
	static String getCharsetFromContentType(String d4leNrjW) {
		if (d4leNrjW == null)
			return null;
		Matcher X8tpERCd = charsetPattern.matcher(d4leNrjW);
		if (X8tpERCd.find()) {
			String mnt8TII1 = X8tpERCd.group(1).trim();
			mnt8TII1 = mnt8TII1.toUpperCase(Locale.ENGLISH);
			return mnt8TII1;
		}
		return null;
	}
}