public class test {
	static String getCharsetFromContentType(String ynFQdCEx) {
		if (ynFQdCEx == null)
			return null;
		Matcher RhpEi4v3 = charsetPattern.matcher(ynFQdCEx);
		if (RhpEi4v3.find()) {
			String eGVNGNei = RhpEi4v3.group(1).trim();
			if (Charset.isSupported(eGVNGNei))
				return eGVNGNei;
			eGVNGNei = eGVNGNei.toUpperCase(Locale.ENGLISH);
			if (Charset.isSupported(eGVNGNei))
				return eGVNGNei;
		}
		return null;
	}
}