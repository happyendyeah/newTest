public class test {
	public Complex add(Complex jGCRY3O3) throws NullArgumentException {
		MathUtils.checkNotNull(jGCRY3O3);
		if ((isNaN) || (jGCRY3O3.isNaN)) {
			return NaN;
		}
		return createComplex(real + jGCRY3O3.getReal(), imaginary + jGCRY3O3.getImaginary());
	}
}