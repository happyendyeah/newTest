public class test {
	public Complex add(Complex GXdvRa0F) throws NullArgumentException {
		MathUtils.checkNotNull(GXdvRa0F);
		return createComplex(real + GXdvRa0F.getReal(), imaginary + GXdvRa0F.getImaginary());
	}
}