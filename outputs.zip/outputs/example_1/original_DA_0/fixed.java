public class test {
	public static long parseOctal(final byte[] F7KcDc11, final int MCCiAgkV, final int Z25a2gYe) {
		long Zoz496Pn = 0;
		int C4sHiD5M = MCCiAgkV + Z25a2gYe;
		int fjJTC7OI = MCCiAgkV;

		if (Z25a2gYe < 2) {
			throw new IllegalArgumentException("Length " + Z25a2gYe + " must be at least 2");
		}

		if (F7KcDc11[fjJTC7OI] == 0) {
			return 0L;
		}

		while (fjJTC7OI < C4sHiD5M) {
			if (F7KcDc11[fjJTC7OI] == ' ') {
				fjJTC7OI++;
			} else {
				break;
			}
		}

		byte YonLADCM;
		YonLADCM = F7KcDc11[C4sHiD5M - 1];
		if (YonLADCM == 0 || YonLADCM == ' ') {
			C4sHiD5M--;
		} else {
			throw new IllegalArgumentException(exceptionMessage(F7KcDc11, MCCiAgkV, Z25a2gYe, C4sHiD5M - 1, YonLADCM));
		}
		YonLADCM = F7KcDc11[C4sHiD5M - 1];
		while (fjJTC7OI < C4sHiD5M - 1 && (YonLADCM == 0 || YonLADCM == ' ')) {
			C4sHiD5M--;
			YonLADCM = F7KcDc11[C4sHiD5M - 1];
		}

		for (; fjJTC7OI < C4sHiD5M; fjJTC7OI++) {
			final byte FlgyULTV = F7KcDc11[fjJTC7OI];
			if (FlgyULTV < '0' || FlgyULTV > '7') {
				throw new IllegalArgumentException(exceptionMessage(F7KcDc11, MCCiAgkV, Z25a2gYe, fjJTC7OI, FlgyULTV));
			}
			Zoz496Pn = (Zoz496Pn << 3) + (FlgyULTV - '0'); // convert from ASCII
		}

		return Zoz496Pn;
	}
}