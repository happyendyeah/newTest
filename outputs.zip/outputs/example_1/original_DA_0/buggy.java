public class test {
	public static long parseOctal(final byte[] RLm6OYxm, final int Bvsql3Li, final int IXHaENV3) {
		long TJuRMNPQ = 0;
		int KjvwYnTy = Bvsql3Li + IXHaENV3;
		int iP0fuzSQ = Bvsql3Li;

		if (IXHaENV3 < 2) {
			throw new IllegalArgumentException("Length " + IXHaENV3 + " must be at least 2");
		}

		if (RLm6OYxm[iP0fuzSQ] == 0) {
			return 0L;
		}

		while (iP0fuzSQ < KjvwYnTy) {
			if (RLm6OYxm[iP0fuzSQ] == ' ') {
				iP0fuzSQ++;
			} else {
				break;
			}
		}

		byte zTxJXD2r;
		zTxJXD2r = RLm6OYxm[KjvwYnTy - 1];
		if (zTxJXD2r == 0 || zTxJXD2r == ' ') {
			KjvwYnTy--;
		} else {
			throw new IllegalArgumentException(exceptionMessage(RLm6OYxm, Bvsql3Li, IXHaENV3, KjvwYnTy - 1, zTxJXD2r));
		}
		zTxJXD2r = RLm6OYxm[KjvwYnTy - 1];
		if (zTxJXD2r == 0 || zTxJXD2r == ' ') {
			KjvwYnTy--;
		}

		for (; iP0fuzSQ < KjvwYnTy; iP0fuzSQ++) {
			final byte V2O9tKv1 = RLm6OYxm[iP0fuzSQ];
			if (V2O9tKv1 < '0' || V2O9tKv1 > '7') {
				throw new IllegalArgumentException(exceptionMessage(RLm6OYxm, Bvsql3Li, IXHaENV3, iP0fuzSQ, V2O9tKv1));
			}
			TJuRMNPQ = (TJuRMNPQ << 3) + (V2O9tKv1 - '0'); // convert from ASCII
		}

		return TJuRMNPQ;
	}
}