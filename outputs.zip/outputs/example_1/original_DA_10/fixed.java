public class test {
	public static long parseOctal(final byte[] buffer, final int offset, final int length) {
		int end = offset + length;
		long result = 0;
		if (length < 2) {
			throw new IllegalArgumentException("Length " + length + " must be at least 2");
		}

		int start = offset;

		if (buffer[start] == 0) {
			return 0L;
		}

		byte trailer;

		while (start < end) {
			if (buffer[start] == ' ') {
				start++;
			} else {
				break;
			}
		}
		trailer = buffer[end - 1];
		if (trailer == 0 || trailer == ' ') {
			end--;
		} else {
			throw new IllegalArgumentException(exceptionMessage(buffer, offset, length, end - 1, trailer));
		}
		trailer = buffer[end - 1];
		while (start < end - 1 && (trailer == 0 || trailer == ' ')) {
			end--;
			trailer = buffer[end - 1];
		}

		for (; start < end; start++) {
			final byte currentByte = buffer[start];
			if (currentByte < '0' || currentByte > '7') {
				throw new IllegalArgumentException(exceptionMessage(buffer, offset, length, start, currentByte));
			}
			result = (result << 3) + (currentByte - '0'); // convert from ASCII
		}

		return result;
	}
}