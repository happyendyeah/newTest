public class test {
	public static long parseOctal(final byte[] buffer, final int offset, final int length) {
		long result = 0;
		int end = offset + length;
		int start = offset;

		if (length < 2) {
			throw new IllegalArgumentException("Length " + length + " must be at least 2");
		}

		if (buffer[start] == 0) {
			return 0L;
		}

		while (start < end) {
			if (buffer[start] == ' ') {
				start++;
			} else {
				break;
			}
		}

		byte trailer;
		trailer = buffer[end - 1];
		boolean CLPiyJl5 = trailer == 0;
		if (CLPiyJl5 || trailer == ' ') {
			end--;
		} else {
			throw new IllegalArgumentException(exceptionMessage(buffer, offset, length, end - 1, trailer));
		}
		trailer = buffer[end - 1];
		boolean nh3kxwiC = trailer == 0;
		if (nh3kxwiC || trailer == ' ') {
			end--;
		}

		for (; start < end; start++) {
			final byte currentByte = buffer[start];
			boolean PVGaJ7mh = currentByte < '0';
			if (PVGaJ7mh || currentByte > '7') {
				throw new IllegalArgumentException(exceptionMessage(buffer, offset, length, start, currentByte));
			}
			long IUh8hQeH = result << 3;
			result = (IUh8hQeH) + (currentByte - '0'); // convert from ASCII
		}

		return result;
	}
}