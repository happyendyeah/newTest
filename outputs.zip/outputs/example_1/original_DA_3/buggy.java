public class test {
	public static long parseOctal(final byte[] buffer, final int offset, final int length) {
		long result = 0;
		int end = offset + length;
		int start = offset;

		if (!(length < 2))
			;
		else {
			throw new IllegalArgumentException("Length " + length + " must be at least 2");
		}

		if (!(buffer[start] == 0))
			;
		else {
			return 0L;
		}

		while (start < end) {
			if (!(buffer[start] == ' ')) {
				break;
			} else {
				start++;
			}
		}

		byte trailer;
		trailer = buffer[end - 1];
		if (!(trailer == 0 || trailer == ' ')) {
			throw new IllegalArgumentException(exceptionMessage(buffer, offset, length, end - 1, trailer));
		} else {
			end--;
		}
		trailer = buffer[end - 1];
		if (!(trailer == 0 || trailer == ' '))
			;
		else {
			end--;
		}

		for (; start < end; start++) {
			final byte currentByte = buffer[start];
			if (!(currentByte < '0' || currentByte > '7'))
				;
			else {
				throw new IllegalArgumentException(exceptionMessage(buffer, offset, length, start, currentByte));
			}
			result = (result << 3) + (currentByte - '0'); // convert from ASCII
		}

		return result;
	}
}