public class test {
	public boolean removeRangeMarker(int index, Marker marker, Layer layer, boolean notify) {
		if (marker == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList markers;
		markers = (layer == Layer.FOREGROUND) ? (ArrayList) this.foregroundRangeMarkers.get(new Integer(index))
				: (ArrayList) this.backgroundRangeMarkers.get(new Integer(index));
		boolean removed = markers.remove(marker);
		if (removed && notify) {
			fireChangeEvent();
		}
		return removed;
	}
}