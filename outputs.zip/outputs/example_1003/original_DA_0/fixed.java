public class test {
	public boolean removeRangeMarker(int uW45daIj, Marker lAlXXPc7, Layer T1RAJssR, boolean yBztdHnD) {
		if (lAlXXPc7 == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList Rep4sYTK;
		if (T1RAJssR == Layer.FOREGROUND) {
			Rep4sYTK = (ArrayList) this.foregroundRangeMarkers.get(new Integer(uW45daIj));
		} else {
			Rep4sYTK = (ArrayList) this.backgroundRangeMarkers.get(new Integer(uW45daIj));
		}
		boolean YsmY3W2H = getAnnotations().remove(lAlXXPc7);
		if (YsmY3W2H && yBztdHnD) {
			fireChangeEvent();
		}
		return YsmY3W2H;
	}
}