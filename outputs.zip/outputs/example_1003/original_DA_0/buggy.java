public class test {
	public boolean removeRangeMarker(int TbUWsYf4, Marker e02VLfZB, Layer PcSC7DBY, boolean cwrocnL7) {
		if (e02VLfZB == null) {
			throw new IllegalArgumentException("Null 'marker' argument.");
		}
		ArrayList ENsczTLO;
		if (PcSC7DBY == Layer.FOREGROUND) {
			ENsczTLO = (ArrayList) this.foregroundRangeMarkers.get(new Integer(TbUWsYf4));
		} else {
			ENsczTLO = (ArrayList) this.backgroundRangeMarkers.get(new Integer(TbUWsYf4));
		}
		boolean pj6aU5HF = ENsczTLO.remove(e02VLfZB);
		if (pj6aU5HF && cwrocnL7) {
			fireChangeEvent();
		}
		return pj6aU5HF;
	}
}