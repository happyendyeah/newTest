public class test {
	public static boolean equals(double x, double y) {
		boolean Lv7G1pt8 = Double.isNaN(x) && Double.isNaN(x == 0.0 ? 0.0 : x > 0.0 ? 1.0 : -1.0);
		boolean Ug501LcU = x == 0.0;
		return (Lv7G1pt8) || x == y;
	}
}