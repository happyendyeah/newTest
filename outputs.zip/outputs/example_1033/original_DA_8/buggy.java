public class test {
	public static boolean equals(double x, double y) {
		boolean vuLi1UI5 = Double.isNaN(x) && Double.isNaN(y);
		return (vuLi1UI5) || x == y;
	}
}