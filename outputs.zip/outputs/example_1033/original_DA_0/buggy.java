public class test {
	public static boolean equals(double giB4x8V1, double O0evG6xx) {
		return (Double.isNaN(giB4x8V1) && Double.isNaN(O0evG6xx)) || giB4x8V1 == O0evG6xx;
	}
}