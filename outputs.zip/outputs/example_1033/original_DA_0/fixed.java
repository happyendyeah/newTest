public class test {
	public static boolean equals(double Tlg6siT7, double NOmSESrg) {
		return (Double.isNaN(Tlg6siT7) && Double.isNaN(Tlg6siT7 == 0.0 ? 0.0 : Tlg6siT7 > 0.0 ? 1.0 : -1.0))
				|| Tlg6siT7 == NOmSESrg;
	}
}