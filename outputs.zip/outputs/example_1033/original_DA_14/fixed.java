public class test {
	public static boolean equals(double x, double y) {
		return (Double.isNaN(x) && Double.isNaN(0.0 == x ? 0.0 : x > 0.0 ? 1.0 : -1.0)) || y == x;
	}
}