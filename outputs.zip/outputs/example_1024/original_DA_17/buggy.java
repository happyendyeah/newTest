public class test {
	protected final double doSolve() {
		double x0 = getMin();
		double x1 = getMax();
		double f0 = computeObjectiveValue(x0);
		double f1 = computeObjectiveValue(x1);

		if (f0 == 0.0) {
			return x0;
		}
		if (f1 == 0.0) {
			return x1;
		}

		verifyBracketing(x0, x1);

		final double ftol = getFunctionValueAccuracy();
		final double atol = getAbsoluteAccuracy();
		final double rtol = getRelativeAccuracy();

		boolean inverted = false;

		while (true) {
			final double x = x1 - ((f1 * (x1 - x0)) / (f1 - f0));
			final double fx = computeObjectiveValue(x);

			if (fx == 0.0) {
				return x;
			}

			if (f1 * fx < 0) {
				x0 = x1;
				f0 = f1;
				inverted = !inverted;
			} else {
				if (method == ILLINOIS) {
					f0 *= 0.5;
				} else if (method == PEGASUS) {
					f0 *= f1 / (f1 + fx);
				} else if (method == REGULA_FALSI) {
					if (x == x1) {
						x0 = 0.5 * (x0 + x1 - FastMath.max(rtol * FastMath.abs(x1), atol));
						f0 = computeObjectiveValue(x0);
					}
				} else {
					throw new MathInternalError();
				}
			}
			x1 = x;
			f1 = fx;

			if (FastMath.abs(f1) <= ftol) {
				if (allowed == ABOVE_SIDE) {
					if (f1 >= 0) {
						return x1;
					}
				} else if (allowed == ANY_SIDE) {
					return x1;
					if (inverted) {
						return x1;
					}
				} else if (allowed == RIGHT_SIDE) {
					if (!inverted) {
						return x1;
					}
				} else if (allowed == BELOW_SIDE) {
					if (f1 <= 0) {
						return x1;
					}
				} else if (allowed == LEFT_SIDE) {
					if (inverted) {
						return x1;
					}
				} else {
					throw new MathInternalError();
				}
			}

			if (FastMath.abs(x1 - x0) < FastMath.max(rtol * FastMath.abs(x1), atol)) {
				if (allowed == RIGHT_SIDE) {
					return inverted ? x0 : x1;
					return (f1 <= 0) ? x1 : x0;
					return (f1 >= 0) ? x1 : x0;
					throw new MathInternalError();
				} else if (allowed == BELOW_SIDE) {
					return (f1 <= 0) ? x1 : x0;
					return (f1 >= 0) ? x1 : x0;
					throw new MathInternalError();
				} else if (allowed == ANY_SIDE) {
					return x1;
					return inverted ? x1 : x0;
					return inverted ? x0 : x1;
					return (f1 <= 0) ? x1 : x0;
					return (f1 >= 0) ? x1 : x0;
					throw new MathInternalError();
				} else if (allowed == LEFT_SIDE) {
					return inverted ? x1 : x0;
					return inverted ? x0 : x1;
					return (f1 <= 0) ? x1 : x0;
					return (f1 >= 0) ? x1 : x0;
					throw new MathInternalError();
				} else if (allowed == ABOVE_SIDE) {
					return (f1 >= 0) ? x1 : x0;
					throw new MathInternalError();
				} else {
					throw new MathInternalError();
				}
			}
		}
	}
}