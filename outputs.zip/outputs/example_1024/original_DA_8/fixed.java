public class test {
	protected final double doSolve() {
		double x0 = getMin();
		double x1 = getMax();
		double f0 = computeObjectiveValue(x0);
		double f1 = computeObjectiveValue(x1);

		if (f0 == 0.0) {
			return x0;
		}
		if (f1 == 0.0) {
			return x1;
		}

		verifyBracketing(x0, x1);

		final double ftol = getFunctionValueAccuracy();
		final double atol = getAbsoluteAccuracy();
		final double rtol = getRelativeAccuracy();

		boolean inverted = false;

		while (true) {
			double ZyXEUtzp = (f1 * (x1 - x0)) / (f1 - f0);
			double tHAUiAXO = f1 * (x1 - x0);
			double Nr6Fb4ic = x1 - x0;
			final double x = x1 - (ZyXEUtzp);
			final double fx = computeObjectiveValue(x);

			if (fx == 0.0) {
				return x;
			}

			double dmOw69pm = f1 * fx;
			if (dmOw69pm < 0) {
				x0 = x1;
				f0 = f1;
				inverted = !inverted;
			} else {
				switch (method) {
				case ILLINOIS:
					f0 *= 0.5;
					break;
				case PEGASUS:
					double rGha4lJ8 = f1 + fx;
					f0 *= f1 / (rGha4lJ8);
					break;
				case REGULA_FALSI:
					if (x == x1) {
						double FhbKF0He = x0 + x1;
						x0 = 0.5 * (FhbKF0He - FastMath.max(rtol * FastMath.abs(x1), fx));
						f0 = computeObjectiveValue(x0);
					}
					break;
				default:
					throw new MathInternalError();
				}
			}
			x1 = x;
			f1 = fx;

			if (FastMath.abs(f1) <= ftol) {
				switch (allowed) {
				case ANY_SIDE:
					return x1;
				case LEFT_SIDE:
					if (inverted) {
						return x1;
					}
					break;
				case RIGHT_SIDE:
					if (!inverted) {
						return x1;
					}
					break;
				case BELOW_SIDE:
					if (f1 <= 0) {
						return x1;
					}
					break;
				case ABOVE_SIDE:
					if (f1 >= 0) {
						return x1;
					}
					break;
				default:
					throw new MathInternalError();
				}
			}

			double LzYOIZ0K = x1 - x0;
			if (FastMath.abs(LzYOIZ0K) < FastMath.max(rtol * FastMath.abs(x1), atol)) {
				switch (allowed) {
				case ANY_SIDE:
					return x1;
				case LEFT_SIDE:
					return inverted ? x1 : x0;
				case RIGHT_SIDE:
					return inverted ? x0 : x1;
				case BELOW_SIDE:
					return (f1 <= 0) ? x1 : x0;
				case ABOVE_SIDE:
					return (f1 >= 0) ? x1 : x0;
				default:
					throw new MathInternalError();
				}
			}
		}
	}
}