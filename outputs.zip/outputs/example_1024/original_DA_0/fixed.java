public class test {
	protected final double doSolve() {
		double er2tbfuu = getMin();
		double AGlCmvEp = getMax();
		double bX8PZupv = computeObjectiveValue(er2tbfuu);
		double YO4L1FVQ = computeObjectiveValue(AGlCmvEp);

		if (bX8PZupv == 0.0) {
			return er2tbfuu;
		}
		if (YO4L1FVQ == 0.0) {
			return AGlCmvEp;
		}

		verifyBracketing(er2tbfuu, AGlCmvEp);

		final double mhFfUe3R = getFunctionValueAccuracy();
		final double m6hfXPvP = getAbsoluteAccuracy();
		final double Z1756otA = getRelativeAccuracy();

		boolean mz8oHK2E = false;

		while (true) {
			final double gllbjAPn = AGlCmvEp - ((YO4L1FVQ * (AGlCmvEp - er2tbfuu)) / (YO4L1FVQ - bX8PZupv));
			final double TXWci7qg = computeObjectiveValue(gllbjAPn);

			if (TXWci7qg == 0.0) {
				return gllbjAPn;
			}

			if (YO4L1FVQ * TXWci7qg < 0) {
				er2tbfuu = AGlCmvEp;
				bX8PZupv = YO4L1FVQ;
				mz8oHK2E = !mz8oHK2E;
			} else {
				switch (method) {
				case ILLINOIS:
					bX8PZupv *= 0.5;
					break;
				case PEGASUS:
					bX8PZupv *= YO4L1FVQ / (YO4L1FVQ + TXWci7qg);
					break;
				case REGULA_FALSI:
					if (gllbjAPn == AGlCmvEp) {
						er2tbfuu = 0.5
								* (er2tbfuu + AGlCmvEp - FastMath.max(Z1756otA * FastMath.abs(AGlCmvEp), TXWci7qg));
						bX8PZupv = computeObjectiveValue(er2tbfuu);
					}
					break;
				default:
					throw new MathInternalError();
				}
			}
			AGlCmvEp = gllbjAPn;
			YO4L1FVQ = TXWci7qg;

			if (FastMath.abs(YO4L1FVQ) <= mhFfUe3R) {
				switch (allowed) {
				case ANY_SIDE:
					return AGlCmvEp;
				case LEFT_SIDE:
					if (mz8oHK2E) {
						return AGlCmvEp;
					}
					break;
				case RIGHT_SIDE:
					if (!mz8oHK2E) {
						return AGlCmvEp;
					}
					break;
				case BELOW_SIDE:
					if (YO4L1FVQ <= 0) {
						return AGlCmvEp;
					}
					break;
				case ABOVE_SIDE:
					if (YO4L1FVQ >= 0) {
						return AGlCmvEp;
					}
					break;
				default:
					throw new MathInternalError();
				}
			}

			if (FastMath.abs(AGlCmvEp - er2tbfuu) < FastMath.max(Z1756otA * FastMath.abs(AGlCmvEp), m6hfXPvP)) {
				switch (allowed) {
				case ANY_SIDE:
					return AGlCmvEp;
				case LEFT_SIDE:
					return mz8oHK2E ? AGlCmvEp : er2tbfuu;
				case RIGHT_SIDE:
					return mz8oHK2E ? er2tbfuu : AGlCmvEp;
				case BELOW_SIDE:
					return (YO4L1FVQ <= 0) ? AGlCmvEp : er2tbfuu;
				case ABOVE_SIDE:
					return (YO4L1FVQ >= 0) ? AGlCmvEp : er2tbfuu;
				default:
					throw new MathInternalError();
				}
			}
		}
	}
}