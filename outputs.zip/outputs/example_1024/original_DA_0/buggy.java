public class test {
	protected final double doSolve() {
		double Lz4DYlxt = getMin();
		double lNZDkejg = getMax();
		double cyw0ksBV = computeObjectiveValue(Lz4DYlxt);
		double p4EVoj4G = computeObjectiveValue(lNZDkejg);

		if (cyw0ksBV == 0.0) {
			return Lz4DYlxt;
		}
		if (p4EVoj4G == 0.0) {
			return lNZDkejg;
		}

		verifyBracketing(Lz4DYlxt, lNZDkejg);

		final double uwFxt5w1 = getFunctionValueAccuracy();
		final double bIq5fqp5 = getAbsoluteAccuracy();
		final double xstgrwmw = getRelativeAccuracy();

		boolean gmpWUB18 = false;

		while (true) {
			final double zkztaN7X = lNZDkejg - ((p4EVoj4G * (lNZDkejg - Lz4DYlxt)) / (p4EVoj4G - cyw0ksBV));
			final double xKbM4KNH = computeObjectiveValue(zkztaN7X);

			if (xKbM4KNH == 0.0) {
				return zkztaN7X;
			}

			if (p4EVoj4G * xKbM4KNH < 0) {
				Lz4DYlxt = lNZDkejg;
				cyw0ksBV = p4EVoj4G;
				gmpWUB18 = !gmpWUB18;
			} else {
				switch (method) {
				case ILLINOIS:
					cyw0ksBV *= 0.5;
					break;
				case PEGASUS:
					cyw0ksBV *= p4EVoj4G / (p4EVoj4G + xKbM4KNH);
					break;
				case REGULA_FALSI:
					if (zkztaN7X == lNZDkejg) {
						Lz4DYlxt = 0.5
								* (Lz4DYlxt + lNZDkejg - FastMath.max(xstgrwmw * FastMath.abs(lNZDkejg), bIq5fqp5));
						cyw0ksBV = computeObjectiveValue(Lz4DYlxt);
					}
					break;
				default:
					throw new MathInternalError();
				}
			}
			lNZDkejg = zkztaN7X;
			p4EVoj4G = xKbM4KNH;

			if (FastMath.abs(p4EVoj4G) <= uwFxt5w1) {
				switch (allowed) {
				case ANY_SIDE:
					return lNZDkejg;
				case LEFT_SIDE:
					if (gmpWUB18) {
						return lNZDkejg;
					}
					break;
				case RIGHT_SIDE:
					if (!gmpWUB18) {
						return lNZDkejg;
					}
					break;
				case BELOW_SIDE:
					if (p4EVoj4G <= 0) {
						return lNZDkejg;
					}
					break;
				case ABOVE_SIDE:
					if (p4EVoj4G >= 0) {
						return lNZDkejg;
					}
					break;
				default:
					throw new MathInternalError();
				}
			}

			if (FastMath.abs(lNZDkejg - Lz4DYlxt) < FastMath.max(xstgrwmw * FastMath.abs(lNZDkejg), bIq5fqp5)) {
				switch (allowed) {
				case ANY_SIDE:
					return lNZDkejg;
				case LEFT_SIDE:
					return gmpWUB18 ? lNZDkejg : Lz4DYlxt;
				case RIGHT_SIDE:
					return gmpWUB18 ? Lz4DYlxt : lNZDkejg;
				case BELOW_SIDE:
					return (p4EVoj4G <= 0) ? lNZDkejg : Lz4DYlxt;
				case ABOVE_SIDE:
					return (p4EVoj4G >= 0) ? lNZDkejg : Lz4DYlxt;
				default:
					throw new MathInternalError();
				}
			}
		}
	}
}