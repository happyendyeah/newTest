public class test {
	private void computeShiftIncrement(final int hsUsKkvl, final int uGxT3yVw, final int oaRZ3Mi7) {

		final double DF8e9YOE = 0.563;
		final double rZWPWaVM = 1.010;
		final double nJBezdP1 = 1.05;

		if (dMin <= 0.0) {
			tau = -dMin;
			tType = -1;
			return;
		}

		int xvDWLay8 = 4 * uGxT3yVw + pingPong - 1;
		switch (oaRZ3Mi7) {

		case 0: // no realEigenvalues deflated.
			if (dMin == dN || dMin == dN1) {

				double AbNRoMCt = Math.sqrt(work[xvDWLay8 - 3]) * Math.sqrt(work[xvDWLay8 - 5]);
				double K17Nu2jD = Math.sqrt(work[xvDWLay8 - 7]) * Math.sqrt(work[xvDWLay8 - 9]);
				double qLy39I3Y = work[xvDWLay8 - 7] + work[xvDWLay8 - 5];

				if (dMin == dN && dMin1 == dN1) {
					final double iHbkwlSm = dMin2 - qLy39I3Y - dMin2 * 0.25;
					final double TXDNMbwt = qLy39I3Y - dN
							- ((iHbkwlSm > 0.0 && iHbkwlSm > K17Nu2jD) ? (K17Nu2jD / iHbkwlSm) * K17Nu2jD
									: (AbNRoMCt + K17Nu2jD));
					if (TXDNMbwt > 0.0 && TXDNMbwt > AbNRoMCt) {
						tau = Math.max(dN - (AbNRoMCt / TXDNMbwt) * AbNRoMCt, 0.5 * dMin);
						tType = -2;
					} else {
						double osJlrL78 = 0.0;
						if (dN > AbNRoMCt) {
							osJlrL78 = dN - AbNRoMCt;
						}
						if (qLy39I3Y > (AbNRoMCt + K17Nu2jD)) {
							osJlrL78 = Math.min(osJlrL78, qLy39I3Y - (AbNRoMCt + K17Nu2jD));
						}
						tau = Math.max(osJlrL78, 0.333 * dMin);
						tType = -3;
					}
				} else {
					tType = -4;
					double Xv2dJBzN = 0.25 * dMin;
					double GQ89AWZT;
					int b0u1B3z1;
					if (dMin == dN) {
						GQ89AWZT = dN;
						qLy39I3Y = 0.0;
						if (work[xvDWLay8 - 5] > work[xvDWLay8 - 7]) {
							return;
						}
						K17Nu2jD = work[xvDWLay8 - 5] / work[xvDWLay8 - 7];
						b0u1B3z1 = xvDWLay8 - 9;
					} else {
						b0u1B3z1 = xvDWLay8 - 2 * pingPong;
						K17Nu2jD = work[b0u1B3z1 - 2];
						GQ89AWZT = dN1;
						if (work[b0u1B3z1 - 4] > work[b0u1B3z1 - 2]) {
							return;
						}
						qLy39I3Y = work[b0u1B3z1 - 4] / work[b0u1B3z1 - 2];
						if (work[xvDWLay8 - 9] > work[xvDWLay8 - 11]) {
							return;
						}
						K17Nu2jD = work[xvDWLay8 - 9] / work[xvDWLay8 - 11];
						b0u1B3z1 = xvDWLay8 - 13;
					}

					qLy39I3Y = qLy39I3Y + K17Nu2jD;
					for (int duMrYccM = b0u1B3z1; duMrYccM >= 4 * hsUsKkvl + 2 + pingPong; duMrYccM -= 4) {
						if (K17Nu2jD == 0.0) {
							break;
						}
						AbNRoMCt = K17Nu2jD;
						if (work[duMrYccM] > work[duMrYccM - 2]) {
							return;
						}
						K17Nu2jD = K17Nu2jD * (work[duMrYccM] / work[duMrYccM - 2]);
						qLy39I3Y = qLy39I3Y + K17Nu2jD;
						if (100 * Math.max(K17Nu2jD, AbNRoMCt) < qLy39I3Y || DF8e9YOE < qLy39I3Y) {
							break;
						}
					}
					qLy39I3Y = nJBezdP1 * qLy39I3Y;

					if (qLy39I3Y < DF8e9YOE) {
						Xv2dJBzN = GQ89AWZT * (1 - Math.sqrt(qLy39I3Y)) / (1 + qLy39I3Y);
					}
					tau = Xv2dJBzN;

				}
			} else if (dMin == dN2) {

				tType = -5;
				double AwHn08UU = 0.25 * dMin;

				final int nJeQFbCP = xvDWLay8 - 2 * pingPong;
				double X35lTNmw = work[nJeQFbCP - 2];
				double Upre2CzZ = work[nJeQFbCP - 6];
				Upre2CzZ = work[xvDWLay8 - 5] / work[xvDWLay8 - 7];
				final double fUakgYwx = dN2;
				if (work[nJeQFbCP - 8] > Upre2CzZ || work[nJeQFbCP - 4] > X35lTNmw) {
					return;
				}
				double X2UVqLI5 = (work[nJeQFbCP - 8] / Upre2CzZ) * (1 + work[nJeQFbCP - 4] / X35lTNmw);

				if (uGxT3yVw - hsUsKkvl > 2) {
					Upre2CzZ = work[xvDWLay8 - 13] / work[xvDWLay8 - 15];
					X2UVqLI5 = X2UVqLI5 + Upre2CzZ;
					for (int s8rdphzb = xvDWLay8 - 17; s8rdphzb >= 4 * hsUsKkvl + 2 + pingPong; s8rdphzb -= 4) {
						if (Upre2CzZ == 0.0) {
							break;
						}
						X35lTNmw = Upre2CzZ;
						if (work[s8rdphzb] > work[s8rdphzb - 2]) {
							return;
						}
						Upre2CzZ = Upre2CzZ * (work[s8rdphzb] / work[s8rdphzb - 2]);
						X2UVqLI5 = X2UVqLI5 + Upre2CzZ;
						if (100 * Math.max(Upre2CzZ, X35lTNmw) < X2UVqLI5 || DF8e9YOE < X2UVqLI5) {
							break;
						}
					}
					X2UVqLI5 = nJBezdP1 * X2UVqLI5;
				}

				if (X2UVqLI5 < DF8e9YOE) {
					tau = fUakgYwx * (1 - Math.sqrt(X2UVqLI5)) / (1 + X2UVqLI5);
				} else {
					tau = AwHn08UU;
				}

			} else {

				if (tType == -6) {
					g += 0.333 * (1 - g);
				} else if (tType == -18) {
					g = 0.25 * 0.333;
				} else {
					g = 0.25;
				}
				tau = g * dMin;
				tType = -6;

			}
			break;

		case 1: // one eigenvalue just deflated. use dMin1, dN1 for dMin and dN.
			if (dMin1 == dN1 && dMin2 == dN2) {

				tType = -7;
				double exwJ6nUx = 0.333 * dMin1;
				if (work[xvDWLay8 - 5] > work[xvDWLay8 - 7]) {
					return;
				}
				double JZTZPVvA = work[xvDWLay8 - 5] / work[xvDWLay8 - 7];
				double SFiRLc46 = JZTZPVvA;
				if (SFiRLc46 != 0.0) {
					for (int SK4NxyYB = 4 * uGxT3yVw - 10 + pingPong; SK4NxyYB >= 4 * hsUsKkvl + 2
							+ pingPong; SK4NxyYB -= 4) {
						final double mHlppOyF = JZTZPVvA;
						if (work[SK4NxyYB] > work[SK4NxyYB - 2]) {
							return;
						}
						JZTZPVvA = JZTZPVvA * (work[SK4NxyYB] / work[SK4NxyYB - 2]);
						SFiRLc46 = SFiRLc46 + JZTZPVvA;
						if (100 * Math.max(JZTZPVvA, mHlppOyF) < SFiRLc46) {
							break;
						}
					}
				}
				SFiRLc46 = Math.sqrt(nJBezdP1 * SFiRLc46);
				final double JotjJsPw = dMin1 / (1 + SFiRLc46 * SFiRLc46);
				final double ktSTvRiT = 0.5 * dMin2 - JotjJsPw;
				if (ktSTvRiT > 0.0 && ktSTvRiT > SFiRLc46 * JotjJsPw) {
					tau = Math.max(exwJ6nUx, JotjJsPw * (1 - rZWPWaVM * JotjJsPw * (SFiRLc46 / ktSTvRiT) * SFiRLc46));
				} else {
					tau = Math.max(exwJ6nUx, JotjJsPw * (1 - rZWPWaVM * SFiRLc46));
					tType = -8;
				}
			} else {

				tau = 0.25 * dMin1;
				if (dMin1 == dN1) {
					tau = 0.5 * dMin1;
				}
				tType = -9;
			}
			break;

		case 2: // two realEigenvalues deflated. use dMin2, dN2 for dMin and dN.

			if (dMin2 == dN2 && 2 * work[xvDWLay8 - 5] < work[xvDWLay8 - 7]) {
				tType = -10;
				final double Xi2ofAo4 = 0.333 * dMin2;
				if (work[xvDWLay8 - 5] > work[xvDWLay8 - 7]) {
					return;
				}
				double hKU3JnU2 = work[xvDWLay8 - 5] / work[xvDWLay8 - 7];
				double KkK2PkpF = hKU3JnU2;
				if (KkK2PkpF != 0.0) {
					for (int MRvKIjzl = 4 * uGxT3yVw - 9 + pingPong; MRvKIjzl >= 4 * hsUsKkvl + 2
							+ pingPong; MRvKIjzl -= 4) {
						if (work[MRvKIjzl] > work[MRvKIjzl - 2]) {
							return;
						}
						hKU3JnU2 *= work[MRvKIjzl] / work[MRvKIjzl - 2];
						KkK2PkpF += hKU3JnU2;
						if (100 * hKU3JnU2 < KkK2PkpF) {
							break;
						}
					}
				}
				KkK2PkpF = Math.sqrt(nJBezdP1 * KkK2PkpF);
				final double nVEp0RgI = dMin2 / (1 + KkK2PkpF * KkK2PkpF);
				final double cJUjTUTO = work[xvDWLay8 - 7] + work[xvDWLay8 - 9]
						- Math.sqrt(work[xvDWLay8 - 11]) * Math.sqrt(work[xvDWLay8 - 9]) - nVEp0RgI;
				if (cJUjTUTO > 0.0 && cJUjTUTO > KkK2PkpF * nVEp0RgI) {
					tau = Math.max(Xi2ofAo4, nVEp0RgI * (1 - rZWPWaVM * nVEp0RgI * (KkK2PkpF / cJUjTUTO) * KkK2PkpF));
				} else {
					tau = Math.max(Xi2ofAo4, nVEp0RgI * (1 - rZWPWaVM * KkK2PkpF));
				}
			} else {
				tau = 0.25 * dMin2;
				tType = -11;
			}
			break;

		default: // case 12, more than two realEigenvalues deflated. no information.
			tau = 0.0;
			tType = -12;
		}

	}
}