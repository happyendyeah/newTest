public class test {
	private void computeShiftIncrement(final int yGDhB3Hu, final int anqlK3Al, final int pq7oMML5) {

		final double koY7tJjj = 0.563;
		final double xFprdUap = 1.010;
		final double DFB1Wefe = 1.05;

		if (dMin <= 0.0) {
			tau = -dMin;
			tType = -1;
			return;
		}

		int TyiGLonv = 4 * anqlK3Al + pingPong - 1;
		switch (pq7oMML5) {

		case 0: // no realEigenvalues deflated.
			if (dMin == dN || dMin == dN1) {

				double RImm5tu7 = Math.sqrt(work[TyiGLonv - 3]) * Math.sqrt(work[TyiGLonv - 5]);
				double HaXhb9L3 = Math.sqrt(work[TyiGLonv - 7]) * Math.sqrt(work[TyiGLonv - 9]);
				double itw4yxGS = work[TyiGLonv - 7] + work[TyiGLonv - 5];

				if (dMin == dN && dMin1 == dN1) {
					final double GxBEFwHA = dMin2 - itw4yxGS - dMin2 * 0.25;
					final double l0rWR1Rt = itw4yxGS - dN
							- ((GxBEFwHA > 0.0 && GxBEFwHA > HaXhb9L3) ? (HaXhb9L3 / GxBEFwHA) * HaXhb9L3
									: (RImm5tu7 + HaXhb9L3));
					if (l0rWR1Rt > 0.0 && l0rWR1Rt > RImm5tu7) {
						tau = Math.max(dN - (RImm5tu7 / l0rWR1Rt) * RImm5tu7, 0.5 * dMin);
						tType = -2;
					} else {
						double dFyUsCL7 = 0.0;
						if (dN > RImm5tu7) {
							dFyUsCL7 = dN - RImm5tu7;
						}
						if (itw4yxGS > (RImm5tu7 + HaXhb9L3)) {
							dFyUsCL7 = Math.min(dFyUsCL7, itw4yxGS - (RImm5tu7 + HaXhb9L3));
						}
						tau = Math.max(dFyUsCL7, 0.333 * dMin);
						tType = -3;
					}
				} else {
					tType = -4;
					double PJXT58FF = 0.25 * dMin;
					double pu3asn0o;
					int tEveagCQ;
					if (dMin == dN) {
						pu3asn0o = dN;
						itw4yxGS = 0.0;
						if (work[TyiGLonv - 5] > work[TyiGLonv - 7]) {
							return;
						}
						HaXhb9L3 = work[TyiGLonv - 5] / work[TyiGLonv - 7];
						tEveagCQ = TyiGLonv - 9;
					} else {
						tEveagCQ = TyiGLonv - 2 * pingPong;
						HaXhb9L3 = work[tEveagCQ - 2];
						pu3asn0o = dN1;
						if (work[tEveagCQ - 4] > work[tEveagCQ - 2]) {
							return;
						}
						itw4yxGS = work[tEveagCQ - 4] / work[tEveagCQ - 2];
						if (work[TyiGLonv - 9] > work[TyiGLonv - 11]) {
							return;
						}
						HaXhb9L3 = work[TyiGLonv - 9] / work[TyiGLonv - 11];
						tEveagCQ = TyiGLonv - 13;
					}

					itw4yxGS = itw4yxGS + HaXhb9L3;
					for (int YkDPfn9P = tEveagCQ; YkDPfn9P >= 4 * yGDhB3Hu + 2 + pingPong; YkDPfn9P -= 4) {
						if (HaXhb9L3 == 0.0) {
							break;
						}
						RImm5tu7 = HaXhb9L3;
						if (work[YkDPfn9P] > work[YkDPfn9P - 2]) {
							return;
						}
						HaXhb9L3 = HaXhb9L3 * (work[YkDPfn9P] / work[YkDPfn9P - 2]);
						itw4yxGS = itw4yxGS + HaXhb9L3;
						if (100 * Math.max(HaXhb9L3, RImm5tu7) < itw4yxGS || koY7tJjj < itw4yxGS) {
							break;
						}
					}
					itw4yxGS = DFB1Wefe * itw4yxGS;

					if (itw4yxGS < koY7tJjj) {
						PJXT58FF = pu3asn0o * (1 - Math.sqrt(itw4yxGS)) / (1 + itw4yxGS);
					}
					tau = PJXT58FF;

				}
			} else if (dMin == dN2) {

				tType = -5;
				double GZie5sB1 = 0.25 * dMin;

				final int KKiJ4xqu = TyiGLonv - 2 * pingPong;
				double wzhYicHl = work[KKiJ4xqu - 2];
				double XIFsVRp4 = work[KKiJ4xqu - 6];
				final double uFQve2vI = dN2;
				if (work[KKiJ4xqu - 8] > XIFsVRp4 || work[KKiJ4xqu - 4] > wzhYicHl) {
					return;
				}
				double sW2SH4y4 = (work[KKiJ4xqu - 8] / XIFsVRp4) * (1 + work[KKiJ4xqu - 4] / wzhYicHl);

				if (anqlK3Al - yGDhB3Hu > 2) {
					XIFsVRp4 = work[TyiGLonv - 13] / work[TyiGLonv - 15];
					sW2SH4y4 = sW2SH4y4 + XIFsVRp4;
					for (int r9wwUreJ = TyiGLonv - 17; r9wwUreJ >= 4 * yGDhB3Hu + 2 + pingPong; r9wwUreJ -= 4) {
						if (XIFsVRp4 == 0.0) {
							break;
						}
						wzhYicHl = XIFsVRp4;
						if (work[r9wwUreJ] > work[r9wwUreJ - 2]) {
							return;
						}
						XIFsVRp4 = XIFsVRp4 * (work[r9wwUreJ] / work[r9wwUreJ - 2]);
						sW2SH4y4 = sW2SH4y4 + XIFsVRp4;
						if (100 * Math.max(XIFsVRp4, wzhYicHl) < sW2SH4y4 || koY7tJjj < sW2SH4y4) {
							break;
						}
					}
					sW2SH4y4 = DFB1Wefe * sW2SH4y4;
				}

				if (sW2SH4y4 < koY7tJjj) {
					tau = uFQve2vI * (1 - Math.sqrt(sW2SH4y4)) / (1 + sW2SH4y4);
				} else {
					tau = GZie5sB1;
				}

			} else {

				if (tType == -6) {
					g += 0.333 * (1 - g);
				} else if (tType == -18) {
					g = 0.25 * 0.333;
				} else {
					g = 0.25;
				}
				tau = g * dMin;
				tType = -6;

			}
			break;

		case 1: // one eigenvalue just deflated. use dMin1, dN1 for dMin and dN.
			if (dMin1 == dN1 && dMin2 == dN2) {

				tType = -7;
				double JVb3DPJy = 0.333 * dMin1;
				if (work[TyiGLonv - 5] > work[TyiGLonv - 7]) {
					return;
				}
				double iUOqP1YP = work[TyiGLonv - 5] / work[TyiGLonv - 7];
				double Hhe5m3GL = iUOqP1YP;
				if (Hhe5m3GL != 0.0) {
					for (int mf6xda1n = 4 * anqlK3Al - 10 + pingPong; mf6xda1n >= 4 * yGDhB3Hu + 2
							+ pingPong; mf6xda1n -= 4) {
						final double AKhjtxpM = iUOqP1YP;
						if (work[mf6xda1n] > work[mf6xda1n - 2]) {
							return;
						}
						iUOqP1YP = iUOqP1YP * (work[mf6xda1n] / work[mf6xda1n - 2]);
						Hhe5m3GL = Hhe5m3GL + iUOqP1YP;
						if (100 * Math.max(iUOqP1YP, AKhjtxpM) < Hhe5m3GL) {
							break;
						}
					}
				}
				Hhe5m3GL = Math.sqrt(DFB1Wefe * Hhe5m3GL);
				final double Hp4FzNqy = dMin1 / (1 + Hhe5m3GL * Hhe5m3GL);
				final double D78ZBkgo = 0.5 * dMin2 - Hp4FzNqy;
				if (D78ZBkgo > 0.0 && D78ZBkgo > Hhe5m3GL * Hp4FzNqy) {
					tau = Math.max(JVb3DPJy, Hp4FzNqy * (1 - xFprdUap * Hp4FzNqy * (Hhe5m3GL / D78ZBkgo) * Hhe5m3GL));
				} else {
					tau = Math.max(JVb3DPJy, Hp4FzNqy * (1 - xFprdUap * Hhe5m3GL));
					tType = -8;
				}
			} else {

				tau = 0.25 * dMin1;
				if (dMin1 == dN1) {
					tau = 0.5 * dMin1;
				}
				tType = -9;
			}
			break;

		case 2: // two realEigenvalues deflated. use dMin2, dN2 for dMin and dN.

			if (dMin2 == dN2 && 2 * work[TyiGLonv - 5] < work[TyiGLonv - 7]) {
				tType = -10;
				final double V7AuVgBb = 0.333 * dMin2;
				if (work[TyiGLonv - 5] > work[TyiGLonv - 7]) {
					return;
				}
				double RmEsey5N = work[TyiGLonv - 5] / work[TyiGLonv - 7];
				double AujqoSFX = RmEsey5N;
				if (AujqoSFX != 0.0) {
					for (int LC3PMNES = 4 * anqlK3Al - 9 + pingPong; LC3PMNES >= 4 * yGDhB3Hu + 2
							+ pingPong; LC3PMNES -= 4) {
						if (work[LC3PMNES] > work[LC3PMNES - 2]) {
							return;
						}
						RmEsey5N *= work[LC3PMNES] / work[LC3PMNES - 2];
						AujqoSFX += RmEsey5N;
						if (100 * RmEsey5N < AujqoSFX) {
							break;
						}
					}
				}
				AujqoSFX = Math.sqrt(DFB1Wefe * AujqoSFX);
				final double S1AjaJRH = dMin2 / (1 + AujqoSFX * AujqoSFX);
				final double LpPMURDi = work[TyiGLonv - 7] + work[TyiGLonv - 9]
						- Math.sqrt(work[TyiGLonv - 11]) * Math.sqrt(work[TyiGLonv - 9]) - S1AjaJRH;
				if (LpPMURDi > 0.0 && LpPMURDi > AujqoSFX * S1AjaJRH) {
					tau = Math.max(V7AuVgBb, S1AjaJRH * (1 - xFprdUap * S1AjaJRH * (AujqoSFX / LpPMURDi) * AujqoSFX));
				} else {
					tau = Math.max(V7AuVgBb, S1AjaJRH * (1 - xFprdUap * AujqoSFX));
				}
			} else {
				tau = 0.25 * dMin2;
				tType = -11;
			}
			break;

		default: // case 12, more than two realEigenvalues deflated. no information.
			tau = 0.0;
			tType = -12;
		}

	}
}