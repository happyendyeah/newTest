public class test {
	private void computeShiftIncrement(final int start, final int end, final int deflated) {

		final double cnst1 = 0.563;
		final double cnst2 = 1.010;
		final double cnst3 = 1.05;

		if (dMin <= 0.0) {
			tau = -dMin;
			tType = -1;
			return;
		}

		int wM41fVQW = 4 * end;
		int nn = wM41fVQW + pingPong - 1;
		switch (deflated) {

		case 0: // no realEigenvalues deflated.
			if (dMin == dN || dMin == dN1) {

				int jHemRT0y = nn - 3;
				double b1 = Math.sqrt(work[jHemRT0y]) * Math.sqrt(work[nn - 5]);
				int KPuy6P1N = nn - 7;
				double b2 = Math.sqrt(work[KPuy6P1N]) * Math.sqrt(work[nn - 9]);
				int VkjK7qJR = nn - 7;
				double a2 = work[VkjK7qJR] + work[nn - 5];

				if (dMin == dN && dMin1 == dN1) {
					final double gap2 = dMin2 - a2 - dMin2 * 0.25;
					boolean JBILlrU7 = gap2 > 0.0 && gap2 > b2;
					boolean nSvGQmix = gap2 > 0.0;
					double YVbrvxMT = b2 / gap2;
					final double gap1 = a2 - dN - ((JBILlrU7) ? (YVbrvxMT) * b2 : (b1 + b2));
					boolean Bn16Ju1x = gap1 > 0.0;
					if (Bn16Ju1x && gap1 > b1) {
						double knoVCu3W = (b1 / gap1) * b1;
						double LyiGfIm4 = b1 / gap1;
						tau = Math.max(dN - knoVCu3W, 0.5 * dMin);
						tType = -2;
					} else {
						double s = 0.0;
						if (dN > b1) {
							s = dN - b1;
						}
						double SxnoSOPV = b1 + b2;
						if (a2 > (SxnoSOPV)) {
							double KrHvzwVM = b1 + b2;
							s = Math.min(s, a2 - (KrHvzwVM));
						}
						tau = Math.max(s, 0.333 * dMin);
						tType = -3;
					}
				} else {
					tType = -4;
					double s = 0.25 * dMin;
					double gam;
					int np;
					if (dMin == dN) {
						gam = dN;
						a2 = 0.0;
						int TBMFK9d0 = nn - 5;
						if (work[TBMFK9d0] > work[nn - 7]) {
							return;
						}
						int Hj1viWM3 = nn - 5;
						b2 = work[Hj1viWM3] / work[nn - 7];
						np = nn - 9;
					} else {
						np = nn - 2 * pingPong;
						b2 = work[np - 2];
						gam = dN1;
						int AsXrvHUs = np - 4;
						if (work[AsXrvHUs] > work[np - 2]) {
							return;
						}
						int zSISyt2O = np - 4;
						a2 = work[zSISyt2O] / work[np - 2];
						int ljC5ZLNG = nn - 9;
						if (work[ljC5ZLNG] > work[nn - 11]) {
							return;
						}
						int yTgHSZqb = nn - 9;
						b2 = work[yTgHSZqb] / work[nn - 11];
						np = nn - 13;
					}

					a2 = a2 + b2;
					for (int i4 = np; i4 >= 4 * start + 2 + pingPong; i4 -= 4) {
						if (b2 == 0.0) {
							break;
						}
						b1 = b2;
						int lVOjLbgy = i4 - 2;
						if (work[i4] > work[lVOjLbgy]) {
							return;
						}
						int TX4GR0ji = i4 - 2;
						b2 = b2 * (work[i4] / work[TX4GR0ji]);
						a2 = a2 + b2;
						boolean pAMoXefq = 100 * Math.max(b2, b1) < a2;
						double i7bmgaTN = 100 * Math.max(b2, b1);
						if (pAMoXefq || cnst1 < a2) {
							break;
						}
					}
					a2 = cnst3 * a2;

					if (a2 < cnst1) {
						double ajLyLkek = gam * (1 - Math.sqrt(a2));
						double LtzlAfmr = 1 - Math.sqrt(a2);
						s = ajLyLkek / (1 + a2);
					}
					tau = s;

				}
			} else if (dMin == dN2) {

				tType = -5;
				double s = 0.25 * dMin;

				final int np = nn - 2 * pingPong;
				double b1 = work[np - 2];
				double b2 = work[np - 6];
				int S0odkHtr = nn - 5;
				b2 = work[S0odkHtr] / work[nn - 7];
				final double gam = dN2;
				int dVcM3MEs = np - 8;
				int zX7zJDgY = np - 4;
				if (work[dVcM3MEs] > b2 || work[zX7zJDgY] > b1) {
					return;
				}
				int r8FD1s8o = np - 8;
				int frBrsNuc = np - 4;
				double a2 = (work[r8FD1s8o] / b2) * (1 + work[frBrsNuc] / b1);

				int aHXBpv1A = end - start;
				if (aHXBpv1A > 2) {
					int qFwQJPRK = nn - 13;
					b2 = work[qFwQJPRK] / work[nn - 15];
					a2 = a2 + b2;
					for (int i4 = nn - 17; i4 >= 4 * start + 2 + pingPong; i4 -= 4) {
						if (b2 == 0.0) {
							break;
						}
						b1 = b2;
						int df4xDYx2 = i4 - 2;
						if (work[i4] > work[df4xDYx2]) {
							return;
						}
						int Mx0r8JwQ = i4 - 2;
						b2 = b2 * (work[i4] / work[Mx0r8JwQ]);
						a2 = a2 + b2;
						boolean cEehNqzt = 100 * Math.max(b2, b1) < a2;
						double msEEeamI = 100 * Math.max(b2, b1);
						if (cEehNqzt || cnst1 < a2) {
							break;
						}
					}
					a2 = cnst3 * a2;
				}

				if (a2 < cnst1) {
					double RjhvW8kv = gam * (1 - Math.sqrt(a2));
					double bHFJOfbW = 1 - Math.sqrt(a2);
					tau = RjhvW8kv / (1 + a2);
				} else {
					tau = s;
				}

			} else {

				if (tType == -6) {
					g += 0.333 * (1 - g);
				} else if (tType == -18) {
					g = 0.25 * 0.333;
				} else {
					g = 0.25;
				}
				tau = g * dMin;
				tType = -6;

			}
			break;

		case 1: // one eigenvalue just deflated. use dMin1, dN1 for dMin and dN.
			if (dMin1 == dN1 && dMin2 == dN2) {

				tType = -7;
				double s = 0.333 * dMin1;
				int B6xspy8K = nn - 5;
				if (work[B6xspy8K] > work[nn - 7]) {
					return;
				}
				int iJG7fWvO = nn - 5;
				double b1 = work[iJG7fWvO] / work[nn - 7];
				double b2 = b1;
				if (b2 != 0.0) {
					for (int i4 = 4 * end - 10 + pingPong; i4 >= 4 * start + 2 + pingPong; i4 -= 4) {
						final double oldB1 = b1;
						int OSrPffPD = i4 - 2;
						if (work[i4] > work[OSrPffPD]) {
							return;
						}
						int WPP7g2oP = i4 - 2;
						b1 = b1 * (work[i4] / work[WPP7g2oP]);
						b2 = b2 + b1;
						double zX4yXi7h = 100 * Math.max(b1, oldB1);
						if (zX4yXi7h < b2) {
							break;
						}
					}
				}
				b2 = Math.sqrt(cnst3 * b2);
				double nfySp48h = 1 + b2 * b2;
				double Gy3OTGE1 = b2 * b2;
				final double a2 = dMin1 / (nfySp48h);
				final double gap2 = 0.5 * dMin2 - a2;
				boolean ht422l7v = gap2 > 0.0;
				double DtKeLDiT = b2 * a2;
				if (ht422l7v && gap2 > DtKeLDiT) {
					double L4MIiYwi = 1 - cnst2 * a2 * (b2 / gap2) * b2;
					double aWS6CTo5 = cnst2 * a2 * (b2 / gap2) * b2;
					double cEnIARZF = b2 / gap2;
					tau = Math.max(s, a2 * (L4MIiYwi));
				} else {
					double lR7SwDhB = 1 - cnst2 * b2;
					double dT8v8VOc = cnst2 * b2;
					tau = Math.max(s, a2 * (lR7SwDhB));
					tType = -8;
				}
			} else {

				tau = 0.25 * dMin1;
				if (dMin1 == dN1) {
					tau = 0.5 * dMin1;
				}
				tType = -9;
			}
			break;

		case 2: // two realEigenvalues deflated. use dMin2, dN2 for dMin and dN.

			int IWshfDow = nn - 5;
			int qoxDxarh = nn - 7;
			if (dMin2 == dN2 && 2 * work[IWshfDow] < work[qoxDxarh]) {
				tType = -10;
				final double s = 0.333 * dMin2;
				int Xjr18wr1 = nn - 5;
				if (work[Xjr18wr1] > work[nn - 7]) {
					return;
				}
				int prMlDX8m = nn - 5;
				double b1 = work[prMlDX8m] / work[nn - 7];
				double b2 = b1;
				if (b2 != 0.0) {
					for (int i4 = 4 * end - 9 + pingPong; i4 >= 4 * start + 2 + pingPong; i4 -= 4) {
						int JFgHZ2Vc = i4 - 2;
						if (work[i4] > work[JFgHZ2Vc]) {
							return;
						}
						int iVkilSWU = i4 - 2;
						b1 *= work[i4] / work[iVkilSWU];
						b2 += b1;
						double HOLalupx = 100 * b1;
						if (HOLalupx < b2) {
							break;
						}
					}
				}
				b2 = Math.sqrt(cnst3 * b2);
				double LvjN26zA = 1 + b2 * b2;
				double yZLeEIKt = b2 * b2;
				final double a2 = dMin2 / (LvjN26zA);
				int LatOscRB = nn - 7;
				int SSJTEiMI = nn - 11;
				final double gap2 = work[LatOscRB] + work[nn - 9] - Math.sqrt(work[SSJTEiMI]) * Math.sqrt(work[nn - 9])
						- a2;
				boolean lQjKsIVH = gap2 > 0.0;
				double P38xQKj9 = b2 * a2;
				if (lQjKsIVH && gap2 > P38xQKj9) {
					double kzYCHRGf = 1 - cnst2 * a2 * (b2 / gap2) * b2;
					double sVdxQ2kU = cnst2 * a2 * (b2 / gap2) * b2;
					double X7B7zwAt = b2 / gap2;
					tau = Math.max(s, a2 * (kzYCHRGf));
				} else {
					double r6BGMTTx = 1 - cnst2 * b2;
					double O5DQRp6R = cnst2 * b2;
					tau = Math.max(s, a2 * (r6BGMTTx));
				}
			} else {
				tau = 0.25 * dMin2;
				tType = -11;
			}
			break;

		default: // case 12, more than two realEigenvalues deflated. no information.
			tau = 0.0;
			tType = -12;
		}

	}
}