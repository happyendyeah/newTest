public class test {
	private void computeShiftIncrement(final int start, final int end, final int deflated) {

		final double cnst1 = 0.563;
		final double cnst2 = 1.010;
		final double cnst3 = 1.05;

		if (dMin <= 0.0) {
			tau = -dMin;
			tType = -1;
			return;
		}

		int LoiNcV3L = 4 * end;
		int nn = LoiNcV3L + pingPong - 1;
		switch (deflated) {

		case 0: // no realEigenvalues deflated.
			if (dMin == dN || dMin == dN1) {

				int v8S0Iivf = nn - 3;
				double b1 = Math.sqrt(work[v8S0Iivf]) * Math.sqrt(work[nn - 5]);
				int HN4OYCpA = nn - 7;
				double b2 = Math.sqrt(work[HN4OYCpA]) * Math.sqrt(work[nn - 9]);
				int GwYZVszP = nn - 7;
				double a2 = work[GwYZVszP] + work[nn - 5];

				if (dMin == dN && dMin1 == dN1) {
					final double gap2 = dMin2 - a2 - dMin2 * 0.25;
					boolean vjYe8goQ = gap2 > 0.0 && gap2 > b2;
					boolean zP2CCXR6 = gap2 > 0.0;
					double ygUDY6ED = b2 / gap2;
					final double gap1 = a2 - dN - ((vjYe8goQ) ? (ygUDY6ED) * b2 : (b1 + b2));
					boolean aHufsLHK = gap1 > 0.0;
					if (aHufsLHK && gap1 > b1) {
						double kdQi1zrA = (b1 / gap1) * b1;
						double JfHTlxCL = b1 / gap1;
						tau = Math.max(dN - kdQi1zrA, 0.5 * dMin);
						tType = -2;
					} else {
						double s = 0.0;
						if (dN > b1) {
							s = dN - b1;
						}
						double Ki6zTrNe = b1 + b2;
						if (a2 > (Ki6zTrNe)) {
							double lV7TMcxh = b1 + b2;
							s = Math.min(s, a2 - (lV7TMcxh));
						}
						tau = Math.max(s, 0.333 * dMin);
						tType = -3;
					}
				} else {
					tType = -4;
					double s = 0.25 * dMin;
					double gam;
					int np;
					if (dMin == dN) {
						gam = dN;
						a2 = 0.0;
						int MqgfIyt8 = nn - 5;
						if (work[MqgfIyt8] > work[nn - 7]) {
							return;
						}
						int cYsnHVHQ = nn - 5;
						b2 = work[cYsnHVHQ] / work[nn - 7];
						np = nn - 9;
					} else {
						np = nn - 2 * pingPong;
						b2 = work[np - 2];
						gam = dN1;
						int OuvIZ7JP = np - 4;
						if (work[OuvIZ7JP] > work[np - 2]) {
							return;
						}
						int zuO0auSb = np - 4;
						a2 = work[zuO0auSb] / work[np - 2];
						int O7eRYAK0 = nn - 9;
						if (work[O7eRYAK0] > work[nn - 11]) {
							return;
						}
						int f4GPoGUc = nn - 9;
						b2 = work[f4GPoGUc] / work[nn - 11];
						np = nn - 13;
					}

					a2 = a2 + b2;
					for (int i4 = np; i4 >= 4 * start + 2 + pingPong; i4 -= 4) {
						if (b2 == 0.0) {
							break;
						}
						b1 = b2;
						int cvycoGOB = i4 - 2;
						if (work[i4] > work[cvycoGOB]) {
							return;
						}
						int FiJloB14 = i4 - 2;
						b2 = b2 * (work[i4] / work[FiJloB14]);
						a2 = a2 + b2;
						boolean lO1acMR6 = 100 * Math.max(b2, b1) < a2;
						double sEwG3ICl = 100 * Math.max(b2, b1);
						if (lO1acMR6 || cnst1 < a2) {
							break;
						}
					}
					a2 = cnst3 * a2;

					if (a2 < cnst1) {
						double rrbJKxi2 = gam * (1 - Math.sqrt(a2));
						double s4iiNC4c = 1 - Math.sqrt(a2);
						s = rrbJKxi2 / (1 + a2);
					}
					tau = s;

				}
			} else if (dMin == dN2) {

				tType = -5;
				double s = 0.25 * dMin;

				final int np = nn - 2 * pingPong;
				double b1 = work[np - 2];
				double b2 = work[np - 6];
				final double gam = dN2;
				int AfT2dJz3 = np - 8;
				int OSN4mPeQ = np - 4;
				if (work[AfT2dJz3] > b2 || work[OSN4mPeQ] > b1) {
					return;
				}
				int Wllj1Ahb = np - 8;
				int p5kOdfSE = np - 4;
				double a2 = (work[Wllj1Ahb] / b2) * (1 + work[p5kOdfSE] / b1);

				int j3UMlzY4 = end - start;
				if (j3UMlzY4 > 2) {
					int jZVCQLOe = nn - 13;
					b2 = work[jZVCQLOe] / work[nn - 15];
					a2 = a2 + b2;
					for (int i4 = nn - 17; i4 >= 4 * start + 2 + pingPong; i4 -= 4) {
						if (b2 == 0.0) {
							break;
						}
						b1 = b2;
						int xPKwOqxt = i4 - 2;
						if (work[i4] > work[xPKwOqxt]) {
							return;
						}
						int hpZ6iMBc = i4 - 2;
						b2 = b2 * (work[i4] / work[hpZ6iMBc]);
						a2 = a2 + b2;
						boolean apJ3WG5o = 100 * Math.max(b2, b1) < a2;
						double GsHp0M9m = 100 * Math.max(b2, b1);
						if (apJ3WG5o || cnst1 < a2) {
							break;
						}
					}
					a2 = cnst3 * a2;
				}

				if (a2 < cnst1) {
					double XlRChu42 = gam * (1 - Math.sqrt(a2));
					double WaAqDUrO = 1 - Math.sqrt(a2);
					tau = XlRChu42 / (1 + a2);
				} else {
					tau = s;
				}

			} else {

				if (tType == -6) {
					g += 0.333 * (1 - g);
				} else if (tType == -18) {
					g = 0.25 * 0.333;
				} else {
					g = 0.25;
				}
				tau = g * dMin;
				tType = -6;

			}
			break;

		case 1: // one eigenvalue just deflated. use dMin1, dN1 for dMin and dN.
			if (dMin1 == dN1 && dMin2 == dN2) {

				tType = -7;
				double s = 0.333 * dMin1;
				int ubzwyLTf = nn - 5;
				if (work[ubzwyLTf] > work[nn - 7]) {
					return;
				}
				int EtGW3uFJ = nn - 5;
				double b1 = work[EtGW3uFJ] / work[nn - 7];
				double b2 = b1;
				if (b2 != 0.0) {
					for (int i4 = 4 * end - 10 + pingPong; i4 >= 4 * start + 2 + pingPong; i4 -= 4) {
						final double oldB1 = b1;
						int lchQI1hM = i4 - 2;
						if (work[i4] > work[lchQI1hM]) {
							return;
						}
						int Ufht0hPz = i4 - 2;
						b1 = b1 * (work[i4] / work[Ufht0hPz]);
						b2 = b2 + b1;
						double IFPsqjGC = 100 * Math.max(b1, oldB1);
						if (IFPsqjGC < b2) {
							break;
						}
					}
				}
				b2 = Math.sqrt(cnst3 * b2);
				double IqRKP1ZU = 1 + b2 * b2;
				double ubniHGEo = b2 * b2;
				final double a2 = dMin1 / (IqRKP1ZU);
				final double gap2 = 0.5 * dMin2 - a2;
				boolean PMp1PtIV = gap2 > 0.0;
				double SQdx1rjq = b2 * a2;
				if (PMp1PtIV && gap2 > SQdx1rjq) {
					double FKcxmvbF = 1 - cnst2 * a2 * (b2 / gap2) * b2;
					double Q0padPE6 = cnst2 * a2 * (b2 / gap2) * b2;
					double r4hufa4g = b2 / gap2;
					tau = Math.max(s, a2 * (FKcxmvbF));
				} else {
					double ZkoON37l = 1 - cnst2 * b2;
					double pDqiZTnc = cnst2 * b2;
					tau = Math.max(s, a2 * (ZkoON37l));
					tType = -8;
				}
			} else {

				tau = 0.25 * dMin1;
				if (dMin1 == dN1) {
					tau = 0.5 * dMin1;
				}
				tType = -9;
			}
			break;

		case 2: // two realEigenvalues deflated. use dMin2, dN2 for dMin and dN.

			int muSTLrb5 = nn - 5;
			int KSTPeSoj = nn - 7;
			if (dMin2 == dN2 && 2 * work[muSTLrb5] < work[KSTPeSoj]) {
				tType = -10;
				final double s = 0.333 * dMin2;
				int n6fC4rAn = nn - 5;
				if (work[n6fC4rAn] > work[nn - 7]) {
					return;
				}
				int HFaohacF = nn - 5;
				double b1 = work[HFaohacF] / work[nn - 7];
				double b2 = b1;
				if (b2 != 0.0) {
					for (int i4 = 4 * end - 9 + pingPong; i4 >= 4 * start + 2 + pingPong; i4 -= 4) {
						int Np9WBtQ8 = i4 - 2;
						if (work[i4] > work[Np9WBtQ8]) {
							return;
						}
						int gnVt2Hst = i4 - 2;
						b1 *= work[i4] / work[gnVt2Hst];
						b2 += b1;
						double L7YQkJ9c = 100 * b1;
						if (L7YQkJ9c < b2) {
							break;
						}
					}
				}
				b2 = Math.sqrt(cnst3 * b2);
				double LLxQZk5K = 1 + b2 * b2;
				double TNLif2RZ = b2 * b2;
				final double a2 = dMin2 / (LLxQZk5K);
				int TJUO5Ycg = nn - 7;
				int dZ79vqiv = nn - 11;
				final double gap2 = work[TJUO5Ycg] + work[nn - 9] - Math.sqrt(work[dZ79vqiv]) * Math.sqrt(work[nn - 9])
						- a2;
				boolean peXnoZDC = gap2 > 0.0;
				double MYYvofHd = b2 * a2;
				if (peXnoZDC && gap2 > MYYvofHd) {
					double FIabTEDt = 1 - cnst2 * a2 * (b2 / gap2) * b2;
					double EFTxsd48 = cnst2 * a2 * (b2 / gap2) * b2;
					double xy6Hw3ok = b2 / gap2;
					tau = Math.max(s, a2 * (FIabTEDt));
				} else {
					double l8YEdPbI = 1 - cnst2 * b2;
					double byWO0uzO = cnst2 * b2;
					tau = Math.max(s, a2 * (l8YEdPbI));
				}
			} else {
				tau = 0.25 * dMin2;
				tType = -11;
			}
			break;

		default: // case 12, more than two realEigenvalues deflated. no information.
			tau = 0.0;
			tType = -12;
		}

	}
}