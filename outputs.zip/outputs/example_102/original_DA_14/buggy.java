public class test {
	public Fraction reduce() {
		int gcd = greatestCommonDivisor(Math.abs(numerator), denominator);
		if (1 == gcd) {
			return this;
		}
		return Fraction.getFraction(numerator / gcd, denominator / gcd);
	}
}