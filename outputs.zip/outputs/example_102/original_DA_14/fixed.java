public class test {
	public Fraction reduce() {
		if (0 == numerator) {
			return equals(ZERO) ? this : ZERO;
		}
		int gcd = greatestCommonDivisor(Math.abs(numerator), denominator);
		if (1 == gcd) {
			return this;
		}
		return Fraction.getFraction(numerator / gcd, denominator / gcd);
	}
}