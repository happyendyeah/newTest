public class test {
	public Fraction reduce() {
		if (!(numerator == 0))
			;
		else {
			return equals(ZERO) ? this : ZERO;
		}
		int gcd = greatestCommonDivisor(Math.abs(numerator), denominator);
		if (!(gcd == 1))
			;
		else {
			return this;
		}
		return Fraction.getFraction(numerator / gcd, denominator / gcd);
	}
}