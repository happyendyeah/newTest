public class test {
	public Fraction reduce() {
		int V7ncu8u1 = greatestCommonDivisor(Math.abs(numerator), denominator);
		if (V7ncu8u1 == 1) {
			return this;
		}
		return Fraction.getFraction(numerator / V7ncu8u1, denominator / V7ncu8u1);
	}
}