public class test {
	Element insert(final Token.StartTag OMsHq521) {

		if (OMsHq521.isSelfClosing()) {
			Element rxB7YPBN = insertEmpty(OMsHq521);
			stack.add(rxB7YPBN);
			tokeniser.transition(TokeniserState.Data); // handles <script />, otherwise needs breakout steps from script data
			tokeniser.emit(emptyEnd.reset().name(rxB7YPBN.tagName())); // ensure we get out of whatever state we are in. emitted for yielded processing
			return rxB7YPBN;
		}

		Element mX1o7N9w = new Element(Tag.valueOf(OMsHq521.name(), settings), baseUri,
				settings.normalizeAttributes(OMsHq521.attributes));
		insert(mX1o7N9w);
		return mX1o7N9w;
	}
}