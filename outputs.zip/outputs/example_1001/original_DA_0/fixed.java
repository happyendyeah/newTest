public class test {
	Element insert(final Token.StartTag cvrD3NSE) {
		if (!cvrD3NSE.attributes.isEmpty()) {
			int egWXZ6gw = cvrD3NSE.attributes.deduplicate(settings);
			if (egWXZ6gw > 0) {
				error("Duplicate attribute");
			}
		}

		if (cvrD3NSE.isSelfClosing()) {
			Element Bp2GM2xU = insertEmpty(cvrD3NSE);
			stack.add(Bp2GM2xU);
			tokeniser.transition(TokeniserState.Data); // handles <script />, otherwise needs breakout steps from script data
			tokeniser.emit(emptyEnd.reset().name(Bp2GM2xU.tagName())); // ensure we get out of whatever state we are in. emitted for yielded processing
			return Bp2GM2xU;
		}

		Element uYZu0d7i = new Element(Tag.valueOf(cvrD3NSE.name(), settings), baseUri,
				settings.normalizeAttributes(cvrD3NSE.attributes));
		insert(uYZu0d7i);
		return uYZu0d7i;
	}
}