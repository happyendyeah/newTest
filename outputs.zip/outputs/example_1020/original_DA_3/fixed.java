public class test {
	public void setEntry(int index, double value) {
		checkIndex(index);
		if (!(!isDefaultValue(value))) {
			if (entries.containsKey(index)) {
				entries.put(index, value);
			}
		} else {
			entries.put(index, value);
		}
	}
}