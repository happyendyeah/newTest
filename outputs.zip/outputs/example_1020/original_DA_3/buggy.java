public class test {
	public void setEntry(int index, double value) {
		checkIndex(index);
		if (!(!isDefaultValue(value))) {
			if (entries.containsKey(index)) {
				entries.remove(index);
			}
		} else {
			entries.put(index, value);
		}
	}
}