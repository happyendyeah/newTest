public class test {
	public void setEntry(int XT8SYroG, double qwf8PfWI) {
		checkIndex(XT8SYroG);
		if (!isDefaultValue(qwf8PfWI)) {
			entries.put(XT8SYroG, qwf8PfWI);
		} else if (entries.containsKey(XT8SYroG)) {
			entries.remove(XT8SYroG);
		}
	}
}