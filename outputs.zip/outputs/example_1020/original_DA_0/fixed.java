public class test {
	public void setEntry(int mMwhnBTP, double JRFoxzfy) {
		checkIndex(mMwhnBTP);
		if (!isDefaultValue(JRFoxzfy)) {
			entries.put(mMwhnBTP, JRFoxzfy);
		} else if (entries.containsKey(mMwhnBTP)) {
			entries.put(mMwhnBTP, JRFoxzfy);
		}
	}
}