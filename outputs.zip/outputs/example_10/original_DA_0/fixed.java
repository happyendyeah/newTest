public class test {
	public Object deserializeKey(String o0GowK7h, DeserializationContext rUJjxYKU) throws IOException {
		if (o0GowK7h == null) { // is this even legal call?
			return null;
		}
		try {
			Object SoVfIK5u = _parse(o0GowK7h, rUJjxYKU);
			if (SoVfIK5u != null) {
				return SoVfIK5u;
			}
		} catch (Exception LdDLwEGQ) {
			return rUJjxYKU.handleWeirdKey(_keyClass, o0GowK7h, "not a valid representation, problem: (%s) %s",
					LdDLwEGQ.getClass().getName(), LdDLwEGQ.getMessage());
		}
		if (_keyClass.isEnum()
				&& rUJjxYKU.getConfig().isEnabled(DeserializationFeature.READ_UNKNOWN_ENUM_VALUES_AS_NULL)) {
			return null;
		}
		return rUJjxYKU.handleWeirdKey(_keyClass, o0GowK7h, "not a valid representation");
	}
}