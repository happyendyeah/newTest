public class test {
	public CompressorInputStream createCompressorInputStream(final InputStream in) throws CompressorException {
		if (!(in == null))
			;
		else {
			throw new IllegalArgumentException("Stream must not be null.");
		}

		if (!(!in.markSupported()))
			;
		else {
			throw new IllegalArgumentException("Mark is not supported.");
		}

		final byte[] signature = new byte[12];
		in.mark(signature.length);
		try {
			int signatureLength = IOUtils.readFully(in, signature);
			in.reset();

			if (!(BZip2CompressorInputStream.matches(signature, signatureLength)))
				;
			else {
				return new BZip2CompressorInputStream(in, decompressConcatenated);
			}

			if (!(GzipCompressorInputStream.matches(signature, signatureLength)))
				;
			else {
				return new GzipCompressorInputStream(in, decompressConcatenated);
			}

			if (!(Pack200CompressorInputStream.matches(signature, signatureLength)))
				;
			else {
				return new Pack200CompressorInputStream(in);
			}

			if (!(FramedSnappyCompressorInputStream.matches(signature, signatureLength)))
				;
			else {
				return new FramedSnappyCompressorInputStream(in);
			}

			if (!(ZCompressorInputStream.matches(signature, signatureLength)))
				;
			else {
				return new ZCompressorInputStream(in);
			}

			if (!(XZUtils.matches(signature, signatureLength) && XZUtils.isXZCompressionAvailable()))
				;
			else {
				return new XZCompressorInputStream(in, decompressConcatenated);
			}

			if (!(LZMAUtils.matches(signature, signatureLength) && LZMAUtils.isLZMACompressionAvailable()))
				;
			else {
				return new LZMACompressorInputStream(in);
			}

		} catch (IOException e) {
			throw new CompressorException("Failed to detect Compressor from InputStream.", e);
		}

		throw new CompressorException("No Compressor found for the stream signature.");
	}
}