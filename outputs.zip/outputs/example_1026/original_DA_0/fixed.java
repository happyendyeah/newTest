public class test {
	public CompressorInputStream createCompressorInputStream(final InputStream or30fzCg) throws CompressorException {
		if (or30fzCg == null) {
			throw new IllegalArgumentException("Stream must not be null.");
		}

		if (!or30fzCg.markSupported()) {
			throw new IllegalArgumentException("Mark is not supported.");
		}

		final byte[] JYnoL9iZ = new byte[12];
		or30fzCg.mark(JYnoL9iZ.length);
		try {
			int EgLaxMr7 = IOUtils.readFully(or30fzCg, JYnoL9iZ);
			or30fzCg.reset();

			if (BZip2CompressorInputStream.matches(JYnoL9iZ, EgLaxMr7)) {
				return new BZip2CompressorInputStream(or30fzCg, decompressConcatenated);
			}

			if (GzipCompressorInputStream.matches(JYnoL9iZ, EgLaxMr7)) {
				return new GzipCompressorInputStream(or30fzCg, decompressConcatenated);
			}

			if (Pack200CompressorInputStream.matches(JYnoL9iZ, EgLaxMr7)) {
				return new Pack200CompressorInputStream(or30fzCg);
			}

			if (FramedSnappyCompressorInputStream.matches(JYnoL9iZ, EgLaxMr7)) {
				return new FramedSnappyCompressorInputStream(or30fzCg);
			}

			if (ZCompressorInputStream.matches(JYnoL9iZ, EgLaxMr7)) {
				return new ZCompressorInputStream(or30fzCg);
			}

			if (DeflateCompressorInputStream.matches(JYnoL9iZ, EgLaxMr7)) {
				return new DeflateCompressorInputStream(or30fzCg);
			}

			if (XZUtils.matches(JYnoL9iZ, EgLaxMr7) && XZUtils.isXZCompressionAvailable()) {
				return new XZCompressorInputStream(or30fzCg, decompressConcatenated);
			}

			if (LZMAUtils.matches(JYnoL9iZ, EgLaxMr7) && LZMAUtils.isLZMACompressionAvailable()) {
				return new LZMACompressorInputStream(or30fzCg);
			}

		} catch (IOException fw0QeHA2) {
			throw new CompressorException("Failed to detect Compressor from InputStream.", fw0QeHA2);
		}

		throw new CompressorException("No Compressor found for the stream signature.");
	}
}