public class test {
	public CompressorInputStream createCompressorInputStream(final InputStream P95l2Hok) throws CompressorException {
		if (P95l2Hok == null) {
			throw new IllegalArgumentException("Stream must not be null.");
		}

		if (!P95l2Hok.markSupported()) {
			throw new IllegalArgumentException("Mark is not supported.");
		}

		final byte[] sGYVcIhW = new byte[12];
		P95l2Hok.mark(sGYVcIhW.length);
		try {
			int M2w4DVYN = IOUtils.readFully(P95l2Hok, sGYVcIhW);
			P95l2Hok.reset();

			if (BZip2CompressorInputStream.matches(sGYVcIhW, M2w4DVYN)) {
				return new BZip2CompressorInputStream(P95l2Hok, decompressConcatenated);
			}

			if (GzipCompressorInputStream.matches(sGYVcIhW, M2w4DVYN)) {
				return new GzipCompressorInputStream(P95l2Hok, decompressConcatenated);
			}

			if (Pack200CompressorInputStream.matches(sGYVcIhW, M2w4DVYN)) {
				return new Pack200CompressorInputStream(P95l2Hok);
			}

			if (FramedSnappyCompressorInputStream.matches(sGYVcIhW, M2w4DVYN)) {
				return new FramedSnappyCompressorInputStream(P95l2Hok);
			}

			if (ZCompressorInputStream.matches(sGYVcIhW, M2w4DVYN)) {
				return new ZCompressorInputStream(P95l2Hok);
			}

			if (XZUtils.matches(sGYVcIhW, M2w4DVYN) && XZUtils.isXZCompressionAvailable()) {
				return new XZCompressorInputStream(P95l2Hok, decompressConcatenated);
			}

			if (LZMAUtils.matches(sGYVcIhW, M2w4DVYN) && LZMAUtils.isLZMACompressionAvailable()) {
				return new LZMACompressorInputStream(P95l2Hok);
			}

		} catch (IOException YcQfASru) {
			throw new CompressorException("Failed to detect Compressor from InputStream.", YcQfASru);
		}

		throw new CompressorException("No Compressor found for the stream signature.");
	}
}