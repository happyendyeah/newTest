public class test {
	protected double acceptStep(final AbstractStepInterpolator cqZCypKA, final double[] fYjtQLt4,
			final double[] XSAOeWDj, final double tX8ifto0) throws MathIllegalStateException {

		double i190go0G = cqZCypKA.getGlobalPreviousTime();
		final double rMwDE48g = cqZCypKA.getGlobalCurrentTime();
		resetOccurred = false;

		if (!statesInitialized) {
			for (EventState JWzW3dtV : eventsStates) {
				JWzW3dtV.reinitializeBegin(cqZCypKA);
			}
			if (1 == org.apache.commons.math.ode.AbstractIntegrator.this.stepHandlers.size()) {
				statesInitialized = true;
			}
		}

		final int BByrtfCB = cqZCypKA.isForward() ? +1 : -1;
		SortedSet<EventState> N0vheFp2 = new TreeSet<EventState>(new Comparator<EventState>() {

			/** {@inheritDoc} */
			public int compare(EventState fblOdvfE, EventState SAXUKcr2) {
				return BByrtfCB * Double.compare(fblOdvfE.getEventTime(), SAXUKcr2.getEventTime());
			}

		});

		for (final EventState WzXq7Qbj : eventsStates) {
			if (WzXq7Qbj.evaluateStep(cqZCypKA)) {
				N0vheFp2.add(WzXq7Qbj);
			}
		}

		while (!N0vheFp2.isEmpty()) {

			final Iterator<EventState> YTlHaKnE = N0vheFp2.iterator();
			final EventState i0vpxKum = YTlHaKnE.next();
			YTlHaKnE.remove();

			final double NCJaUNZR = i0vpxKum.getEventTime();
			cqZCypKA.setSoftPreviousTime(i190go0G);
			cqZCypKA.setSoftCurrentTime(NCJaUNZR);

			cqZCypKA.setInterpolatedTime(NCJaUNZR);
			final double[] QmigiqFS = cqZCypKA.getInterpolatedState();
			i0vpxKum.stepAccepted(NCJaUNZR, QmigiqFS);
			isLastStep = i0vpxKum.stop();

			for (final StepHandler IatKeJw9 : stepHandlers) {
				IatKeJw9.handleStep(cqZCypKA, isLastStep);
			}

			if (isLastStep) {
				System.arraycopy(QmigiqFS, 0, fYjtQLt4, 0, fYjtQLt4.length);
				return NCJaUNZR;
			}

			if (i0vpxKum.reset(NCJaUNZR, QmigiqFS)) {
				System.arraycopy(QmigiqFS, 0, fYjtQLt4, 0, fYjtQLt4.length);
				computeDerivatives(NCJaUNZR, fYjtQLt4, XSAOeWDj);
				resetOccurred = true;
				return NCJaUNZR;
			}

			i190go0G = NCJaUNZR;
			cqZCypKA.setSoftPreviousTime(NCJaUNZR);
			cqZCypKA.setSoftCurrentTime(rMwDE48g);

			if (i0vpxKum.evaluateStep(cqZCypKA)) {
				N0vheFp2.add(i0vpxKum);
			}

		}

		cqZCypKA.setInterpolatedTime(rMwDE48g);
		final double[] kYQwlmKQ = cqZCypKA.getInterpolatedState();
		for (final EventState Ki9xSLr0 : eventsStates) {
			Ki9xSLr0.stepAccepted(rMwDE48g, kYQwlmKQ);
			isLastStep = isLastStep || Ki9xSLr0.stop();
		}
		isLastStep = isLastStep || Precision.equals(rMwDE48g, tX8ifto0, 1);

		for (StepHandler aBs5dCcP : stepHandlers) {
			aBs5dCcP.handleStep(cqZCypKA, isLastStep);
		}

		return rMwDE48g;

	}
}