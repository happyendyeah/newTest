public class test {
	protected double acceptStep(final AbstractStepInterpolator XEXywE2U, final double[] I2IOJe0x,
			final double[] Eztp3tjh, final double F01VI5gJ) throws MathIllegalStateException {

		double F8Osbed7 = XEXywE2U.getGlobalPreviousTime();
		final double bOGqhhMi = XEXywE2U.getGlobalCurrentTime();
		resetOccurred = false;

		if (!statesInitialized) {
			for (EventState SBoQVpM9 : eventsStates) {
				SBoQVpM9.reinitializeBegin(XEXywE2U);
			}
			statesInitialized = true;
		}

		final int dWQAnSGX = XEXywE2U.isForward() ? +1 : -1;
		SortedSet<EventState> nPeoFB5y = new TreeSet<EventState>(new Comparator<EventState>() {

			/** {@inheritDoc} */
			public int compare(EventState FV0gaT1d, EventState YVAYYYFm) {
				return dWQAnSGX * Double.compare(FV0gaT1d.getEventTime(), YVAYYYFm.getEventTime());
			}

		});

		for (final EventState nSmtQFEQ : eventsStates) {
			if (nSmtQFEQ.evaluateStep(XEXywE2U)) {
				nPeoFB5y.add(nSmtQFEQ);
			}
		}

		while (!nPeoFB5y.isEmpty()) {

			final Iterator<EventState> cis3fW6R = nPeoFB5y.iterator();
			final EventState WGgoo0jT = cis3fW6R.next();
			cis3fW6R.remove();

			final double v3gOAqoM = WGgoo0jT.getEventTime();
			XEXywE2U.setSoftPreviousTime(F8Osbed7);
			XEXywE2U.setSoftCurrentTime(v3gOAqoM);

			XEXywE2U.setInterpolatedTime(v3gOAqoM);
			final double[] vZtBZnkm = XEXywE2U.getInterpolatedState();
			WGgoo0jT.stepAccepted(v3gOAqoM, vZtBZnkm);
			isLastStep = WGgoo0jT.stop();

			for (final StepHandler N7lfRa26 : stepHandlers) {
				N7lfRa26.handleStep(XEXywE2U, isLastStep);
			}

			if (isLastStep) {
				System.arraycopy(vZtBZnkm, 0, I2IOJe0x, 0, I2IOJe0x.length);
				return v3gOAqoM;
			}

			if (WGgoo0jT.reset(v3gOAqoM, vZtBZnkm)) {
				System.arraycopy(vZtBZnkm, 0, I2IOJe0x, 0, I2IOJe0x.length);
				computeDerivatives(v3gOAqoM, I2IOJe0x, Eztp3tjh);
				resetOccurred = true;
				return v3gOAqoM;
			}

			F8Osbed7 = v3gOAqoM;
			XEXywE2U.setSoftPreviousTime(v3gOAqoM);
			XEXywE2U.setSoftCurrentTime(bOGqhhMi);

			if (WGgoo0jT.evaluateStep(XEXywE2U)) {
				nPeoFB5y.add(WGgoo0jT);
			}

		}

		XEXywE2U.setInterpolatedTime(bOGqhhMi);
		final double[] Gzt8jk61 = XEXywE2U.getInterpolatedState();
		for (final EventState lXnSoboN : eventsStates) {
			lXnSoboN.stepAccepted(bOGqhhMi, Gzt8jk61);
			isLastStep = isLastStep || lXnSoboN.stop();
		}
		isLastStep = isLastStep || Precision.equals(bOGqhhMi, F01VI5gJ, 1);

		for (StepHandler TkcrXzqQ : stepHandlers) {
			TkcrXzqQ.handleStep(XEXywE2U, isLastStep);
		}

		return bOGqhhMi;

	}
}