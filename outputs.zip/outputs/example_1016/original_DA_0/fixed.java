public class test {
	protected Size2D arrangeFN(BlockContainer sWnXcE9m, Graphics2D K5u3UyO9, double LkAoPznz) {
		double[] cFtcWq1k = new double[5];
		double[] tqmKORNq = new double[5];
		RectangleConstraint dManFmyg = new RectangleConstraint(LkAoPznz, null, LengthConstraintType.FIXED, 0.0, null,
				LengthConstraintType.NONE);
		if (this.topBlock != null) {
			Size2D zbjUBBqr = this.topBlock.arrange(K5u3UyO9, dManFmyg);
			cFtcWq1k[0] = zbjUBBqr.width;
			tqmKORNq[0] = zbjUBBqr.height;
		}
		if (this.bottomBlock != null) {
			Size2D abps4vK0 = this.bottomBlock.arrange(K5u3UyO9, dManFmyg);
			cFtcWq1k[1] = abps4vK0.width;
			tqmKORNq[1] = abps4vK0.height;
		}
		RectangleConstraint Pj4Vqbde = new RectangleConstraint(0.0, new Range(0.0, LkAoPznz),
				LengthConstraintType.RANGE, 0.0, null, LengthConstraintType.NONE);
		if (this.leftBlock != null) {
			Size2D RXkypWUi = this.leftBlock.arrange(K5u3UyO9, Pj4Vqbde);
			cFtcWq1k[2] = RXkypWUi.width;
			tqmKORNq[2] = RXkypWUi.height;
		}
		if (this.rightBlock != null) {
			double R4yTxQp3 = Math.max(LkAoPznz - cFtcWq1k[2], 0.0);
			RectangleConstraint Kx7CKahe = new RectangleConstraint(0.0,
					new Range(Math.min(cFtcWq1k[2], R4yTxQp3), R4yTxQp3), LengthConstraintType.RANGE, 0.0, null,
					LengthConstraintType.NONE);
			Size2D zoZYa0hM = this.rightBlock.arrange(K5u3UyO9, Kx7CKahe);
			cFtcWq1k[3] = zoZYa0hM.width;
			tqmKORNq[3] = zoZYa0hM.height;
		}

		tqmKORNq[2] = Math.max(tqmKORNq[2], tqmKORNq[3]);
		this.leftBlock = null;

		if (this.centerBlock != null) {
			RectangleConstraint JQgzRoWU = new RectangleConstraint(LkAoPznz - cFtcWq1k[2] - cFtcWq1k[3], null,
					LengthConstraintType.FIXED, 0.0, null, LengthConstraintType.NONE);
			Size2D s6cM7hrN = this.centerBlock.arrange(K5u3UyO9, JQgzRoWU);
			cFtcWq1k[4] = s6cM7hrN.width;
			tqmKORNq[4] = s6cM7hrN.height;
		}
		double e6TT0qio = tqmKORNq[0] + tqmKORNq[1] + Math.max(tqmKORNq[2], Math.max(tqmKORNq[3], tqmKORNq[4]));
		return arrange(sWnXcE9m, K5u3UyO9, new RectangleConstraint(LkAoPznz, e6TT0qio));
	}
}