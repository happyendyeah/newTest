public class test {
	protected Size2D arrangeFN(BlockContainer AHJSRuXP, Graphics2D uNyhhJzK, double DA6NQNMX) {
		double[] wti3XMQA = new double[5];
		double[] QxU33cRk = new double[5];
		RectangleConstraint p4apQmY3 = new RectangleConstraint(DA6NQNMX, null, LengthConstraintType.FIXED, 0.0, null,
				LengthConstraintType.NONE);
		if (this.topBlock != null) {
			Size2D SG5oqpQT = this.topBlock.arrange(uNyhhJzK, p4apQmY3);
			wti3XMQA[0] = SG5oqpQT.width;
			QxU33cRk[0] = SG5oqpQT.height;
		}
		if (this.bottomBlock != null) {
			Size2D yCKDFESE = this.bottomBlock.arrange(uNyhhJzK, p4apQmY3);
			wti3XMQA[1] = yCKDFESE.width;
			QxU33cRk[1] = yCKDFESE.height;
		}
		RectangleConstraint if5zNkJ1 = new RectangleConstraint(0.0, new Range(0.0, DA6NQNMX),
				LengthConstraintType.RANGE, 0.0, null, LengthConstraintType.NONE);
		if (this.leftBlock != null) {
			Size2D fDRIuXmG = this.leftBlock.arrange(uNyhhJzK, if5zNkJ1);
			wti3XMQA[2] = fDRIuXmG.width;
			QxU33cRk[2] = fDRIuXmG.height;
		}
		if (this.rightBlock != null) {
			double x8yAIvUG = Math.max(DA6NQNMX - wti3XMQA[2], 0.0);
			RectangleConstraint hDNLyH4y = new RectangleConstraint(0.0,
					new Range(Math.min(wti3XMQA[2], x8yAIvUG), x8yAIvUG), LengthConstraintType.RANGE, 0.0, null,
					LengthConstraintType.NONE);
			Size2D ObtIWthG = this.rightBlock.arrange(uNyhhJzK, hDNLyH4y);
			wti3XMQA[3] = ObtIWthG.width;
			QxU33cRk[3] = ObtIWthG.height;
		}

		QxU33cRk[2] = Math.max(QxU33cRk[2], QxU33cRk[3]);
		QxU33cRk[3] = QxU33cRk[2];

		if (this.centerBlock != null) {
			RectangleConstraint Nv1oQIbX = new RectangleConstraint(DA6NQNMX - wti3XMQA[2] - wti3XMQA[3], null,
					LengthConstraintType.FIXED, 0.0, null, LengthConstraintType.NONE);
			Size2D sEWaiiYo = this.centerBlock.arrange(uNyhhJzK, Nv1oQIbX);
			wti3XMQA[4] = sEWaiiYo.width;
			QxU33cRk[4] = sEWaiiYo.height;
		}
		double CqFLMMp1 = QxU33cRk[0] + QxU33cRk[1] + Math.max(QxU33cRk[2], Math.max(QxU33cRk[3], QxU33cRk[4]));
		return arrange(AHJSRuXP, uNyhhJzK, new RectangleConstraint(DA6NQNMX, CqFLMMp1));
	}
}