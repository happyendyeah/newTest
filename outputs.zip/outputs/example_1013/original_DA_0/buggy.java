public class test {
	protected double doSolve() {

		final double[] cTdnxCF2 = new double[maximalOrder + 1];
		final double[] w0TASQf8 = new double[maximalOrder + 1];
		cTdnxCF2[0] = getMin();
		cTdnxCF2[1] = getStartValue();
		cTdnxCF2[2] = getMax();
		verifySequence(cTdnxCF2[0], cTdnxCF2[1], cTdnxCF2[2]);

		w0TASQf8[1] = computeObjectiveValue(cTdnxCF2[1]);
		if (Precision.equals(w0TASQf8[1], 0.0, 1)) {
			return cTdnxCF2[1];
		}

		w0TASQf8[0] = computeObjectiveValue(cTdnxCF2[0]);
		if (Precision.equals(w0TASQf8[0], 0.0, 1)) {
			return cTdnxCF2[0];
		}

		int C5EFW0Rg;
		int iGMZdVIZ;
		if (w0TASQf8[0] * w0TASQf8[1] < 0) {

			C5EFW0Rg = 2;
			iGMZdVIZ = 1;

		} else {

			w0TASQf8[2] = computeObjectiveValue(cTdnxCF2[2]);
			if (Precision.equals(w0TASQf8[2], 0.0, 1)) {
				return cTdnxCF2[2];
			}

			if (w0TASQf8[1] * w0TASQf8[2] < 0) {
				C5EFW0Rg = 3;
				iGMZdVIZ = 2;
			} else {
				throw new NoBracketingException(cTdnxCF2[0], cTdnxCF2[2], w0TASQf8[0], w0TASQf8[2]);
			}

		}

		final double[] f8y4nhmo = new double[cTdnxCF2.length];

		double Ru92IFSa = cTdnxCF2[iGMZdVIZ - 1];
		double YVYV8RJl = w0TASQf8[iGMZdVIZ - 1];
		double uUyxbAvA = FastMath.abs(YVYV8RJl);
		int pq5huSnb = 0;
		double BzgR7HUq = cTdnxCF2[iGMZdVIZ];
		double Nl2KgEPO = w0TASQf8[iGMZdVIZ];
		double a54gzjd3 = FastMath.abs(Nl2KgEPO);
		int qG5ztfEN = 0;

		while (true) {

			final double rSETxDC2 = getAbsoluteAccuracy()
					+ getRelativeAccuracy() * FastMath.max(FastMath.abs(Ru92IFSa), FastMath.abs(BzgR7HUq));
			if (((BzgR7HUq - Ru92IFSa) <= rSETxDC2)
					|| (FastMath.max(uUyxbAvA, a54gzjd3) < getFunctionValueAccuracy())) {
				switch (allowed) {
				case ANY_SIDE:
					return uUyxbAvA < a54gzjd3 ? Ru92IFSa : BzgR7HUq;
				case LEFT_SIDE:
					return Ru92IFSa;
				case RIGHT_SIDE:
					return BzgR7HUq;
				case BELOW_SIDE:
					return (YVYV8RJl <= 0) ? Ru92IFSa : BzgR7HUq;
				case ABOVE_SIDE:
					return (YVYV8RJl < 0) ? BzgR7HUq : Ru92IFSa;
				default:
					throw new MathInternalError(null);
				}
			}

			double csYJ7Mgp;
			if (pq5huSnb >= MAXIMAL_AGING) {
				csYJ7Mgp = -REDUCTION_FACTOR * Nl2KgEPO;
			} else if (qG5ztfEN >= MAXIMAL_AGING) {
				csYJ7Mgp = -REDUCTION_FACTOR * YVYV8RJl;
			} else {
				csYJ7Mgp = 0;
			}

			double pPtYtHku;
			int fBju02id = 0;
			int OG62rrCa = C5EFW0Rg;
			do {

				System.arraycopy(cTdnxCF2, fBju02id, f8y4nhmo, fBju02id, OG62rrCa - fBju02id);
				pPtYtHku = guessX(csYJ7Mgp, f8y4nhmo, w0TASQf8, fBju02id, OG62rrCa);

				if (!((pPtYtHku > Ru92IFSa) && (pPtYtHku < BzgR7HUq))) {

					if (iGMZdVIZ - fBju02id >= OG62rrCa - iGMZdVIZ) {
						++fBju02id;
					} else {
						--OG62rrCa;
					}

					pPtYtHku = Double.NaN;

				}

			} while (Double.isNaN(pPtYtHku) && (OG62rrCa - fBju02id > 1));

			if (Double.isNaN(pPtYtHku)) {
				pPtYtHku = Ru92IFSa + 0.5 * (BzgR7HUq - Ru92IFSa);
				fBju02id = iGMZdVIZ - 1;
				OG62rrCa = iGMZdVIZ;
			}

			final double vYLPL8fY = computeObjectiveValue(pPtYtHku);
			if (Precision.equals(vYLPL8fY, 0.0, 1)) {
				return pPtYtHku;
			}

			if ((C5EFW0Rg > 2) && (OG62rrCa - fBju02id != C5EFW0Rg)) {

				C5EFW0Rg = OG62rrCa - fBju02id;
				System.arraycopy(cTdnxCF2, fBju02id, cTdnxCF2, 0, C5EFW0Rg);
				System.arraycopy(w0TASQf8, fBju02id, w0TASQf8, 0, C5EFW0Rg);
				iGMZdVIZ -= fBju02id;

			} else if (C5EFW0Rg == cTdnxCF2.length) {

				C5EFW0Rg--;

				if (iGMZdVIZ >= (cTdnxCF2.length + 1) / 2) {
					System.arraycopy(cTdnxCF2, 1, cTdnxCF2, 0, C5EFW0Rg);
					System.arraycopy(w0TASQf8, 1, w0TASQf8, 0, C5EFW0Rg);
					--iGMZdVIZ;
				}

			}

			System.arraycopy(cTdnxCF2, iGMZdVIZ, cTdnxCF2, iGMZdVIZ + 1, C5EFW0Rg - iGMZdVIZ);
			cTdnxCF2[iGMZdVIZ] = pPtYtHku;
			System.arraycopy(w0TASQf8, iGMZdVIZ, w0TASQf8, iGMZdVIZ + 1, C5EFW0Rg - iGMZdVIZ);
			w0TASQf8[iGMZdVIZ] = vYLPL8fY;
			++C5EFW0Rg;

			if (vYLPL8fY * YVYV8RJl <= 0) {
				BzgR7HUq = pPtYtHku;
				Nl2KgEPO = vYLPL8fY;
				a54gzjd3 = FastMath.abs(Nl2KgEPO);
				++pq5huSnb;
				qG5ztfEN = 0;
			} else {
				Ru92IFSa = pPtYtHku;
				YVYV8RJl = vYLPL8fY;
				uUyxbAvA = FastMath.abs(YVYV8RJl);
				pq5huSnb = 0;
				++qG5ztfEN;

				iGMZdVIZ++;

			}

		}

	}
}