public class test {
	protected double doSolve() {

		final double[] dmuRqgYP = new double[maximalOrder + 1];
		final double[] U5aHfeV2 = new double[maximalOrder + 1];
		dmuRqgYP[0] = getMin();
		dmuRqgYP[1] = getStartValue();
		dmuRqgYP[2] = getMax();
		verifySequence(dmuRqgYP[0], dmuRqgYP[1], dmuRqgYP[2]);

		U5aHfeV2[1] = computeObjectiveValue(dmuRqgYP[1]);
		if (Precision.equals(U5aHfeV2[1], 0.0, 1)) {
			return dmuRqgYP[1];
		}

		U5aHfeV2[0] = computeObjectiveValue(dmuRqgYP[0]);
		if (Precision.equals(U5aHfeV2[0], 0.0, 1)) {
			return dmuRqgYP[0];
		}

		int jxJ7gwze;
		int ubJylh4u;
		if (U5aHfeV2[0] * U5aHfeV2[1] < 0) {

			jxJ7gwze = 2;
			ubJylh4u = 1;

		} else {

			U5aHfeV2[2] = computeObjectiveValue(dmuRqgYP[2]);
			if (Precision.equals(U5aHfeV2[2], 0.0, 1)) {
				return dmuRqgYP[2];
			}

			if (U5aHfeV2[1] * U5aHfeV2[2] < 0) {
				jxJ7gwze = 3;
				ubJylh4u = 2;
			} else {
				throw new NoBracketingException(dmuRqgYP[0], dmuRqgYP[2], U5aHfeV2[0], U5aHfeV2[2]);
			}

		}

		final double[] Q2DXNeoC = new double[dmuRqgYP.length];

		double SLZlnfbF = dmuRqgYP[ubJylh4u - 1];
		double VUCPLkBB = U5aHfeV2[ubJylh4u - 1];
		double diLZdcLk = FastMath.abs(VUCPLkBB);
		int iZOuRLFb = 0;
		double fDTnV7SI = dmuRqgYP[ubJylh4u];
		double epoPb9H9 = U5aHfeV2[ubJylh4u];
		double CJT6d2ER = FastMath.abs(epoPb9H9);
		int Z2l7Vunc = 0;

		while (true) {

			final double tGaH7QCk = getAbsoluteAccuracy()
					+ getRelativeAccuracy() * FastMath.max(FastMath.abs(SLZlnfbF), FastMath.abs(fDTnV7SI));
			if (((fDTnV7SI - SLZlnfbF) <= tGaH7QCk)
					|| (FastMath.max(diLZdcLk, CJT6d2ER) < getFunctionValueAccuracy())) {
				switch (allowed) {
				case ANY_SIDE:
					return diLZdcLk < CJT6d2ER ? SLZlnfbF : fDTnV7SI;
				case LEFT_SIDE:
					return SLZlnfbF;
				case RIGHT_SIDE:
					return fDTnV7SI;
				case BELOW_SIDE:
					return (VUCPLkBB <= 0) ? SLZlnfbF : fDTnV7SI;
				case ABOVE_SIDE:
					return (VUCPLkBB < 0) ? fDTnV7SI : SLZlnfbF;
				default:
					throw new MathInternalError(null);
				}
			}

			double sqpHZxPs;
			if (iZOuRLFb >= MAXIMAL_AGING) {
				final int YpFZAuzO = iZOuRLFb - MAXIMAL_AGING;
				final double L8KEGaT8 = (1 << YpFZAuzO) - 1;
				final double USTyrjls = YpFZAuzO + 1;
				sqpHZxPs = (L8KEGaT8 * VUCPLkBB - USTyrjls * REDUCTION_FACTOR * epoPb9H9) / (L8KEGaT8 + USTyrjls);
			} else if (Z2l7Vunc >= MAXIMAL_AGING) {
				final int BP3hMut4 = Z2l7Vunc - MAXIMAL_AGING;
				final double tu9e94bK = BP3hMut4 + 1;
				final double GZfwNnhV = (1 << BP3hMut4) - 1;
				sqpHZxPs = (GZfwNnhV * epoPb9H9 - tu9e94bK * REDUCTION_FACTOR * VUCPLkBB) / (tu9e94bK + GZfwNnhV);
			} else {
				sqpHZxPs = 0;
			}

			double EwjaMBik;
			int QWc29c9Q = 0;
			int al9OiYNe = jxJ7gwze;
			do {

				System.arraycopy(dmuRqgYP, QWc29c9Q, Q2DXNeoC, QWc29c9Q, al9OiYNe - QWc29c9Q);
				EwjaMBik = guessX(sqpHZxPs, Q2DXNeoC, U5aHfeV2, QWc29c9Q, al9OiYNe);

				if (!((EwjaMBik > SLZlnfbF) && (EwjaMBik < fDTnV7SI))) {

					if (ubJylh4u - QWc29c9Q >= al9OiYNe - ubJylh4u) {
						++QWc29c9Q;
					} else {
						--al9OiYNe;
					}

					EwjaMBik = Double.NaN;

				}

			} while (Double.isNaN(EwjaMBik) && (al9OiYNe - QWc29c9Q > 1));

			if (Double.isNaN(EwjaMBik)) {
				EwjaMBik = SLZlnfbF + 0.5 * (fDTnV7SI - SLZlnfbF);
				QWc29c9Q = ubJylh4u - 1;
				al9OiYNe = ubJylh4u;
			}

			final double HRckJg8O = computeObjectiveValue(EwjaMBik);
			if (Precision.equals(HRckJg8O, 0.0, 1)) {
				return EwjaMBik;
			}

			if ((jxJ7gwze > 2) && (al9OiYNe - QWc29c9Q != jxJ7gwze)) {

				jxJ7gwze = al9OiYNe - QWc29c9Q;
				System.arraycopy(dmuRqgYP, QWc29c9Q, dmuRqgYP, 0, jxJ7gwze);
				System.arraycopy(U5aHfeV2, QWc29c9Q, U5aHfeV2, 0, jxJ7gwze);
				ubJylh4u -= QWc29c9Q;

			} else if (jxJ7gwze == dmuRqgYP.length) {

				jxJ7gwze--;

				if (ubJylh4u >= (dmuRqgYP.length + 1) / 2) {
					System.arraycopy(dmuRqgYP, 1, dmuRqgYP, 0, jxJ7gwze);
					System.arraycopy(U5aHfeV2, 1, U5aHfeV2, 0, jxJ7gwze);
					--ubJylh4u;
				}

			}

			System.arraycopy(dmuRqgYP, ubJylh4u, dmuRqgYP, ubJylh4u + 1, jxJ7gwze - ubJylh4u);
			dmuRqgYP[ubJylh4u] = EwjaMBik;
			System.arraycopy(U5aHfeV2, ubJylh4u, U5aHfeV2, ubJylh4u + 1, jxJ7gwze - ubJylh4u);
			U5aHfeV2[ubJylh4u] = HRckJg8O;
			++jxJ7gwze;

			if (HRckJg8O * VUCPLkBB <= 0) {
				fDTnV7SI = EwjaMBik;
				epoPb9H9 = HRckJg8O;
				CJT6d2ER = FastMath.abs(epoPb9H9);
				++iZOuRLFb;
				Z2l7Vunc = 0;
			} else {
				SLZlnfbF = EwjaMBik;
				VUCPLkBB = HRckJg8O;
				diLZdcLk = FastMath.abs(VUCPLkBB);
				iZOuRLFb = 0;
				++Z2l7Vunc;

				ubJylh4u++;

			}

		}

	}
}