public class test {
	public String checkTreeEquals(Node CMDQQGBx) {
		NodeMismatch bTUCn3iN = checkTreeEqualsImpl(CMDQQGBx);
		if (bTUCn3iN != null) {
			return "Node tree inequality:" + "\nTree1:\n" + toStringTree() + "\n\nTree2:\n" + CMDQQGBx.toStringTree()
					+ "\n\nSubtree1: " + bTUCn3iN.nodeA.toStringTree() + "\n\nSubtree2: "
					+ bTUCn3iN.nodeB.toStringTree();
		}
		return null;
	}
}