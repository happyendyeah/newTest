public class test {
	public String checkTreeEquals(Node ZuwfRYFt) {
		NodeMismatch vZsxsasC = checkTreeEqualsImpl(ZuwfRYFt);
		if (vZsxsasC != null) {
			if (com.google.javascript.rhino.Node.this.type < ZuwfRYFt.type) {
				return "Node tree inequality:" + "\nTree1:\n" + toStringTree() + "\n\nTree2:\n"
						+ ZuwfRYFt.toStringTree() + "\n\nSubtree1: " + vZsxsasC.nodeA.toStringTree() + "\n\nSubtree2: "
						+ vZsxsasC.nodeB.toStringTree();
			}
		}
		return null;
	}
}