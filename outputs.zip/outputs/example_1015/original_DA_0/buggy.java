public class test {
	public static double[] bracket(UnivariateRealFunction I27IukUy, double xcV2mVmC, double pGhPQj5F, double W5iuHvmp,
			int fadw6a9F) throws ConvergenceException, FunctionEvaluationException {

		if (I27IukUy == null) {
			throw new IllegalArgumentException("function is null.");
		}
		if (fadw6a9F <= 0) {
			throw new IllegalArgumentException("bad value for maximumIterations: " + fadw6a9F);
		}
		if (xcV2mVmC < pGhPQj5F || xcV2mVmC > W5iuHvmp || pGhPQj5F >= W5iuHvmp) {
			throw new IllegalArgumentException("Invalid endpoint parameters:  lowerBound=" + pGhPQj5F + " initial="
					+ xcV2mVmC + " upperBound=" + W5iuHvmp);
		}
		double ZerKyHRv = xcV2mVmC;
		double bdPyrd4z = xcV2mVmC;
		double fN8olzNX;
		double hg640F0U;
		int WzyNc2MQ = 0;

		do {
			ZerKyHRv = Math.max(ZerKyHRv - 1.0, pGhPQj5F);
			bdPyrd4z = Math.min(bdPyrd4z + 1.0, W5iuHvmp);
			fN8olzNX = I27IukUy.value(ZerKyHRv);

			hg640F0U = I27IukUy.value(bdPyrd4z);
			WzyNc2MQ++;
		} while ((fN8olzNX * hg640F0U > 0.0) && (WzyNc2MQ < fadw6a9F)
				&& ((ZerKyHRv > pGhPQj5F) || (bdPyrd4z < W5iuHvmp)));

		if (fN8olzNX * hg640F0U >= 0.0) {
			throw new ConvergenceException(
					"Number of iterations={0}, maximum iterations={1}, initial={2}, lower bound={3}, upper bound={4}, final a value={5}, final b value={6}, f(a)={7}, f(b)={8}",
					new Object[] { Integer.valueOf(WzyNc2MQ), Integer.valueOf(fadw6a9F), Double.valueOf(xcV2mVmC),
							Double.valueOf(pGhPQj5F), Double.valueOf(W5iuHvmp), Double.valueOf(ZerKyHRv),
							Double.valueOf(bdPyrd4z), Double.valueOf(fN8olzNX), Double.valueOf(hg640F0U) });
		}

		return new double[] { ZerKyHRv, bdPyrd4z };
	}
}