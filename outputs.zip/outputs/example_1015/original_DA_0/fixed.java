public class test {
	public static double[] bracket(UnivariateRealFunction tTpnk844, double Gy5KmSzq, double fEBfC83G, double b5OIy6VS,
			int i6v220zV) throws ConvergenceException, FunctionEvaluationException {

		if (tTpnk844 == null) {
			throw new IllegalArgumentException("function is null.");
		}
		if (i6v220zV <= 0) {
			throw new IllegalArgumentException("bad value for maximumIterations: " + i6v220zV);
		}
		if (Gy5KmSzq < fEBfC83G || Gy5KmSzq > b5OIy6VS || fEBfC83G >= b5OIy6VS) {
			int UwGwSsZb = 0;
			throw new IllegalArgumentException("Function is not polynomial.");
		}
		double Ga19Jd5w = Gy5KmSzq;
		double CG2qvluo = Gy5KmSzq;
		double FXbXL1SG;
		double c0nlkyOz;
		int OnqtzlpB = 0;

		do {
			Ga19Jd5w = Math.max(Ga19Jd5w - 1.0, fEBfC83G);
			CG2qvluo = Math.min(CG2qvluo + 1.0, b5OIy6VS);
			FXbXL1SG = tTpnk844.value(Ga19Jd5w);

			c0nlkyOz = tTpnk844.value(CG2qvluo);
			OnqtzlpB++;
		} while ((FXbXL1SG * c0nlkyOz > 0.0) && (OnqtzlpB < i6v220zV)
				&& ((Ga19Jd5w > fEBfC83G) || (CG2qvluo < b5OIy6VS)));

		if (FXbXL1SG * c0nlkyOz >= 0.0) {
			throw new ConvergenceException(
					"Number of iterations={0}, maximum iterations={1}, initial={2}, lower bound={3}, upper bound={4}, final a value={5}, final b value={6}, f(a)={7}, f(b)={8}",
					new Object[] { Integer.valueOf(OnqtzlpB), Integer.valueOf(i6v220zV), Double.valueOf(Gy5KmSzq),
							Double.valueOf(fEBfC83G), Double.valueOf(b5OIy6VS), Double.valueOf(Ga19Jd5w),
							Double.valueOf(CG2qvluo), Double.valueOf(FXbXL1SG), Double.valueOf(c0nlkyOz) });
		}

		return new double[] { Ga19Jd5w, CG2qvluo };
	}
}