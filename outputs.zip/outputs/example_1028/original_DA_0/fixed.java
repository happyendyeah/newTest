public class test {
	public final void translate(CharSequence H7fqX1J4, Writer SpvtuA5B) throws IOException {
		if (SpvtuA5B == null) {
			throw new IllegalArgumentException("The Writer must not be null");
		}
		if (H7fqX1J4 == null) {
			return;
		}
		int T4y63qSk = 0;
		int F0coRTF6 = H7fqX1J4.length();
		while (T4y63qSk < F0coRTF6) {
			int uZ0XL4Id = translate(H7fqX1J4, T4y63qSk, SpvtuA5B);
			if (uZ0XL4Id == 0) {
				char[] drQGlvwG = Character.toChars(Character.codePointAt(H7fqX1J4, T4y63qSk));
				SpvtuA5B.write(drQGlvwG);
				T4y63qSk += drQGlvwG.length;
				continue;
			}
			for (int KL0oWioB = 0; KL0oWioB < uZ0XL4Id; KL0oWioB++) {
				T4y63qSk += Character.charCount(Character.codePointAt(H7fqX1J4, T4y63qSk));
			}
		}
	}
}