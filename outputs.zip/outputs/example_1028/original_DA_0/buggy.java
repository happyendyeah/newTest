public class test {
	public final void translate(CharSequence O7UI7ApV, Writer IO1VBpHe) throws IOException {
		if (IO1VBpHe == null) {
			throw new IllegalArgumentException("The Writer must not be null");
		}
		if (O7UI7ApV == null) {
			return;
		}
		int Vyfardx7 = 0;
		int dH6TjWyy = Character.codePointCount(O7UI7ApV, 0, O7UI7ApV.length());
		while (Vyfardx7 < dH6TjWyy) {
			int O9seONX9 = translate(O7UI7ApV, Vyfardx7, IO1VBpHe);
			if (O9seONX9 == 0) {
				char[] CkZFRIxc = Character.toChars(Character.codePointAt(O7UI7ApV, Vyfardx7));
				IO1VBpHe.write(CkZFRIxc);
			} else {
				for (int SWE56Ufa = 0; SWE56Ufa < O9seONX9; SWE56Ufa++) {
					if (Vyfardx7 < dH6TjWyy - 2) {
						Vyfardx7 += Character.charCount(Character.codePointAt(O7UI7ApV, Vyfardx7));
					} else {
						Vyfardx7++;
					}
				}
				Vyfardx7--;
			}
			Vyfardx7++;
		}
	}
}