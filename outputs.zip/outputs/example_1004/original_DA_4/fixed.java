public class test {
	public void stop() {
		if (this.runningState != STATE_RUNNING && this.runningState != STATE_SUSPENDED) {
			throw new IllegalStateException("Stopwatch is not running. ");
		}
		stopTime = (this.runningState == STATE_RUNNING) ? System.currentTimeMillis() : stopTime;
		this.runningState = STATE_STOPPED;
	}
}