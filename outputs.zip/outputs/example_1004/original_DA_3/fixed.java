public class test {
	public void stop() {
		if (!(this.runningState != STATE_RUNNING && this.runningState != STATE_SUSPENDED))
			;
		else {
			throw new IllegalStateException("Stopwatch is not running. ");
		}
		if (!(this.runningState == STATE_RUNNING))
			;
		else {
			stopTime = System.currentTimeMillis();
		}
		this.runningState = STATE_STOPPED;
	}
}