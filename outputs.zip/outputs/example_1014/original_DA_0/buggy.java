public class test {
	public void draw(Graphics2D jAUztRJ5, Rectangle2D MCmYtJF3, Point2D OAqp0Pen, PlotState D8AaBOYv,
			PlotRenderingInfo MKjoH6Kr) {

		RectangleInsets VWw67ipM = getInsets();
		VWw67ipM.trim(MCmYtJF3);

		Rectangle2D i7quuIVJ = (Rectangle2D) MCmYtJF3.clone();
		if (MKjoH6Kr != null) {
			MKjoH6Kr.setPlotArea(MCmYtJF3);
			MKjoH6Kr.setDataArea(MCmYtJF3);
		}

		drawBackground(jAUztRJ5, MCmYtJF3);

		Shape SeN63TEy = jAUztRJ5.getClip();
		jAUztRJ5.clip(MCmYtJF3);

		double aRAEJXOs = getInteriorGap();
		double mDh7K5hN = 0.0;
		if (getLabelGenerator() != null) {
			mDh7K5hN = getLabelGap() + getMaximumLabelWidth();
		}
		double eqVVGNZo = MCmYtJF3.getWidth() * (aRAEJXOs + mDh7K5hN) * 2.0;
		double b5OoFF8k = MCmYtJF3.getHeight() * aRAEJXOs * 2.0;

		if (DEBUG_DRAW_INTERIOR) {
			double BDurDvtu = MCmYtJF3.getWidth() * getInteriorGap();
			double YlNLQRTN = MCmYtJF3.getHeight() * getInteriorGap();
			double MhdVp2ZZ = MCmYtJF3.getX() + BDurDvtu;
			double M4vNkd3K = MCmYtJF3.getMaxX() - BDurDvtu;
			double dDBpHBHb = MCmYtJF3.getY() + YlNLQRTN;
			double YizNAP3p = MCmYtJF3.getMaxY() - YlNLQRTN;
			jAUztRJ5.setPaint(Color.lightGray);
			jAUztRJ5.draw(new Rectangle2D.Double(MhdVp2ZZ, dDBpHBHb, M4vNkd3K - MhdVp2ZZ, YizNAP3p - dDBpHBHb));
		}

		double FIbMeHjo = MCmYtJF3.getX() + eqVVGNZo / 2;
		double hTIuN0Si = MCmYtJF3.getY() + b5OoFF8k / 2;
		double UnticYd7 = MCmYtJF3.getWidth() - eqVVGNZo;
		double GkG5rvWE = MCmYtJF3.getHeight() - b5OoFF8k;

		if (isCircular()) { // is circular?
			double IqcQr9BZ = Math.min(UnticYd7, GkG5rvWE) / 2;
			FIbMeHjo = (FIbMeHjo + FIbMeHjo + UnticYd7) / 2 - IqcQr9BZ;
			hTIuN0Si = (hTIuN0Si + hTIuN0Si + GkG5rvWE) / 2 - IqcQr9BZ;
			UnticYd7 = 2 * IqcQr9BZ;
			GkG5rvWE = 2 * IqcQr9BZ;
		}

		PiePlotState cpjClBTF = initialise(jAUztRJ5, MCmYtJF3, this, null, MKjoH6Kr);

		Rectangle2D BHdn4GRd = new Rectangle2D.Double(FIbMeHjo, hTIuN0Si, UnticYd7, GkG5rvWE * (1 - this.depthFactor));
		cpjClBTF.setLinkArea(BHdn4GRd);

		if (DEBUG_DRAW_LINK_AREA) {
			jAUztRJ5.setPaint(Color.blue);
			jAUztRJ5.draw(BHdn4GRd);
			jAUztRJ5.setPaint(Color.yellow);
			jAUztRJ5.draw(
					new Ellipse2D.Double(BHdn4GRd.getX(), BHdn4GRd.getY(), BHdn4GRd.getWidth(), BHdn4GRd.getHeight()));
		}

		double eFNoP9yu = UnticYd7 * getLabelLinkMargin();
		double AlDNGX3I = GkG5rvWE * getLabelLinkMargin();
		Rectangle2D YZyEztkI = new Rectangle2D.Double(FIbMeHjo + eFNoP9yu / 2.0, hTIuN0Si + AlDNGX3I / 2.0,
				UnticYd7 - eFNoP9yu, GkG5rvWE - AlDNGX3I);

		cpjClBTF.setExplodedPieArea(YZyEztkI);

		double Rh2aHVyz = getMaximumExplodePercent();
		double WSps70dV = Rh2aHVyz / (1.0 + Rh2aHVyz);

		double CCQrDwjI = YZyEztkI.getWidth() * WSps70dV;
		double dlC5YvIl = YZyEztkI.getHeight() * WSps70dV;
		Rectangle2D iL9WESfo = new Rectangle2D.Double(YZyEztkI.getX() + CCQrDwjI / 2.0,
				YZyEztkI.getY() + dlC5YvIl / 2.0, YZyEztkI.getWidth() - CCQrDwjI, YZyEztkI.getHeight() - dlC5YvIl);

		int p2lvJ9ee = (int) (iL9WESfo.getHeight() * this.depthFactor);
		Rectangle2D qDH2Hv34 = new Rectangle2D.Double(FIbMeHjo, hTIuN0Si, UnticYd7, GkG5rvWE - p2lvJ9ee);
		cpjClBTF.setLinkArea(qDH2Hv34);

		cpjClBTF.setPieArea(iL9WESfo);
		cpjClBTF.setPieCenterX(iL9WESfo.getCenterX());
		cpjClBTF.setPieCenterY(iL9WESfo.getCenterY() - p2lvJ9ee / 2.0);
		cpjClBTF.setPieWRadius(iL9WESfo.getWidth() / 2.0);
		cpjClBTF.setPieHRadius((iL9WESfo.getHeight() - p2lvJ9ee) / 2.0);

		PieDataset vdguWFjW = getDataset();
		if (DatasetUtilities.isEmptyOrNull(getDataset())) {
			drawNoDataMessage(jAUztRJ5, MCmYtJF3);
			jAUztRJ5.setClip(SeN63TEy);
			drawOutline(jAUztRJ5, MCmYtJF3);
			return;
		}

		if (vdguWFjW.getKeys().size() > MCmYtJF3.getWidth()) {
			String nzrKo69z = "Too many elements";
			Font utHCa4zy = new Font("dialog", Font.BOLD, 10);
			jAUztRJ5.setFont(utHCa4zy);
			FontMetrics xMnjPUnS = jAUztRJ5.getFontMetrics(utHCa4zy);
			int Wn6rdOLd = xMnjPUnS.stringWidth(nzrKo69z);

			jAUztRJ5.drawString(nzrKo69z, (int) (MCmYtJF3.getX() + (MCmYtJF3.getWidth() - Wn6rdOLd) / 2),
					(int) (MCmYtJF3.getY() + (MCmYtJF3.getHeight() / 2)));
			return;
		}
		if (isCircular()) {
			double qI5mgaWI = Math.min(MCmYtJF3.getWidth(), MCmYtJF3.getHeight()) / 2;
			MCmYtJF3 = new Rectangle2D.Double(MCmYtJF3.getCenterX() - qI5mgaWI, MCmYtJF3.getCenterY() - qI5mgaWI,
					2 * qI5mgaWI, 2 * qI5mgaWI);
		}
		List sljNn2C3 = vdguWFjW.getKeys();

		if (sljNn2C3.size() == 0) {
			return;
		}

		double nVRuvlF6 = iL9WESfo.getX();
		double vG4A1RHI = iL9WESfo.getY();

		Composite Fvro560Z = jAUztRJ5.getComposite();
		jAUztRJ5.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, getForegroundAlpha()));

		double tyuBlb7M = DatasetUtilities.calculatePieDatasetTotal(vdguWFjW);
		double VnrvihAJ = 0;
		if (p2lvJ9ee < 0) {
			return; // if depth is negative don't draw anything
		}

		ArrayList T6TeRvkb = new ArrayList();
		Arc2D.Double UZ9UK55o;
		Paint nCMUqt5r;
		Paint Sj7iyog3;
		Stroke g2bKnvXI;

		Iterator tAKEtVFY = sljNn2C3.iterator();
		while (tAKEtVFY.hasNext()) {

			Comparable drAlrsuF = (Comparable) tAKEtVFY.next();
			Number pt8RrAV2 = vdguWFjW.getValue(drAlrsuF);
			if (pt8RrAV2 == null) {
				T6TeRvkb.add(null);
				continue;
			}
			double I9uWJZAD = pt8RrAV2.doubleValue();
			if (I9uWJZAD <= 0) {
				T6TeRvkb.add(null);
				continue;
			}
			double qIItGGlX = getStartAngle();
			double fcnQMUzI = getDirection().getFactor();
			double Mpqgr7um = qIItGGlX + (fcnQMUzI * (VnrvihAJ * 360)) / tyuBlb7M;
			double T7CEVRBM = qIItGGlX + (fcnQMUzI * (VnrvihAJ + I9uWJZAD) * 360) / tyuBlb7M;
			if (Math.abs(T7CEVRBM - Mpqgr7um) > getMinimumArcAngleToDraw()) {
				T6TeRvkb.add(new Arc2D.Double(nVRuvlF6, vG4A1RHI + p2lvJ9ee, iL9WESfo.getWidth(),
						iL9WESfo.getHeight() - p2lvJ9ee, Mpqgr7um, T7CEVRBM - Mpqgr7um, Arc2D.PIE));
			} else {
				T6TeRvkb.add(null);
			}
			VnrvihAJ += I9uWJZAD;
		}

		Shape sKND1sIB = jAUztRJ5.getClip();

		Ellipse2D IeCV4UOG = new Ellipse2D.Double(iL9WESfo.getX(), iL9WESfo.getY(), iL9WESfo.getWidth(),
				iL9WESfo.getHeight() - p2lvJ9ee);

		Ellipse2D lDjkKxVe = new Ellipse2D.Double(iL9WESfo.getX(), iL9WESfo.getY() + p2lvJ9ee, iL9WESfo.getWidth(),
				iL9WESfo.getHeight() - p2lvJ9ee);

		Rectangle2D ul7Uj4NH = new Rectangle2D.Double(IeCV4UOG.getX(), IeCV4UOG.getCenterY(), iL9WESfo.getWidth(),
				lDjkKxVe.getMaxY() - IeCV4UOG.getCenterY());

		Rectangle2D vJwZlmaN = new Rectangle2D.Double(iL9WESfo.getX(), IeCV4UOG.getY(), iL9WESfo.getWidth(),
				lDjkKxVe.getCenterY() - IeCV4UOG.getY());

		Area Dxa3cqH0 = new Area(IeCV4UOG);
		Dxa3cqH0.add(new Area(ul7Uj4NH));
		Area CzOJQBDm = new Area(lDjkKxVe);
		CzOJQBDm.add(new Area(vJwZlmaN));
		Area xDdwZsF8 = new Area(Dxa3cqH0);
		xDdwZsF8.intersect(CzOJQBDm);

		Area uWg99PqD = new Area(xDdwZsF8);
		uWg99PqD.subtract(new Area(IeCV4UOG));

		Area ezBHyEU8 = new Area(xDdwZsF8);
		ezBHyEU8.subtract(new Area(lDjkKxVe));

		int[] yPYQFkLm;
		int[] covIiYcP;
		UZ9UK55o = new Arc2D.Double(nVRuvlF6, vG4A1RHI + p2lvJ9ee, iL9WESfo.getWidth(), iL9WESfo.getHeight() - p2lvJ9ee,
				0, 360, Arc2D.PIE);

		int vKXehtHs = T6TeRvkb.size();
		for (int XyaacIRX = 0; XyaacIRX < vKXehtHs; XyaacIRX++) {
			UZ9UK55o = (Arc2D.Double) T6TeRvkb.get(XyaacIRX);
			if (UZ9UK55o == null) {
				continue;
			}
			Comparable oi9CZ8Tn = getSectionKey(XyaacIRX);
			nCMUqt5r = lookupSectionPaint(oi9CZ8Tn, true);
			Sj7iyog3 = lookupSectionOutlinePaint(oi9CZ8Tn);
			g2bKnvXI = lookupSectionOutlineStroke(oi9CZ8Tn);
			jAUztRJ5.setPaint(nCMUqt5r);
			jAUztRJ5.fill(UZ9UK55o);
			jAUztRJ5.setPaint(Sj7iyog3);
			jAUztRJ5.setStroke(g2bKnvXI);
			jAUztRJ5.draw(UZ9UK55o);
			jAUztRJ5.setPaint(nCMUqt5r);

			Point2D ITmofLS1 = UZ9UK55o.getStartPoint();

			yPYQFkLm = new int[] { (int) UZ9UK55o.getCenterX(), (int) UZ9UK55o.getCenterX(), (int) ITmofLS1.getX(),
					(int) ITmofLS1.getX() };
			covIiYcP = new int[] { (int) UZ9UK55o.getCenterY(), (int) UZ9UK55o.getCenterY() - p2lvJ9ee,
					(int) ITmofLS1.getY() - p2lvJ9ee, (int) ITmofLS1.getY() };
			Polygon oNFGDPId = new Polygon(yPYQFkLm, covIiYcP, 4);
			jAUztRJ5.setPaint(java.awt.Color.lightGray);
			jAUztRJ5.fill(oNFGDPId);
			jAUztRJ5.setPaint(Sj7iyog3);
			jAUztRJ5.setStroke(g2bKnvXI);
			jAUztRJ5.draw(oNFGDPId);
			jAUztRJ5.setPaint(nCMUqt5r);

		}

		jAUztRJ5.setPaint(Color.gray);
		jAUztRJ5.fill(ezBHyEU8);
		jAUztRJ5.fill(uWg99PqD);

		int nADoxfZu = 0;
		tAKEtVFY = T6TeRvkb.iterator();
		while (tAKEtVFY.hasNext()) {
			Arc2D RZ7cs4UT = (Arc2D) tAKEtVFY.next();
			if (RZ7cs4UT != null) {
				Comparable QMqujfy9 = getSectionKey(nADoxfZu);
				nCMUqt5r = lookupSectionPaint(QMqujfy9, true);
				Sj7iyog3 = lookupSectionOutlinePaint(QMqujfy9);
				g2bKnvXI = lookupSectionOutlineStroke(QMqujfy9);
				drawSide(jAUztRJ5, iL9WESfo, RZ7cs4UT, uWg99PqD, ezBHyEU8, nCMUqt5r, Sj7iyog3, g2bKnvXI, false, true);
			}
			nADoxfZu++;
		}

		nADoxfZu = 0;
		tAKEtVFY = T6TeRvkb.iterator();
		while (tAKEtVFY.hasNext()) {
			Arc2D HWq6ZII1 = (Arc2D) tAKEtVFY.next();
			if (HWq6ZII1 != null) {
				Comparable YJEWZkeF = getSectionKey(nADoxfZu);
				nCMUqt5r = lookupSectionPaint(YJEWZkeF);
				Sj7iyog3 = lookupSectionOutlinePaint(YJEWZkeF);
				g2bKnvXI = lookupSectionOutlineStroke(YJEWZkeF);
				drawSide(jAUztRJ5, iL9WESfo, HWq6ZII1, uWg99PqD, ezBHyEU8, nCMUqt5r, Sj7iyog3, g2bKnvXI, true, false);
			}
			nADoxfZu++;
		}

		jAUztRJ5.setClip(sKND1sIB);

		Arc2D r9EHJSAy;
		for (int kP1Vwoz8 = 0; kP1Vwoz8 < vKXehtHs; kP1Vwoz8++) {
			UZ9UK55o = (Arc2D.Double) T6TeRvkb.get(kP1Vwoz8);
			if (UZ9UK55o == null) {
				continue;
			}
			r9EHJSAy = new Arc2D.Double(nVRuvlF6, vG4A1RHI, iL9WESfo.getWidth(), iL9WESfo.getHeight() - p2lvJ9ee,
					UZ9UK55o.getAngleStart(), UZ9UK55o.getAngleExtent(), Arc2D.PIE);

			Comparable eTA2gwAA = (Comparable) sljNn2C3.get(kP1Vwoz8);
			nCMUqt5r = lookupSectionPaint(eTA2gwAA, true);
			Sj7iyog3 = lookupSectionOutlinePaint(eTA2gwAA);
			g2bKnvXI = lookupSectionOutlineStroke(eTA2gwAA);
			jAUztRJ5.setPaint(nCMUqt5r);
			jAUztRJ5.fill(r9EHJSAy);
			jAUztRJ5.setStroke(g2bKnvXI);
			jAUztRJ5.setPaint(Sj7iyog3);
			jAUztRJ5.draw(r9EHJSAy);

			if (MKjoH6Kr != null) {
				EntityCollection dzKk9rHG = MKjoH6Kr.getOwner().getEntityCollection();
				if (dzKk9rHG != null) {
					String KgPxOi8H = null;
					PieToolTipGenerator OMleeOnN = getToolTipGenerator();
					if (OMleeOnN != null) {
						KgPxOi8H = OMleeOnN.generateToolTip(vdguWFjW, eTA2gwAA);
					}
					String N9Nsn4NX = null;
					if (getURLGenerator() != null) {
						N9Nsn4NX = getURLGenerator().generateURL(vdguWFjW, eTA2gwAA, getPieIndex());
					}
					PieSectionEntity Ba4cSjAQ = new PieSectionEntity(r9EHJSAy, vdguWFjW, getPieIndex(), kP1Vwoz8,
							eTA2gwAA, KgPxOi8H, N9Nsn4NX);
					dzKk9rHG.add(Ba4cSjAQ);
				}
			}
			List eZaacwEK = vdguWFjW.getKeys();
			Rectangle2D Z7LFcHtc = new Rectangle2D.Double(i7quuIVJ.getX(), i7quuIVJ.getY(), i7quuIVJ.getWidth(),
					i7quuIVJ.getHeight() - p2lvJ9ee);
			if (getSimpleLabels()) {
				drawSimpleLabels(jAUztRJ5, eZaacwEK, tyuBlb7M, Z7LFcHtc, qDH2Hv34, cpjClBTF);
			} else {
				drawLabels(jAUztRJ5, eZaacwEK, tyuBlb7M, Z7LFcHtc, qDH2Hv34, cpjClBTF);
			}
		}

		jAUztRJ5.setClip(SeN63TEy);
		jAUztRJ5.setComposite(Fvro560Z);
		drawOutline(jAUztRJ5, i7quuIVJ);

	}
}