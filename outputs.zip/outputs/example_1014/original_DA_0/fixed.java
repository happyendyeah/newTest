public class test {
	public void draw(Graphics2D kdM3idWU, Rectangle2D rfqLMn5n, Point2D wzDXhmrh, PlotState IXfAKtS2,
			PlotRenderingInfo AQoUv2tt) {

		RectangleInsets x0XrLjUv = getInsets();
		x0XrLjUv.trim(rfqLMn5n);

		Rectangle2D hNdYXitV = (Rectangle2D) rfqLMn5n.clone();
		if (AQoUv2tt != null) {
			AQoUv2tt.setPlotArea(rfqLMn5n);
			AQoUv2tt.setDataArea(rfqLMn5n);
		}

		drawBackground(kdM3idWU, rfqLMn5n);

		Shape rgu3HQAM = kdM3idWU.getClip();
		kdM3idWU.clip(rfqLMn5n);

		double JT0iZn2j = getInteriorGap();
		double jZGEMzCk = 0.0;
		if (getLabelGenerator() != null) {
			jZGEMzCk = getLabelGap() + getMaximumLabelWidth();
		}
		double RpK65Q83 = rfqLMn5n.getWidth() * (JT0iZn2j + jZGEMzCk) * 2.0;
		double ut1pjQ2w = rfqLMn5n.getHeight() * JT0iZn2j * 2.0;

		if (DEBUG_DRAW_INTERIOR) {
			double SaSqFX0P = rfqLMn5n.getWidth() * getInteriorGap();
			double ZaHblYl0 = rfqLMn5n.getHeight() * getInteriorGap();
			double xHcxF04B = rfqLMn5n.getX() + SaSqFX0P;
			double Lk7rwrSs = rfqLMn5n.getMaxX() - SaSqFX0P;
			double agqOrLeM = rfqLMn5n.getY() + ZaHblYl0;
			double zNVkLyJU = rfqLMn5n.getMaxY() - ZaHblYl0;
			kdM3idWU.setPaint(Color.lightGray);
			kdM3idWU.draw(new Rectangle2D.Double(xHcxF04B, agqOrLeM, Lk7rwrSs - xHcxF04B, zNVkLyJU - agqOrLeM));
		}

		double gtGlVp9N = rfqLMn5n.getX() + RpK65Q83 / 2;
		double ljquNWNO = rfqLMn5n.getY() + ut1pjQ2w / 2;
		double FzzZyPGZ = rfqLMn5n.getWidth() - RpK65Q83;
		double hu5SwM9q = rfqLMn5n.getHeight() - ut1pjQ2w;

		if (isCircular()) { // is circular?
			double c2FCSRXo = Math.min(FzzZyPGZ, hu5SwM9q) / 2;
			gtGlVp9N = (gtGlVp9N + gtGlVp9N + FzzZyPGZ) / 2 - c2FCSRXo;
			ljquNWNO = (ljquNWNO + ljquNWNO + hu5SwM9q) / 2 - c2FCSRXo;
			FzzZyPGZ = 2 * c2FCSRXo;
			hu5SwM9q = 2 * c2FCSRXo;
		}

		if (DatasetUtilities.isEmptyOrNull(getDataset())) {
			drawNoDataMessage(kdM3idWU, rfqLMn5n);
			kdM3idWU.setClip(rgu3HQAM);
			drawOutline(kdM3idWU, rfqLMn5n);
			return;
		}

		PiePlotState Y8h88djT = initialise(kdM3idWU, rfqLMn5n, this, null, AQoUv2tt);

		Rectangle2D p5xEljYG = new Rectangle2D.Double(gtGlVp9N, ljquNWNO, FzzZyPGZ, hu5SwM9q * (1 - this.depthFactor));
		Y8h88djT.setLinkArea(p5xEljYG);

		if (DEBUG_DRAW_LINK_AREA) {
			kdM3idWU.setPaint(Color.blue);
			kdM3idWU.draw(p5xEljYG);
			kdM3idWU.setPaint(Color.yellow);
			kdM3idWU.draw(
					new Ellipse2D.Double(p5xEljYG.getX(), p5xEljYG.getY(), p5xEljYG.getWidth(), p5xEljYG.getHeight()));
		}

		double JK8k3vnK = FzzZyPGZ * getLabelLinkMargin();
		double g2QRae4u = hu5SwM9q * getLabelLinkMargin();
		Rectangle2D LjWBA9XC = new Rectangle2D.Double(gtGlVp9N + JK8k3vnK / 2.0, ljquNWNO + g2QRae4u / 2.0,
				FzzZyPGZ - JK8k3vnK, hu5SwM9q - g2QRae4u);

		Y8h88djT.setExplodedPieArea(LjWBA9XC);

		double QDiR4ih3 = getMaximumExplodePercent();
		double yBrRgSQe = QDiR4ih3 / (1.0 + QDiR4ih3);

		double p9D4kuZp = LjWBA9XC.getWidth() * yBrRgSQe;
		double pvZcVzWt = LjWBA9XC.getHeight() * yBrRgSQe;
		Rectangle2D WHg2Irr0 = new Rectangle2D.Double(LjWBA9XC.getX() + p9D4kuZp / 2.0,
				LjWBA9XC.getY() + pvZcVzWt / 2.0, LjWBA9XC.getWidth() - p9D4kuZp, LjWBA9XC.getHeight() - pvZcVzWt);

		int Tg0lF8Xo = (int) (WHg2Irr0.getHeight() * this.depthFactor);
		Rectangle2D BUBGDHpS = new Rectangle2D.Double(gtGlVp9N, ljquNWNO, FzzZyPGZ, hu5SwM9q - Tg0lF8Xo);
		Y8h88djT.setLinkArea(BUBGDHpS);

		Y8h88djT.setPieArea(WHg2Irr0);
		Y8h88djT.setPieCenterX(WHg2Irr0.getCenterX());
		Y8h88djT.setPieCenterY(WHg2Irr0.getCenterY() - Tg0lF8Xo / 2.0);
		Y8h88djT.setPieWRadius(WHg2Irr0.getWidth() / 2.0);
		Y8h88djT.setPieHRadius((WHg2Irr0.getHeight() - Tg0lF8Xo) / 2.0);

		PieDataset QOHe4uWY = getDataset();
		if (DatasetUtilities.isEmptyOrNull(getDataset())) {
			drawNoDataMessage(kdM3idWU, rfqLMn5n);
			kdM3idWU.setClip(rgu3HQAM);
			drawOutline(kdM3idWU, rfqLMn5n);
			return;
		}

		if (QOHe4uWY.getKeys().size() > rfqLMn5n.getWidth()) {
			String rcWda13I = "Too many elements";
			Font sqMVpMhP = new Font("dialog", Font.BOLD, 10);
			kdM3idWU.setFont(sqMVpMhP);
			FontMetrics qJODqrs7 = kdM3idWU.getFontMetrics(sqMVpMhP);
			int CqZPeYUy = qJODqrs7.stringWidth(rcWda13I);

			kdM3idWU.drawString(rcWda13I, (int) (rfqLMn5n.getX() + (rfqLMn5n.getWidth() - CqZPeYUy) / 2),
					(int) (rfqLMn5n.getY() + (rfqLMn5n.getHeight() / 2)));
			return;
		}
		if (isCircular()) {
			double mr71jIsW = Math.min(rfqLMn5n.getWidth(), rfqLMn5n.getHeight()) / 2;
			rfqLMn5n = new Rectangle2D.Double(rfqLMn5n.getCenterX() - mr71jIsW, rfqLMn5n.getCenterY() - mr71jIsW,
					2 * mr71jIsW, 2 * mr71jIsW);
		}
		List vgEWPH7O = QOHe4uWY.getKeys();

		if (vgEWPH7O.size() == 0) {
			return;
		}

		double WyiAJZnF = WHg2Irr0.getX();
		double W9Whlduj = WHg2Irr0.getY();

		Composite cX9mN9H2 = kdM3idWU.getComposite();
		kdM3idWU.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, getForegroundAlpha()));

		double rgLfG1kE = DatasetUtilities.calculatePieDatasetTotal(QOHe4uWY);
		double qOyPu3HK = 0;
		if (Tg0lF8Xo < 0) {
			return; // if depth is negative don't draw anything
		}

		ArrayList vA2wiOj9 = new ArrayList();
		Arc2D.Double HPw03ncl;
		Paint Inwfl2Rd;
		Paint Pzjwqf6O;
		Stroke Vjs1B01B;

		Iterator aG6o7VTN = vgEWPH7O.iterator();
		while (aG6o7VTN.hasNext()) {

			Comparable Klbq8nyd = (Comparable) aG6o7VTN.next();
			Number Wt2wPzxM = QOHe4uWY.getValue(Klbq8nyd);
			if (Wt2wPzxM == null) {
				vA2wiOj9.add(null);
				continue;
			}
			double gdkMEy2G = Wt2wPzxM.doubleValue();
			if (gdkMEy2G <= 0) {
				vA2wiOj9.add(null);
				continue;
			}
			double gkBCVKnp = getStartAngle();
			double qjFHg9m5 = getDirection().getFactor();
			double DMw5gdoz = gkBCVKnp + (qjFHg9m5 * (qOyPu3HK * 360)) / rgLfG1kE;
			double ie3V9hOI = gkBCVKnp + (qjFHg9m5 * (qOyPu3HK + gdkMEy2G) * 360) / rgLfG1kE;
			if (Math.abs(ie3V9hOI - DMw5gdoz) > getMinimumArcAngleToDraw()) {
				vA2wiOj9.add(new Arc2D.Double(WyiAJZnF, W9Whlduj + Tg0lF8Xo, WHg2Irr0.getWidth(),
						WHg2Irr0.getHeight() - Tg0lF8Xo, DMw5gdoz, ie3V9hOI - DMw5gdoz, Arc2D.PIE));
			} else {
				vA2wiOj9.add(null);
			}
			qOyPu3HK += gdkMEy2G;
		}

		Shape aXN8XdFh = kdM3idWU.getClip();

		Ellipse2D R3vJcvT8 = new Ellipse2D.Double(WHg2Irr0.getX(), WHg2Irr0.getY(), WHg2Irr0.getWidth(),
				WHg2Irr0.getHeight() - Tg0lF8Xo);

		Ellipse2D VVBdPDs5 = new Ellipse2D.Double(WHg2Irr0.getX(), WHg2Irr0.getY() + Tg0lF8Xo, WHg2Irr0.getWidth(),
				WHg2Irr0.getHeight() - Tg0lF8Xo);

		Rectangle2D uGQZZhDd = new Rectangle2D.Double(R3vJcvT8.getX(), R3vJcvT8.getCenterY(), WHg2Irr0.getWidth(),
				VVBdPDs5.getMaxY() - R3vJcvT8.getCenterY());

		Rectangle2D LgjxBn9D = new Rectangle2D.Double(WHg2Irr0.getX(), R3vJcvT8.getY(), WHg2Irr0.getWidth(),
				VVBdPDs5.getCenterY() - R3vJcvT8.getY());

		Area C8dgq94v = new Area(R3vJcvT8);
		C8dgq94v.add(new Area(uGQZZhDd));
		Area ZEgHWoX7 = new Area(VVBdPDs5);
		ZEgHWoX7.add(new Area(LgjxBn9D));
		Area bOhem107 = new Area(C8dgq94v);
		bOhem107.intersect(ZEgHWoX7);

		Area iE7A6PZp = new Area(bOhem107);
		iE7A6PZp.subtract(new Area(R3vJcvT8));

		Area uRIyj7Nr = new Area(bOhem107);
		uRIyj7Nr.subtract(new Area(VVBdPDs5));

		int[] zPC8gEd3;
		int[] OT39wZ0H;
		HPw03ncl = new Arc2D.Double(WyiAJZnF, W9Whlduj + Tg0lF8Xo, WHg2Irr0.getWidth(), WHg2Irr0.getHeight() - Tg0lF8Xo,
				0, 360, Arc2D.PIE);

		int MsULufxq = vA2wiOj9.size();
		for (int ISAOdOLd = 0; ISAOdOLd < MsULufxq; ISAOdOLd++) {
			HPw03ncl = (Arc2D.Double) vA2wiOj9.get(ISAOdOLd);
			if (HPw03ncl == null) {
				continue;
			}
			Comparable b1wnc78I = getSectionKey(ISAOdOLd);
			Inwfl2Rd = lookupSectionPaint(b1wnc78I, true);
			Pzjwqf6O = lookupSectionOutlinePaint(b1wnc78I);
			Vjs1B01B = lookupSectionOutlineStroke(b1wnc78I);
			kdM3idWU.setPaint(Inwfl2Rd);
			kdM3idWU.fill(HPw03ncl);
			kdM3idWU.setPaint(Pzjwqf6O);
			kdM3idWU.setStroke(Vjs1B01B);
			kdM3idWU.draw(HPw03ncl);
			kdM3idWU.setPaint(Inwfl2Rd);

			Point2D RksDfscX = HPw03ncl.getStartPoint();

			zPC8gEd3 = new int[] { (int) HPw03ncl.getCenterX(), (int) HPw03ncl.getCenterX(), (int) RksDfscX.getX(),
					(int) RksDfscX.getX() };
			OT39wZ0H = new int[] { (int) HPw03ncl.getCenterY(), (int) HPw03ncl.getCenterY() - Tg0lF8Xo,
					(int) RksDfscX.getY() - Tg0lF8Xo, (int) RksDfscX.getY() };
			Polygon tryWVPoB = new Polygon(zPC8gEd3, OT39wZ0H, 4);
			kdM3idWU.setPaint(java.awt.Color.lightGray);
			kdM3idWU.fill(tryWVPoB);
			kdM3idWU.setPaint(Pzjwqf6O);
			kdM3idWU.setStroke(Vjs1B01B);
			kdM3idWU.draw(tryWVPoB);
			kdM3idWU.setPaint(Inwfl2Rd);

		}

		kdM3idWU.setPaint(Color.gray);
		kdM3idWU.fill(uRIyj7Nr);
		kdM3idWU.fill(iE7A6PZp);

		int XaD7Svet = 0;
		aG6o7VTN = vA2wiOj9.iterator();
		while (aG6o7VTN.hasNext()) {
			Arc2D RpYcOgSM = (Arc2D) aG6o7VTN.next();
			if (RpYcOgSM != null) {
				Comparable JK4bPkxo = getSectionKey(XaD7Svet);
				Inwfl2Rd = lookupSectionPaint(JK4bPkxo, true);
				Pzjwqf6O = lookupSectionOutlinePaint(JK4bPkxo);
				Vjs1B01B = lookupSectionOutlineStroke(JK4bPkxo);
				drawSide(kdM3idWU, WHg2Irr0, RpYcOgSM, iE7A6PZp, uRIyj7Nr, Inwfl2Rd, Pzjwqf6O, Vjs1B01B, false, true);
			}
			XaD7Svet++;
		}

		XaD7Svet = 0;
		aG6o7VTN = vA2wiOj9.iterator();
		while (aG6o7VTN.hasNext()) {
			Arc2D uVjTyecb = (Arc2D) aG6o7VTN.next();
			if (uVjTyecb != null) {
				Comparable yf5V7KjR = getSectionKey(XaD7Svet);
				Inwfl2Rd = lookupSectionPaint(yf5V7KjR);
				Pzjwqf6O = lookupSectionOutlinePaint(yf5V7KjR);
				Vjs1B01B = lookupSectionOutlineStroke(yf5V7KjR);
				drawSide(kdM3idWU, WHg2Irr0, uVjTyecb, iE7A6PZp, uRIyj7Nr, Inwfl2Rd, Pzjwqf6O, Vjs1B01B, true, false);
			}
			XaD7Svet++;
		}

		kdM3idWU.setClip(aXN8XdFh);

		Arc2D rYq8KDMD;
		for (int zT0n6qHA = 0; zT0n6qHA < MsULufxq; zT0n6qHA++) {
			HPw03ncl = (Arc2D.Double) vA2wiOj9.get(zT0n6qHA);
			if (HPw03ncl == null) {
				continue;
			}
			rYq8KDMD = new Arc2D.Double(WyiAJZnF, W9Whlduj, WHg2Irr0.getWidth(), WHg2Irr0.getHeight() - Tg0lF8Xo,
					HPw03ncl.getAngleStart(), HPw03ncl.getAngleExtent(), Arc2D.PIE);

			Comparable LqrWtCuj = (Comparable) vgEWPH7O.get(zT0n6qHA);
			Inwfl2Rd = lookupSectionPaint(LqrWtCuj, true);
			Pzjwqf6O = lookupSectionOutlinePaint(LqrWtCuj);
			Vjs1B01B = lookupSectionOutlineStroke(LqrWtCuj);
			kdM3idWU.setPaint(Inwfl2Rd);
			kdM3idWU.fill(rYq8KDMD);
			kdM3idWU.setStroke(Vjs1B01B);
			kdM3idWU.setPaint(Pzjwqf6O);
			kdM3idWU.draw(rYq8KDMD);

			if (AQoUv2tt != null) {
				EntityCollection binlYFOD = AQoUv2tt.getOwner().getEntityCollection();
				if (binlYFOD != null) {
					String vt2Dsh45 = null;
					PieToolTipGenerator UDKTI36r = getToolTipGenerator();
					if (UDKTI36r != null) {
						vt2Dsh45 = UDKTI36r.generateToolTip(QOHe4uWY, LqrWtCuj);
					}
					String SWdCinTm = null;
					if (getURLGenerator() != null) {
						SWdCinTm = getURLGenerator().generateURL(QOHe4uWY, LqrWtCuj, getPieIndex());
					}
					PieSectionEntity qs1Q0Ixs = new PieSectionEntity(rYq8KDMD, QOHe4uWY, getPieIndex(), zT0n6qHA,
							LqrWtCuj, vt2Dsh45, SWdCinTm);
					binlYFOD.add(qs1Q0Ixs);
				}
			}
			List Tsyi0xOn = QOHe4uWY.getKeys();
			Rectangle2D JvZEqV1G = new Rectangle2D.Double(hNdYXitV.getX(), hNdYXitV.getY(), hNdYXitV.getWidth(),
					hNdYXitV.getHeight() - Tg0lF8Xo);
			if (getSimpleLabels()) {
				drawSimpleLabels(kdM3idWU, Tsyi0xOn, rgLfG1kE, JvZEqV1G, BUBGDHpS, Y8h88djT);
			} else {
				drawLabels(kdM3idWU, Tsyi0xOn, rgLfG1kE, JvZEqV1G, BUBGDHpS, Y8h88djT);
			}
		}

		kdM3idWU.setClip(rgu3HQAM);
		kdM3idWU.setComposite(cX9mN9H2);
		drawOutline(kdM3idWU, hNdYXitV);

	}
}